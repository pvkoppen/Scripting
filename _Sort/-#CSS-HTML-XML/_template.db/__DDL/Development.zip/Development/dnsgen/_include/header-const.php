<?php

 if (!defined("CONST_APP_TITLE"  )) { define("CONST_APP_TITLE"  , "  <title>DNS-Gen site</title>\n"); };
 if (!defined("CONST_APP_REFRESH")) { define("CONST_APP_REFRESH", "  \n"); };
 if (!defined("CONST_APP_CONTENT")) { define("CONST_APP_CONTENT", "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n"); };
 if (!defined("CONST_APP_STYLE"  )) { define("CONST_APP_STYLE"  , "  <link href=\"../html/style.css\" rel=\"stylesheet\" type=\"text/css\">\n"); };

?>