<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: thumb.php,v 1.6 2004/12/21 00:42:10 cvs Exp $
##################################################

$img = "";

define("BASE",$_GET['base']);

function fallbackPreviewImage() {
	$fh = fopen(BASE."default_preview.gif","rb");
	$fallback = fread($fh,65536);
	header("Content-type: image/gif");
	echo $fallback;
	fclose($fh);
}

if (!function_exists("getimagesize")) {
	fallbackPreviewImage();
	exit();
}

$sizeinfo = getimagesize(BASE.$_GET['file']);

if (!isset($sizeinfo['mimetype'])) {
	$types = array(
		"jpg"=>"image/jpeg",
		"jpeg"=>"image/jpeg",
		"gif"=>"image/gif",
		"png"=>"image/png"
	);
	
	foreach ($types as $type=>$mime) {
		if (substr($_GET['file'],-1*strlen($type),strlen($type)) == $type) $sizeinfo['mime'] = $mime;
	}
}

if ($sizeinfo['mime'] == "image/jpeg" && function_exists("imagecreatefromjpeg")) {
	$img = imagecreatefromjpeg($_GET['file']);
} else if ($sizeinfo['mime'] == "image/png" && function_exists("imagecreatefrompng")) {
	$img = imagecreatefrompng($_GET['file']);
} else if ($sizeinfo['mime'] == "image/gif" && function_exists("imagecreatefromgif")) {
	$img = imagecreatefromgif($_GET['file']);
} else {
	fallbackPreviewImage();
	exit();
}

$height = $newheight = $sizeinfo[1];
$width = $newwidth =  $sizeinfo[0];

if (isset($_GET['width'])) {
	$percent = $_GET['width'] / $newwidth;
	$newwidth = $_GET['width'];
	$newheight = $percent * $sizeinfo[1];
} else if (isset($_GET['height'])) {
	$percent = $_GET['height'] / $newheight;
	$newheight = $_GET['height'];
	$newwidth = $percent * $sizeinfo[0];
} else if (isset($_GET['scale'])) {
	$scale = $_GET['scale'] / 100;
	$newwidth = $newwidth * $scale;
	$newheight = $newheight * $scale;
}

header("Content-type: " . $sizeinfo['mime']);
if ($height == $newheight && $width == $newwidth) {
	$thumb = $img;
} else {
	//$thumb = imagecreatetruecolor($newwidth,$newheight);
	$thumb = imagecreate($newwidth,$newheight);

	imagecopyresized($thumb,$img,0,0,0,0,$newwidth,$newheight,$sizeinfo[0],$sizeinfo[1]);
}
if ($sizeinfo['mime'] == "image/jpeg") {
	imagejpeg($thumb);
} else if ($sizeinfo['mime'] == "image/png") {
	imagepng($thumb);
} else if ($sizeinfo['mime'] == "image/gif") {
	imagepng($thumb);
}

?>
