<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: calendar.php,v 1.2 2004/10/29 00:01:53 cvs Exp $
##################################################

class calendar {
	function form($object) {
		global $user;
	
		if (!defined("SYS_FORMS")) include_once(BASE."subsystems/forms.php");
		pathos_forms_initialize();
		
		$form = new form();
		if (!isset($object->id)) {
			$object->title = "";
			$object->body = "";
			$object->eventstart = time();
			$object->eventend = time()+3600;
			
		} else {
			$form->meta("id",$object->id);
		}
		
		$form->register("title","Title",new textcontrol($object->title));
		$form->register("body","Body",new htmleditorcontrol($object->body));
		
		$form->register(uniqid(""),"", new htmlcontrol("<hr size='1' />"));
		
		$form->register("eventstart","Starts on",new popupdatetimecontrol($object->eventstart));
		$form->register("eventend","Ends on",new popupdatetimecontrol($object->eventend));
		
		$form->register("submit","",new buttongroupcontrol("Save","","Cancel"));
		
		pathos_forms_cleanup();
		return $form;
	}
	
	function update($values,$object) {
		if (!defined("SYS_FORMS")) include_once(BASE."subsystems/forms.php");
		pathos_forms_initialize();
		
		$object->title = $values['title'];
		
		$object->body = preg_replace("/<br ?\/>$/","",trim($values['body']));
		
		$object->eventstart = popupdatetimecontrol::parseData("eventstart",$values);
		$object->eventend = popupdatetimecontrol::parseData("eventend",$values);
		
		if (!isset($object->id)) {
			global $user;
			$object->poster = $user->id;
			$object->posted = time();
		}
		
		pathos_forms_cleanup();
		return $object;
	}
}

?>