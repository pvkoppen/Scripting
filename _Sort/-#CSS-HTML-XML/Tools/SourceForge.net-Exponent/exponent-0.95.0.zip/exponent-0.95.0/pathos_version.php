<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: pathos_version.php,v 1.13 2004/12/21 00:05:16 cvs Exp $
##################################################

if (!defined("PATHOS_VERSION")) {
	#define("DEVELOPMENT",1);
	define("PATHOS_VERSION_MAJOR",0);
	define("PATHOS_VERSION_MINOR",95);
	define("PATHOS_VERSION_REVISION",0);
	define("PATHOS_VERSION_BUILDDATE","1103615306");
	define("PATHOS_VERSION_TYPE","");
	define("PATHOS_VERSION_ITERATION","0"); // only applies to betas/alphas / rcs
}

return "0.95";

?>
