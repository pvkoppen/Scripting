<?php

return array(
	"modules/addressbookmodule/actions/edit.php"=>"a58b3b22bb4b8af704d7b28e08649756",
	"modules/addressbookmodule/actions/delete.php"=>"df22b7bc50d9ae9ac52b95ea64d0eb1d",
	"modules/addressbookmodule/actions/save.php"=>"fda9146fb9071694010493962795ae49",
	"modules/addressbookmodule/actions/view.php"=>"fd57a9b1d4f777abf629b018964c8e2e",
	"modules/addressbookmodule/actions/save_copy.php"=>"b1c613a00ffe7c7f2e605c92cbc33010",
	"modules/addressbookmodule/actions/reference.php"=>"cce06cee29bccead06659cf01bcf7cda",
	"modules/addressbookmodule/actions/save_reference.php"=>"e9af0431a7fbe0f27023c566155669ed",
	"modules/addressbookmodule/actions/copy.php"=>"b52b94a7edafd64ed82a3a1c48462a82",
	"modules/addressbookmodule/class.php"=>"eef9576af3e8b70c362ba50a3441f03f",
	"modules/addressbookmodule/views/Default.tpl"=>"2ba6279d59ddf34fbcd9aad9805f1362",
	"modules/addressbookmodule/views/_view.tpl"=>"c2e22c1cf5f7e69f243379f2f29f288b",
	"modules/addressbookmodule/views/_form_edit.tpl"=>"00089b5256d35bd28c42dfe22f9f5ee8",
	"modules/addressbookmodule/views/_form_copy.tpl"=>"4fed29e6247e4b33c3632d564336379a",
	"modules/addressbookmodule/views/_form_reference.tpl"=>"e53d99361e6c8c28f8e572996dbb270e",
	"datatypes/addressbook_contact.php"=>"c909ca2a3f40dfb63b9a9065997d2315",
	"datatypes/definitions/addressbook_contact.php"=>"1704171f62d7bf2bddd46a71e8bec61a",
);
?>
