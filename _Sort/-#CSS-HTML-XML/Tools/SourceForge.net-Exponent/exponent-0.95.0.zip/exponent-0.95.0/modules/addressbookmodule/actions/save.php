<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: save.php,v 1.5 2004/10/29 00:09:00 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("addressbookmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to save a contact");
	pathos_debug_message(1,"Running the 'save' action");
}

$contact = null;
$iloc = null;
if (isset($_POST['id'])) {
	$contact = $db->selectObject("addressbook_contact","id=".$_POST['id']);
	$loc = unserialize($contact->location_data);
	$iloc = pathos_core_makeLocation($loc->mod,$loc->src,$contact->id);
	
	if (DEBUG) {
		pathos_debug_message(1,"Found an id in POST.  Performing an edit on (id:".$_POST['id'].")");
		pathos_debug_message(1,"Will check 'edit' permission on module and existing contact (\$loc and \$iloc)");
		
		pathos_debug_message(2,"Existing contact to update:");
		pathos_debug_message(2,pathos_debug_dump($contact,"contact"));
		
		pathos_debug_message(1,"Overwrote passed location with contact's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		pathos_debug_message(1,"Generated internal location from contact.");
		pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
	}
} else if (DEBUG) {
	pathos_debug_message(1,"No id was found in POST.  Saving a new contact");
	pathos_debug_message(1,"Will check 'post' permission on module (\$loc)");
}

if (DEBUG) pathos_debug_message(0,"Checking permissions");

if (	($contact == null && pathos_permissions_check("post",$loc)) ||
	($contact != null && pathos_permissions_check("edit",$loc)) ||
	($iloc != null && pathos_permissions_check("edit",$iloc))
) {
	$contact = addressbook_contact::update($_POST,$contact);
	$contact->location_data = serialize($loc);
	
	if (DEBUG) {
		pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
		pathos_debug_message(1,"Updated contact object from POST data");
		pathos_debug_message(2,pathos_debug_dump($contact,"contact"));
	}
	
	if (isset($contact->id)) {
		if (DEBUG) pathos_debug_message(1,"The id attribute was set; performing a database UPDATE statement");
		$db->updateObject($contact,"addressbook_contact");
	} else {
		if (DEBUG) pathos_debug_message(1,"No id attribute was present; performing a database INSERT statement");
		$db->insertObject($contact,"addressbook_contact");
	}
	
	if (!DEBUG) pathos_flow_redirect();
} else if (DEBUG) {
	pathos_debug_message(0,"Permissions check failed.  Action will not execute");
}

if (DEBUG) {
	pathos_debug_backLink();
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>