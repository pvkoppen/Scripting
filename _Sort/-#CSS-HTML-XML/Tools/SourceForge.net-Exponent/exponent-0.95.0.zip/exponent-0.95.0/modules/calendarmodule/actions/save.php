<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: save.php,v 1.4 2004/10/29 12:42:27 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("addressbookmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to save a calendar event");
	pathos_debug_message(1,"Running the 'save' action");
}

$item = null;
$iloc = null;
if (isset($_POST['id'])) {
	$item = $db->selectObject("calendar","id=".$_POST['id']);
	$loc = unserialize($item->location_data);
	$iloc = pathos_core_makeLocation($loc->mod,$loc->src,$item->id);
	
	if (DEBUG) {
		pathos_debug_message(1,"Found an id in POST.  Performing an edit on (id:".$_POST['id'].")");
		pathos_debug_message(1,"Will check 'edit' permission on module and existing calendar event (\$loc and \$iloc)");
		
		pathos_debug_message(2,"Existing calendar to update:");
		pathos_debug_message(2,pathos_debug_dump($item,"item"));
		
		pathos_debug_message(1,"Overwrote passed location with calendar event's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		pathos_debug_message(1,"Generated internal location from calendar event.");
		pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
	}
} else if (DEBUG) {
	pathos_debug_message(1,"No id was found in POST.  Saving a new calendar event");
	pathos_debug_message(1,"Will check 'post' permission on module (\$loc)");
}

if (DEBUG) pathos_debug_message(0,"Checking permissions");

if (	($item == null && pathos_permissions_check("post",$loc)) ||
	($item != null && pathos_permissions_check("edit",$loc)) ||
	($iloc != null && pathos_permissions_check("edit",$iloc))
) {
	if (DEBUG) pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
	
	$item = calendar::update($_POST,$item);
	$item->location_data = serialize($loc);
	
	if (DEBUG) {
		pathos_debug_message(1,"Updated calendar event object from POST data");
		pathos_debug_message(2,pathos_debug_dump($item,"item"));
	}
	
	if (!defined("SYS_WORKFLOW")) include_once(BASE."subsystems/workflow.php");
	if (DEBUG) pathos_debug_message(1,"Posting calendar event to workflow for approval handling.");
	
	if (isset($item->id)) {
		pathos_workflow_post($item,"calendar",$loc);
	} else {
#		$id = $db->insertObject($item,"unifiedcontent");
#		$thisloc = pathos_core_makeLocation($loc->mod,$loc->src,$id);
#		foreach (array_keys(unifiedcontentmodule::permissions($id)) as $perm) {
#			pathos_permissions_grant($user,$perm,$thisloc);
#		}
#		pathos_permissions_triggerSingleRefresh($user);
		
		pathos_workflow_post($item,"calendar",$loc);
	}
}

if (DEBUG) {
	pathos_debug_backLink();
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>