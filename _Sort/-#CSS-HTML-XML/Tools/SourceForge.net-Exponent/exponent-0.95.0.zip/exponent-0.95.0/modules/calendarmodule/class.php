<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: class.php,v 1.8 2004/11/23 21:22:14 cvs Exp $
##################################################

class calendarmodule {
	function name() { return "Calendar"; }
	function author() { return "OIC Group Exponent Team / Greg Otte"; }
	function description() { return "Allows posting of content to a calendar."; }
	
	function hasContent() { return true; }
	function hasSources() { return true; }
	function hasViews()   { return true; }
	
	function supportsWorkflow() { return true; }
	
	function permissions($internal = "") {
		if ($internal == "") {
			return array(
				"administrate"=>"Administrate",
			//	"configure"=>"Configure",
				"post"=>"Create",
				"edit"=>"Edit",
				"delete"=>"Delete",
				"approve"=>"Approve",
				"manage_approval"=>"Manage Approval"
			);
		} else {
			return array(
				"administrate"=>"Administrate",
				"edit"=>"Edit",
				"delete"=>"Delete"
			);
		}
	}
	
	function getLocationHierarchy($loc) {
		if ($loc->int == "") return array($loc);
		else return array($loc,pathos_core_makelocation($loc->mod,$loc->src));
	}
	
	function show($view,$location = null, $title = "") {
		if (DEBUG) {
			$__olddebug = pathos_debug_setContext("calendarmodule");
			pathos_debug_clear();
		}
	
		global $user;
		global $db;
		
		$template = new Template("calendarmodule",$view,$location);
		$template->assign("moduletitle",$title);
		
		$canviewapproval = false;
		$inapproval = false;
		
		global $user;
		if ($user) $canviewapproval = (pathos_permissions_check("approve",$location) || pathos_permissions_check("manage_approval",$location));
		if ($db->countObjects("calendar","location_data='".serialize($location)."' AND approved!=1")) {
			foreach ($db->selectObjects("calendar","location_data='".serialize($location)."' AND approved!=1") as $c) {
				if ($c->poster == $user->id) $canviewapproval = true;
			}
			$inapproval = true;
		}
		
		$viewconfig = array("type"=>"default");
		if (is_readable($template->viewdir."/$view.config")) {
			$viewconfig = include($template->viewdir."/$view.config");
			if (DEBUG) pathos_debug_message(1,"Read static view configuration from file " . $template->viewdir."/$view.config");
		} else if (DEBUG) {
			pathos_debug_message(1,"Using default static view configuration");
		}
		if (DEBUG) pathos_debug_message(2,pathos_debug_dump($viewconfig,"viewconfig"));
		
		if (!defined("SYS_DATETIME")) include_once(BASE."subsystems/datetime.php");
		
		if ($viewconfig['type'] == "minical") {
			$monthly = array();
			$info = getdate(time());
			$info = getdate(time());
			// Grab non-day numbers only (before end of month)
			$week = 0;
			$currentweek = 0;
			
			$infofirst = getdate(mktime(12,0,0,$info['mon'],1,$info['year']));
			
			if ($infofirst['wday'] == 0) $monthly[$week] = array(); // initialize for non days
			for ($i = 0 - $infofirst['wday']; $i < 0; $i++) {
				$monthly[$week][$i] = array("number"=>-1,"ts"=>-1);
			}
			$weekday = $infofirst['wday']; // day number in grid.  if 7+, switch weeks
			// Grab day counts
			$endofmonth = pathos_datetime_endOfMonthDay(time());
			for ($i = 1; $i <= $endofmonth; $i++) {
				$start = mktime(0,0,0,$info['mon'],$i,$info['year']);
				if ($i == $info['mday']) $currentweek = $week;
				$monthly[$week][$i] = array("ts"=>$start,"number"=>$db->countObjects("calendar","location_data='".serialize($location)."' AND approved!=0 AND (eventstart >= $start AND eventend <= " . ($start+86399) . ")"));
				if ($weekday >= 6) {
					$week++;
					$monthly[$week] = array(); // allocate an array for the next week
					$weekday = 0;
				} else $weekday++;
			}
			// Grab non-day numbers only (after end of month)
			for ($i = 1; $weekday && $i <= (7-$weekday); $i++) $monthly[$week][$i+$endofmonth] = -1;
			
			$template->assign("monthly",$monthly);
			$template->assign("currentweek",$currentweek);
			$template->assign("now",time());
		} else if ($viewconfig['type'] == "weekly") {
			$startweek = pathos_datetime_startOfWeekTimestamp(time());
			$days = array();
			for ($i = 0; $i < 7; $i++) {
				$start = $startweek + ($i*86400);
				$days[$start] = $db->selectObjects("calendar","location_data='".serialize($location)."' AND (eventstart >= $start AND eventend <= " . ($start+86399) . ") AND approved!=0");
				for ($j = 0; $j < count($days[$start]); $j++) {
					$thisloc = pathos_core_makeLocation($location->mod,$location->src,$days[$start][$j]->id);
					$days[$start][$j]->permissions = array(
						"administrate"=>(pathos_permissions_check("administrate",$thisloc) || pathos_permissions_check("administrate",$location)),
						"edit"=>(pathos_permissions_check("edit",$thisloc) || pathos_permissions_check("edit",$location)),
						"delete"=>(pathos_permissions_check("delete",$thisloc) || pathos_permissions_check("delete",$location))
					);
				}
			}
			$template->assign("days",$days);
		} else if ($viewconfig['type'] == "monthly") {
			$monthly = array();
			$counts = array();
			
			$time = (isset($_GET['time']) ? $_GET['time'] : time());
			$info = getdate($time);
			$nowinfo = getdate(time());
			if ($info['mon'] != $nowinfo['mon']) $nowinfo['mday'] = -10;
			// Grab non-day numbers only (before end of month)
			$week = 0;
			$currentweek = -1;
			
			$timefirst = mktime(12,0,0,$info['mon'],1,$info['year']);
			$infofirst = getdate($timefirst);
			
			if ($infofirst['wday'] == 0) {
				$monthly[$week] = array(); // initialize for non days
				$counts[$week] = array();
			}
			for ($i = 1 - $infofirst['wday']; $i < 1; $i++) {
				$monthly[$week][$i] = array();
				$counts[$week][$i] = -1;
			}
			$weekday = $infofirst['wday']; // day number in grid.  if 7+, switch weeks
			// Grab day counts
			$endofmonth = pathos_datetime_endOfMonthDay($time);
			for ($i = 1; $i <= $endofmonth; $i++) {
				$start = mktime(0,0,0,$info['mon'],$i,$info['year']);
				if ($i == $nowinfo['mday']) $currentweek = $week;
				$monthly[$week][$i] = $db->selectObjects("calendar","location_data='".serialize($location)."' AND (eventstart >= $start AND eventend <= " . ($start+86399) . ") AND approved!=0");
				$counts[$week][$i] = count($monthly[$week][$i]);
				if ($weekday >= 6) {
					$week++;
					$monthly[$week] = array(); // allocate an array for the next week
					$counts[$week] = array();
					$weekday = 0;
				} else $weekday++;
			}
			// Grab non-day numbers only (after end of month)
			for ($i = 1; $weekday && $i < (8-$weekday); $i++) {
				$monthly[$week][$i+$endofmonth] = array();
				$counts[$week][$i+$endofmonth] = -1;
			}
			
			$template->assign("currentweek",$currentweek);
			$template->assign("monthly",$monthly);
			$template->assign("counts",$counts);
			$template->assign("nextmonth",$timefirst+(86400*45));
			$template->assign("prevmonth",$timefirst-(86400*15));
			$template->assign("now",$timefirst);
		} else if ($viewconfig['type'] == "administration") {
			// Check perms and return if cant view
			if ($viewconfig['type'] == "administration" && !$user) return;
			
			$continue = (	pathos_permissions_check("administrate",$location) ||
					pathos_permissions_check("post",$location) ||
					pathos_permissions_check("edit",$location) ||
					pathos_permissions_check("delete",$location) ||
					pathos_permissions_check("approve",$location) ||
					pathos_permissions_check("manage_approval",$location)
				) ? 1 : 0;
			$items = $db->selectObjects("calendar","location_data='" . serialize($location) . "' AND approved!=0");
			if (!$continue) {
				foreach ($items as $i) {
					$iloc = pathos_core_makeLocation($location->mod,$location->src,$i->id);
					if (	pathos_permissions_check("edit",$iloc) ||
						pathos_permissions_check("delete",$iloc) ||
						pathos_permissions_check("administrate",$iloc)
					) {
						$continue = true;
					}
				}
			}
			if (!$continue) return;
			
			for ($i = 0; $i < count($items); $i++) {
				$thisloc = pathos_core_makeLocation($location->mod,$location->src,$items[$i]->id);
				if ($user && $items[$i]->poster == $user->id) $canviewapproval = 1;
				$items[$i]->permissions = array(
					"administrate"=>(pathos_permissions_check("administrate",$thisloc) || pathos_permissions_check("administrate",$location)),
					"edit"=>(pathos_permissions_check("edit",$thisloc) || pathos_permissions_check("edit",$location)),
					"delete"=>(pathos_permissions_check("delete",$thisloc) || pathos_permissions_check("delete",$location))
				);
			}
			
			$template->assign("items",$items);
		} else if ($viewconfig['type'] == "default") {
			if (!isset($viewconfig['range'])) $viewconfig['range'] = "all";
			$items = null;
			switch ($viewconfig['range']) {
				case "all":
					$items = $db->selectObjects("calendar","location_data='" . serialize($location) . "' AND approved!=0");
					break;
				case "upcoming":
					$items = $db->selectObjects("calendar","location_data='" . serialize($location) . "' AND approved!=0 AND eventstart >= ".time());
					break;
				case "past":
					$items = $db->selectObjects("calendar","location_data='" . serialize($location) . "' AND approved!=0 AND eventstart < ".time());
					break;
				case "today":
					$items = $db->selectObjects("calendar","location_data='" . serialize($location) . "' AND approved!=0 AND eventstart >= ".pathos_datetime_startOfDayTimestamp(time()) . " AND eventend <= " . pathos_datetime_startOfDayTimestamp(time()) + 86400);
					break;
				case "next":
					$items = array($db->selectObject("calendar","location_data='" . serialize($location) . "' AND approved!=0 AND eventstart >= ".time()));
					break;
			}
			
			function tmpSort($a,$b) { return ($a->eventstart < $b->eventstart) ? -1 : 1; }
			usort($items,"tmpSort");
			
			for ($i = 0; $i < count($items); $i++) {
				$thisloc = pathos_core_makeLocation($location->mod,$location->src,$items[$i]->id);
				if ($user && $items[$i]->poster == $user->id) $canviewapproval = 1;
				$items[$i]->permissions = array(
					"administrate"=>(pathos_permissions_check("administrate",$thisloc) || pathos_permissions_check("administrate",$location)),
					"edit"=>(pathos_permissions_check("edit",$thisloc) || pathos_permissions_check("edit",$location)),
					"delete"=>(pathos_permissions_check("delete",$thisloc) || pathos_permissions_check("delete",$location))
				);
			}
			
			$template->assign("items",$items);
		}
		
		$template->assign("in_approval",$inapproval);
		$template->assign("linkbase","?module=calendarmodule&src=" . $location->src . "&int=" . $location->int . "&action=");
		$template->assign("wf_linkbase","?module=workflow&datatype=calendar&m=calendarmodule&s=".$location->src."&action=");
		$template->assign("canview_approval_link",$canviewapproval);
		$template->register_permissions(
			array("administrate"/*,"configure"*/,"post","edit","delete","manage_approval"),
			$location
		);
		
		if (DEBUG) {
			pathos_debug_output(SYS_DEBUG_TYPE_WITHDRAWN);
			pathos_debug_clear();
			pathos_debug_setContext($__olddebug);
		}
		
		$template->output($view);
	}
	
	function deleteIn($loc) {
		global $db;
		$items = $db->selectObjects("calendar","location_data='".serialize($loc)."'");
		foreach ($items as $i) {
			$db->delete("calendar_wf_revision","wf_original=".$i->id);
			$db->delete("calendar_wf_info","real_id=".$i->id);
		}
		$db->delete("calendar","location_data='".serialize($loc)."'");
	}
	
	function getContent($loc) {
		global $db;
		return $db->selectObjects("calendar","location_data='".serialize($loc)."' AND approved != 0");
	}
	
	function getContentType($loc) {
		return "calendar";
	}
	
	function copyContent($oloc,$nloc) {
	}
}

?>