<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: view.php,v 1.5 2004/10/29 00:15:17 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("calendarmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to view a calendar event");
	pathos_debug_message(1,"Running the 'view' action");
}

// PERM CHECK
	$item = $db->selectObject("calendar","id=" . $_GET['id']);
	if ($item) {
		$loc = unserialize($item->location_data);
		$iloc = pathos_core_makeLocation($loc->mod,$loc->src,$item->id);
		$item->permissions = array(
			"edit"=>(pathos_permissions_check("edit",$iloc) || pathos_permissions_check("edit",$loc)),
			"delete"=>(pathos_permissions_check("delete",$iloc) || pathos_permissions_check("delete",$loc)),
			"administrate"=>(pathos_permissions_check("administrate",$iloc) || pathos_permissions_check("administrate",$loc)),
		);
		// Debugger test
		$item->permissions = array(
			"edit"=>pathos_permissions_check("edit",$iloc),
			"delete"=>pathos_permissions_check("delete",$iloc),
			"administrate"=>pathos_permissions_check("administrate",$iloc)
		);
		
		if (DEBUG) {
			pathos_debug_message(1,"Found a calendar event to view (id:".$_GET['id'].")");
			pathos_debug_message(1,"Overwrote passed location with calendar event's stored location");
			pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
			
			pathos_debug_message(1,"Generated internal location from calendar event.");
			pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
			
			pathos_debug_message(1,"Registered permission data with calendar event, based on \$loc and \$iloc");
			pathos_debug_message(2,"Modified calendar event follows:");
			pathos_debug_message(2,pathos_debug_dump($item,"item"));
		}
		
		$template = new Template("calendarmodule","_view");
		$template->assign("item",$item);
		$template->assign("wf_linkbase","?module=workflow&datatype=calendar&m=calendarmodule&s=".$loc->src."&action=");
		
		$template->assign("directory","files/calendarmodule/".$loc->src);
		$template->assign("linkbase","?module=calendarmodule&src=".$loc->src."&int=".$loc->int."&action=");
		$template->register_permissions(
			array("post","edit","delete","administrate","manage_approval"),
			$loc
		);
		
		$template->output();
	} else {
		if (DEBUG) {
			pathos_debug_message(1,"No calendar event found for (id:".$_GET['id'].")");
		}
		echo SITE_404_HTML;
	}
// END PERM CHECK

if (DEBUG) {
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>