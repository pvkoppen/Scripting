<?php

return array(
	"modules/contactmodule/actions/contact.php"=>"09ddac0846938ff000d137f901f9bde0",
	"modules/contactmodule/actions/edit_contact.php"=>"971a03278962c29c6cde6aca6273db94",
	"modules/contactmodule/actions/manage_contacts.php"=>"2fcf11249ea0f863a34a8f70ce191491",
	"modules/contactmodule/actions/save_contact.php"=>"1318ef918106b16102d6492eb6317846",
	"modules/contactmodule/actions/delete_contact.php"=>"cf86ec2329f55139a62174612a497df4",
	"modules/contactmodule/class.php"=>"96fb3926c159df72bd0115d6604bd26d",
	"modules/contactmodule/views/Default.tpl"=>"4debd96a712970dabe36c76fbacadcda",
	"modules/contactmodule/views/_contactmanager.tpl"=>"4dc0d844cce5c9a1ca952ff5fbfa3e90",
	"modules/contactmodule/views/_Default.tpl"=>"d0f49f67c716acfa26a03573eb4147fc",
	"modules/contactmodule/views/_standard.tpl"=>"9d3ff784283c03662c6bfbd8429e7852",
	"modules/contactmodule/views/_form_edit_contact.tpl"=>"2d856647765195b6fcbe0af7bd3bf505",
	"datatypes/definitions/contact_contact.php"=>"705c3779f6651058b970dafdddd98bea",
	"datatypes/definitions/contactmodule_config.php"=>"98f1163ad315d839f4765dde780b98ed",
	"datatypes/contactmodule_config.php"=>"dbbef3d4a3ca54db57989540c337592f",
	"datatypes/contact_contact.php"=>"9ad506ff17ac9a06923ee9b2dff5ea9f",
);
?>
