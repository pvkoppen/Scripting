<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: delete_contact.php,v 1.4 2004/10/29 00:16:30 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("contactmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to delete a contact (id:".$_GET['id'].")");
	pathos_debug_message(1,"Running the 'delete_contact' action");
}

$contact = $db->selectObject("contact_contact","id=".$_GET['id']);
if ($contact) {
	$loc = unserialize($contact->location_data);
	
	if (DEBUG) {
		pathos_debug_message(1,"Found a contact to delete");
		pathos_debug_message(2,pathos_debug_dump($contact,"contact"));
		
		pathos_debug_message(1,"Overwrote passed location with contact's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		#pathos_debug_message(1,"Generated internal location from contact.");
		#pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
		
		pathos_debug_message(1,"Will check 'configure' permission on module (\$loc)");
		pathos_debug_message(0,"Checking permissions");
	}
	
	
	if (pathos_permissions_check("configure",$loc)) {
		if (DEBUG) pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
	
		$db->delete("contact_contact","id=".$contact->id);
		
		if (DEBUG) pathos_debug_message(1,"Deleted contact from the database");
		
		if (!DEBUG) pathos_flow_redirect();
	} else if (DEBUG) {
		pathos_debug_message(0,"Permissions check failed.  Action will not execute");
	}
} else {
	if (DEBUG) pathos_debug_message(0,"No contact found with specified id (".$_GET['id'].")");
	echo SITE_404_HTML;
}

if (DEBUG) {
	pathos_debug_backLink();
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>