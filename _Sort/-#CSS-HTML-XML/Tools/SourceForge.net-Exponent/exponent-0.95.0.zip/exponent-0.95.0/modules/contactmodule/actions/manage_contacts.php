<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: manage_contacts.php,v 1.4 2004/10/29 00:16:30 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("contactmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to manage contacts");
	pathos_debug_message(1,"Running the 'manage_contacts' action");
	pathos_debug_message(1,"Will check 'configure' permission on module (\$loc)");
	pathos_debug_message(0,"Checking permissions");
}

if (pathos_permissions_check("configure",$loc)) {
	if (DEBUG) {
		pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
		pathos_debug_message(1,"Calling flow subsystem to register this action as a standalone page.");
	}
	
	pathos_flow_set(SYS_FLOW_PROTECTED,SYS_FLOW_ACTION);

	$contacts = array();
	if (!defined("SYS_USERS")) include_once(BASE."subsystems/users.php");
	
	foreach ($db->selectObjects("contact_contact","location_data='".serialize($loc)."'") as $c) {
		if ($c->user_id != 0) {
			$u = pathos_users_getUserById($c->user_id);
			$c->email = $u->email;
			$c->name = $u->firstname . " " . $u->lastname;
			if ($c->name == "") $c->name = $u->username;
		} else {
			$c->name = "<i>&lt;none&gt;</i>";
		}
		$contacts[] = $c;
	}
	
	if (DEBUG) {
		pathos_debug_message(1,"Read contacts from database.  Found " . count($contacts) . " contact(s)");
		pathos_debug_message(2,pathos_debug_dump($contacts,"contacts"));
	}
	
	$template = new template("contactmodule","_contactmanager");
	$template->assign("contacts",$contacts);
	$template->assign("linkbase","?module=contactmodule&src=".$loc->src."&int=".$loc->int."&action=");
	$template->output();
} else if (DEBUG) {
	pathos_debug_message(0,"Permissions check failed.  Action will not execute");
}

if (DEBUG) {
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>