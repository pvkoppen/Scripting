<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: save_contact.php,v 1.4 2004/10/29 00:16:30 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("contactmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to save a contact");
	pathos_debug_message(1,"Running the 'save_contact' action");
}

$contact = null;
if (isset($_POST['id'])) {
	$contact = $db->selectObject("contact_contact","id=".$_POST['id']);
	if ($contact) $loc = unserialize($contact->location_data);
	
	if (DEBUG) {
		pathos_debug_message(1,"Found an id in POST.  Performing an edit on (id:".$_POST['id'].")");
		
		pathos_debug_message(2,"Existing contact to edit:");
		pathos_debug_message(2,pathos_debug_dump($contact,"contact"));
		
		pathos_debug_message(1,"Overwrote passed location with contact's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		#pathos_debug_message(1,"Generated internal location from contact.");
		#pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
	}
} else if (DEBUG) {
	pathos_debug_message(1,"No id was found in POST.  Posting a new contact");
}

if (DEBUG) {
	pathos_debug_message(1,"Will check 'configure' permission on module (\$loc)");
	pathos_debug_message(0,"Checking permissions");
}

if (pathos_permissions_check("configure",$loc)) {
	if (DEBUG) pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
	
	$contact = contact_contact::update($_POST,$contact);
	$contact->location_data = serialize($loc);
	
	if (DEBUG) {
		pathos_debug_message(1,"Updated contact object from POST data");
		pathos_debug_message(2,pathos_debug_dump($contact,"contact"));
	}
	
	if (isset($contact->id)) {
		if (DEBUG) pathos_debug_message(1,"The id attribute was set; performing a database UPDATE statement");
		$db->updateObject($contact,"contact_contact");
	} else {
		if (DEBUG) pathos_debug_message(1,"No id attribute was present; performing a database INSERT statement");
		$db->insertObject($contact,"contact_contact");
	}
	
	if (!DEBUG) pathos_flow_redirect();
}

if (DEBUG) {
	pathos_debug_backLink();
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>