<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: edit_contact.php,v 1.6 2004/10/29 00:16:30 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("contactmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to edit / post a contact");
	pathos_debug_message(1,"Running the 'edit_contact' action");
}

$contact = null;
if (isset($_GET['id'])) {
	$contact = $db->selectObject("contact_contact","id=".$_GET['id']);
	if ($contact) $loc = unserialize($contact->location_data);
	
	if (DEBUG) {
		pathos_debug_message(1,"Found an id in GET.  Performing an edit on (id:".$_GET['id'].")");
		
		pathos_debug_message(2,"Existing contact to edit:");
		pathos_debug_message(2,pathos_debug_dump($contact,"contact"));
		
		pathos_debug_message(1,"Overwrote passed location with contact's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		#pathos_debug_message(1,"Generated internal location from contact.");
		#pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
	}
} else if (DEBUG) {
	pathos_debug_message(1,"No id was found in GET.  Posting a new contact");
}

if (DEBUG) {
	pathos_debug_message(1,"Will check 'configure' permission on module (\$loc)");
	pathos_debug_message(0,"Checking permissions");
}

if (pathos_permissions_check("configure",$loc)) {
	if (DEBUG) pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
	
	$form = contact_contact::form($contact);
	$form->location($loc);
	$form->meta("action","save_contact");
	
	if (DEBUG) {
		pathos_debug_message(1,"Generated form to edit / post contact");
		pathos_debug_message(2,pathos_debug_dump($form,"form"));
	}
	
	$template = new template("contactmodule","_form_edit_contact");
	$template->assign("form_html",$form->toHTML());
	$template->assign("is_edit",isset($_GET['id']));
	$template->output();
} else if (DEBUG) {
	pathos_debug_message(0,"Permissions check failed.  Action will not execute");
}

if (DEBUG) {
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>