<?php

return array(
	"modules/containermodule/actions/delete.php"=>"9b4e4cee7efe1aff3a7772883e4857e1",
	"modules/containermodule/actions/edit.php"=>"3cecc1e8275fcd5f81844c0b0ee605cf",
	"modules/containermodule/actions/order.php"=>"978662b7ef1185efbb98b13d38bff267",
	"modules/containermodule/actions/save.php"=>"e4bcee3560fbce22317727b751e263b3",
	"modules/containermodule/actions/delete_content.php"=>"fa45c5f997bb47f79fa4e96ae69081ab",
	"modules/containermodule/actions/orphans_modules.php"=>"b232887d11a6d0839238c5910f7794ca",
	"modules/containermodule/actions/orphans_content.php"=>"288e42a031ae5c08d51785934cb06ac8",
	"modules/containermodule/class.php"=>"54935f9604f747513644a7eeda8d8041",
	"modules/containermodule/views/Default.tpl"=>"b475ba5a1d8f989ef9e2e933e2c66f09",
	"modules/containermodule/views/_sourcePicker.tpl"=>"6a1cebde039f2b12e26d4eac4af638ba",
	"modules/containermodule/views/_form_edit.tpl"=>"fed265a350f73c756866baa9d412b16a",
	"modules/containermodule/views/_nocontent.tpl"=>"4d6c283f69858ec20be23f677881ab8c",
	"modules/containermodule/views/_lastreferencedelete.tpl"=>"60a3c1b67d9b90ac262f8d01bd399075",
	"modules/containermodule/views/_orphans_modules.tpl"=>"fade2660c796ad5635a9bb059a7c98b9",
	"datatypes/container.php"=>"e45487e29c72d108bdcdfa9513f000b8",
	"datatypes/definitions/container.php"=>"3fdd2f0ae84febf2650bd5df8dc2694f",
	"datatypes/definitions/locationref.php"=>"bc48197c89ffd286bf41db6db67bc697",
	"datatypes/definitions/sectionref.php"=>"4613c57c3892525700795c2d6c30e559",
);
?>
