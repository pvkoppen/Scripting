<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: save.php,v 1.8 2004/10/29 00:17:28 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("addressbookmodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to save a module to a container");
	pathos_debug_message(1,"Running the 'save' action");
}

$container = null;
$iloc = null;
$cloc = null;
if (isset($_POST['id'])) $container = $db->selectObject("container","id=" . $_POST['id']);
if ($container != null) {
	$iloc = unserialize($container->internal);
	$loc = unserialize($container->external);
	$cloc = unserialize($container->external);
	$cloc->int = $container->id;
	
	if (DEBUG) {
		pathos_debug_message(1,"Found an id in POST.  Performing an edit on (id:".$_POST['id'].")");
		pathos_debug_message(1,"Will check 'edit' permission on module and existing contact (\$loc and \$iloc)");
		
		pathos_debug_message(2,"Existing container to update:");
		pathos_debug_message(2,pathos_debug_dump($container,"container"));
		
		pathos_debug_message(1,"Overwrote passed location with container's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		pathos_debug_message(1,"Generated internal location from container.");
		pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
		
		pathos_debug_message(1,"Generated module location from contained module.");
		pathos_debug_message(2,pathos_debug_dump($cloc,"cloc"));
	}
} else if (DEBUG) {
	pathos_debug_message(1,"No id was found in POST.  Saving a new module");
	pathos_debug_message(1,"Will check 'post' permission on module (\$loc)");
}

if (DEBUG) pathos_debug_message(0,"Checking permissions");

if (	pathos_permissions_check("add_module",$loc) || 
	($iloc != null && pathos_permissions_check("administrate",$iloc)) ||
	($cloc != null && pathos_permissions_check("edit_module",$cloc))
	) {
	
	if (DEBUG) pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
	
	$container = container::update($_POST,$container,$loc);
	
	if (DEBUG) {
		pathos_debug_message(1,"Updated container object from POST data");
		pathos_debug_message(2,pathos_debug_dump($container,"container"));
	}

	if (isset($container->id)) {
		if (DEBUG) pathos_debug_message(1,"The id attribute was set; performing a database UPDATE statement");
		$db->updateObject($container,"container");
	} else {
		if (DEBUG) pathos_debug_message(1,"No id attribute was present; performing a database INSERT statement");
		$db->insertObject($container,"container");
	}
	
	if ($container->is_existing == 0) {
		$iloc = unserialize($container->internal);
		$locref = $db->selectObject("locationref","module='".$iloc->mod."' AND source='".$iloc->src."'");
		$locref->description = $_POST['description'];
		$db->updateObject($locref,"locationref","module='".$iloc->mod."' AND source='".$iloc->src."'");
		
		if (DEBUG) {
			pathos_debug_message(0,"Creating new location.");
			pathos_debug_message(1,"Found locationref of existing module");
			pathos_debug_message(2,pathos_debug_dump($locref,"locref"));
			pathos_debug_message(1,"Updated locationref to reflect new description");
		}
	}
	
	pathos_template_clear();
	if (!DEBUG) pathos_flow_redirect();
}

if (DEBUG) {
	pathos_debug_backLink();
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>