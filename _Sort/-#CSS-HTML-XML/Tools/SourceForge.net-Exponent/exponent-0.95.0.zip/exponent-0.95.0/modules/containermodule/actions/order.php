<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: order.php,v 1.4 2004/10/29 00:17:28 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("containermodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to order contained modules");
	pathos_debug_message(1,"Running the 'order' action");
	pathos_debug_message(1,"Will check 'order_modules' on module (\$loc)");
	pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
	pathos_debug_message(0,"Checking permissions");
}

if (pathos_permissions_check("order_modules",$loc)) {
	$a = $db->selectObject("container","external='".serialize($loc)."' AND rank=".$_GET['a']);
	$b = $db->selectObject("container","external='".serialize($loc)."' AND rank=".$_GET['b']);
	
	if (DEBUG) {
		pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
		pathos_debug_message(1,"Read both container records from database");
		pathos_debug_message(2,pathos_debug_dump($a,"a"));
		pathos_debug_message(2,pathos_debug_dump($b,"b"));
	}
	
	$tmp = $a->rank;
	$a->rank = $b->rank;
	$b->rank = $tmp;
	
	$db->updateObject($a,"container");
	$db->updateObject($b,"container");
	
	pathos_template_clear();
	
	if (DEBUG) {
		pathos_debug_message(1,"Switched ranks on both containers");
	} else {
		pathos_flow_redirect();
	}
} else if (DEBUG) {
	pathos_debug_message(0,"Permissions check failed.  Action will not execute");
}

if (DEBUG) {
	pathos_debug_backLink();
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>