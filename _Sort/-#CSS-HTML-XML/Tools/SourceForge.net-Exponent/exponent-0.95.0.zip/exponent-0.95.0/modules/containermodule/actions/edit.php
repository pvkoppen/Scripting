<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: edit.php,v 1.11 2004/11/23 09:21:03 cvs Exp $
##################################################

if (!defined("PATHOS")) exit("");

if (DEBUG) {
	$__olddebug = pathos_debug_setContext("containermodule");
	pathos_debug_clear();
	pathos_debug_message(0,"Attempting to edit / post a new module");
	pathos_debug_message(1,"Running the 'edit' action");
}

$container = null;
$iloc = null;
$cloc = null;
if (isset($_GET['id'])) {
	$container = $db->selectObject("container","id=".$_GET['id']);
	if ($container != null) {
		$iloc = unserialize($container->internal);
		$cloc = unserialize($container->external);
		$cloc->int = $container->id;
	}
	
	if (DEBUG) {
		pathos_debug_message(1,"Found an id in GET.  Performing an edit on (id:".$_GET['id'].")");
		pathos_debug_message(1,"Will check 'edit' permission on module and existing container (\$loc and \$iloc)");
		pathos_debug_message(1,"Will check 'administrate' permission on contained module (\$cloc)");
		
		pathos_debug_message(2,"Existing container to edit:");
		pathos_debug_message(2,pathos_debug_dump($container,"container"));
		
		pathos_debug_message(1,"Overwrote passed location with container's stored location");
		pathos_debug_message(2,pathos_debug_dump($loc,"loc"));
		
		pathos_debug_message(1,"Generated internal location from container.");
		pathos_debug_message(2,pathos_debug_dump($iloc,"iloc"));
		
		pathos_debug_message(1,"Generated contained module location from container.");
		pathos_debug_message(2,pathos_debug_dump($cloc,"cloc"));
	}
} else {
	if (DEBUG) {
		pathos_debug_message(1,"No id was found in GET.  Posting a new contact");
		pathos_debug_message(1,"Will check 'post' permission on module (\$loc)");
		pathos_debug_message(1,"Setting rank for new container record to ".$_GET['rank']);
	}
	
	$container->rank = $_GET['rank'];
}

if (DEBUG) pathos_debug_message(0,"Checking permissions");

if (	pathos_permissions_check("edit_module",$loc) || pathos_permissions_check("add_module",$loc) ||
	($iloc != null && pathos_permissions_check("administrate",$iloc)) ||
	($cloc != null && pathos_permissions_check("delete_module",$cloc))
) {
	if (DEBUG) pathos_debug_message(0,"Permissions check succeeded.  Action can continue executing");
	#
	# Initialize Container, in case its null
	#
	$locref = null;
	if (!isset($container->id)) {
		$locref->description = "";
		$container->view = "";
		$container->internal = pathos_core_makeLocation();
		$container->title = "";
		$container->rank = $_GET['rank'];
		
		if (DEBUG) {
			pathos_debug_message(1,"Initialized container record to defaults");
			
			pathos_debug_message(2,"Location Reference:");
			pathos_debug_message(2,pathos_debug_dumpObject($locref,"locref"));
			
			pathos_debug_message(2,"Container Record:");
			pathos_debug_message(2,pathos_debug_dumpObject($container,"container"));
		}
	} else {
		if (DEBUG) pathos_debug_message(1,"Getting location reference from internal of container");
		
		$container->internal = unserialize($container->internal);
		$locref = $db->selectObject("locationref","module='".$container->internal->mod."' AND source='".$container->internal->src."'","container_edit");
	}
	
	$template = new template("containermodule","_form_edit");
	$template->assign("rerank",(isset($_GET['rerank']) ? 1 : 0));
	$template->assign("container",$container);
	$template->assign("locref",$locref);
	$template->assign("is_edit",isset($container->id));
	
	if (!defined("SYS_JAVASCRIPT")) include_once(BASE."subsystems/javascript.php");
	$haveclass = false;
	$mods = array();
	
	$modules_list = (isset($container->id) ? pathos_modules_list() : pathos_modules_listActive());
	
	if (!count($modules_list)) { // No active modules
		$form = new form();
		$form->register("notice","",new htmlcontrol("The system administrators have deactivated all modules.  You will not be able to add a new one."));
		return $form;
	}
	
	usort($modules_list,"pathos_sorting_moduleClassByNameAscending");
	
	$js_init = "<script type='text/javascript'>";
		
	foreach ($modules_list as $moduleclass) {
		$module = new $moduleclass();
		
		$mod = null;
		
		// Get basic module meta info
		$mod->name = $module->name();
		$mod->author = $module->author();
		$mod->description = $module->description();
		if (isset($container->view) && $container->internal->mod == $moduleclass) {
			$mod->defaultView = $container->view;
		} else $mod->defaultView = "";
		
		// Get support flags
		$mod->supportsSources = ($module->hasSources() ? 1 : 0);
		$mod->supportsViews  = ($module->hasViews()   ? 1 : 0);
		
		// Get a list of views
		$mod->views = pathos_modules_views($moduleclass);
		natsort($mod->views);
		
		// Get a list of existing sources
		$mod->existingSources = pathos_modules_sources($moduleclass);
		$mod->existingSourcesInternal = array_keys($mod->existingSources);
		
		// Get a list of previews
		$mod->previews = pathos_modules_previews($moduleclass,$mod->views);
		
		if (!$haveclass) {
			$js_init .=  pathos_javascript_class($mod,"Module");
			$js_init .=  "var modules = new Array();\n";
			$js_init .=  "var modnames = new Array();\n\n";
			$haveclass = true;
		}
		$js_init .=  "modules.push(" . pathos_javascript_object($mod,"Module") . ");\n";
		$js_init .=  "modnames.push('" . $moduleclass . "');\n";
		$mods[$moduleclass] = $module->name();
	}
	$js_init .= "\n</script>";
	
	$template->assign("js_init",$js_init);
	$template->assign("modules",$mods);
	$template->assign("loc",$loc);
	$template->assign("back",pathos_flow_get());
	
	$template->output();	
}  else if (DEBUG) {
	pathos_debug_message(0,"Permissions check failed.  Action will not execute");
}

if (DEBUG) {
	pathos_debug_output();
	pathos_debug_clear();
	pathos_debug_setContext($__olddebug);
}

?>