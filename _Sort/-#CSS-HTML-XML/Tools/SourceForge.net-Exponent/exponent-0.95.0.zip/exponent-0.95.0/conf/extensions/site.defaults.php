<?php

##################################################
#
# Copyright 2004 James Hunt and OIC Group, Inc.
#
# This file is part of Exponent
#
# Exponent is free software; you can redistribute
# it and/or modify it under the terms of the GNU
# General Public License as published by the Free
# Software Foundation; either version 2 of the
# License, or (at your option) any later version.
#
# Exponent is distributed in the hope that it
# will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU
# General Public License along with Exponent; if
# not, write to:
#
# Free Software Foundation, Inc.,
# 59 Temple Place,
# Suite 330,
# Boston, MA 02111-1307  USA
#
# $Id: site.defaults.php,v 1.10 2004/10/29 00:48:09 cvs Exp $
##################################################

if (!defined("SITE_TITLE")) define("SITE_TITLE","My New Exponent Site");
if (!defined("SITE_ALLOW_REGISTRATION")) define("SITE_ALLOW_REGISTRATION",1);
if (!defined("SITE_404_HTML")) define("SITE_404_HTML",html_entity_decode("<h3>Resource Not Found</h3>The resource you were looking for wasn&apos;t found.  It may have been deleted, or moved."));
if (!defined("SITE_KEYWORDS")) define("SITE_KEYWORDS","");
if (!defined("SITE_DESCRIPTION")) define("SITE_DESCRIPTION","");
if (!defined("SITE_DEFAULT_SECTION")) define("SITE_DEFAULT_SECTION",1);
if (!defined("SESSION_TIMEOUT")) define("SESSION_TIMEOUT",3600);

?>