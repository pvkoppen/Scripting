<?php

define("DB_NAME","dbname");
define("DB_USER","dbuser");
define("DB_PASS","dbpass");
define("DB_HOST","localhost");
define("DB_PORT","3306");
define("DB_TABLE_PREFIX","exponent_");
define("DISPLAY_THEME_REAL","defaulttheme");
define("DISPLAY_ATTRIBUTION","realname");
define("SITE_TITLE","My New Exponent Site");
define("SITE_KEYWORDS","");
define("SITE_DESCRIPTION","");
define("SITE_ALLOW_REGISTRATION",1);

?>
<?
define("CURRENTCONFIGNAME","");
?>
