#Author	: Ruud Baars
#Date	: 11/09/2008

#deletes all recovery points before 'now' on selected data source an creates new  express full recovery-point
#No conformations
$version="V4.2" 
#display RP's to delete and ask to continue. Also ask to make express full RP.
#Check & wait data source to be idle else removal may fail (in Mojito filter on 'intent' to see the error)
#Fixed prune default and logfile name and some logging lines (concatenate question + answer)
#Check dependent recovery points do not pass BEFORE date and adjust selection to not select those ($reselect)
#--- Fixed reselect logic to keep adjusting reselect for as long as older than BEFORE date
#--- Fixed post removal rechecking logic to match what is done so far (was still geared to old logic)
#--- Fixed $ds=$ds+ if not array returned
# ---v4.2 Added choice to create new recovery point on disk or tape (there may not be disk protection)


$MB=1024*1024
$logfile="DPMdeleteRP.LOG"
$wait=10	#seconds

function Show_help
{
	cls
	$l="=" * 79
	write-host $l -foregroundcolor magenta
	write-host -nonewline "`t<<<" -foregroundcolor white
	write-host -nonewline " DANGEROUS :: MAY DELETE MANY RECOVERY POINTS " -foregroundcolor red
	write-host ">>>" -foregroundcolor white
	write-host $l -foregroundcolor magenta
	write-host "Version: $version" -foregroundcolor cyan
    	write-host "A: User Selects data source to remove recovery points for" -foregroundcolor green
	write-host "B: User Selects whether or not remove tape recovery points" -foregroundcolor green
	write-host "C: User Selects whether or not remove recovery points from the beginning" -foregroundcolor green
	write-host "D: User enters date / time (using 24hr clock) to Delete recovery points" -foregroundcolor green
	write-host "E: Optionally creates another recovery point using express full" -foregroundcolor green
	write-host "F: Optionally executes pruning job`n " -foregroundcolor green	
	write-host "Appending to log file $logfile`n" -foregroundcolor white
	write-host "User Accepts all responsibilities by entering a data source or just pressing [Enter] " -foregroundcolor white -backgroundcolor blue

}
function ShortToTape {
	# return $true if ShortTerm if short on tape possible
	param ($pgroup)
	$popts = @($pgroup.protectionmethod.split("|"))
	foreach ($opt in $popts) {
		if (($opt -imatch "short") -and ($opt -imatch "tape")) {return $true}
	}
	return $false
}

"**********************************" >> $logfile
"Version $version" >> $logfile
get-date >> $logfile
show_help

$DPMservername=&"hostname"
"Selected DPM server = $DPMservername" >> $logfile
write-host "`nConnnecting to DPM server retrieving data source list...`n" -foregroundcolor green
$pglist = Get-ProtectionGroup $DPMservername
$ds=@()
$tapes=@()
foreach ($onepg in $pglist) {$ds += (get-datasource $onepg); $tapes += (Get-Tape -ProtectionGroup $onepg)} 
if ( Get-Datasource $DPMservername -inactive) {$ds+=Get-Datasource $DPMservername -inactive}

$i=0
foreach ($l in $ds) {
	"[{0}] {1} `t`t {2}" -f $i,$l.psinfo.netbiosname, $l.logicalpath
	$i++
	}
$DSname=read-host "`nEnter a data source index from list above "

if (!$DSname) 
{
	write-host "No datasource selected `n" -foregroundcolor yellow
	"Aborted on Datasource name" >> $logfile
	exit 0
}
$DSselected=$ds[$DSname]
$PGselected=$pglist | where {$_.FriendlyName -eq $DSselected.protectiongroupname}

"Selected datasource = $DSselected" >> $logfile
Write-Host "`n`nSelected"-foregroundcolor yellow
$DSselected

if (!$DSselected) 
{
	write-host "No datasource selected `n" -foregroundcolor yellow
	"Aborted on Datasource name" >> $logfile
	exit 0
}
$DoTape=read-host "`nDo you want to remove when recovery points are on tape ? [y/N]"
"Remove tape recovery point = $DoTape" >> $logfile

write-host "`nCollecting recoverypoint information for datasource $DSselected.name" -foregroundcolor green
if ($DSselected.ShadowCopyUsedspace -gt 0)
{
	#this is on disk
	$oldShadowUsage=[math]::round($DSselected.ShadowCopyUsedspace/$MB,1)
	$line=("Total recoverypoint usage {0} MB on DISK in {1} recovery points" -f $oldShadowUsage ,$DSselected.TotalRecoveryPoints  ) 
	$line >> $logfile
	write-host $line`n -foregroundcolor white
}

#this is on tape
$trptot=0
$tp= Get-RecoveryPoint($dsselected) | where {($_.Datalocation -eq "Media")}
foreach ($trp in $tp) {$trptot += $trp.size }
if ($trptot -gt 0 )
{
	$line=("Total recoverypoint usage {0} MB on TAPE in {1} recovery points" -f ($trptot/$MB) ,$DSselected.TotalRecoveryPoints  ) 
	$line >> $logfile
	write-host $line`n -foregroundcolor white		
}

[datetime]$afterdate="1/1/1980"
$answer=read-host "`nDo you want to delete recovery points from the beginning [Y/n]" 
if ($answer -eq "n" )
{
	[datetime]$afterdate=read-host "Delete recovery points AFTER date [MM/DD/YYYY hh:mm]"
}
[datetime]$enddate=read-host "Delete recovery points BEFORE date [MM/DD/YYYY hh:mm]" 
"Deleting recovery points between $afterdate and $enddate" >>$logfile
write-host "Deleting recovery points between $afterdate and $enddate" -foregroundcolor yellow
$rp=get-recoverypoint $DSselected
if ($DoTape -ne "y" )
{
	$RPselected=$rp | where {($_.representedpointintime -gt $afterdate)-and ($_.representedpointintime -lt $enddate) -and ($_.Isincremental -eq $FALSE)-and ($_.DataLocation -eq "Disk")}
}
else
{
	$RPselected=$rp | where {($_.representedpointintime -gt $afterdate)-and ($_.representedpointintime -lt $enddate) -and ($_.Isincremental -eq $FALSE)}
}

if (!$RPselected) 
{
	write-host "No recovery points found!" -foregroundcolor yellow
	"No recovery points found, aborting...!" >> $logfile
	exit 0
}
$reselect = $enddate
$adjustflag = $false
foreach ($onerp in $RPselected)
{
	$rtime=[string]$onerp.representedpointintime
	$rsize=[math]::round(($onerp.size/$MB),1)
	$line= "Found {0} size {1} Incremental={2} "-f $rtime, $rsize,$onerp.Isincremental
        $line >> $logfile
	write-host "$line" -foregroundcolor yellow
	#
	#Get dependent rp's for data source
	#
	$allRPtbd=$DSselected.GetAllRecoveryPointsToBeDeleted($onerp)
	foreach ($oneDrp in $allRPtbd)
	{
		if ($oneDrp.IsIncremental -eq $FALSE) {continue}
		$rtime=[string]$oneDrp.representedpointintime
		$rsize=[math]::round(($oneDrp.size/$MB),1)
		$line= ("`t...is dependancy for {0} size {1} `tIncremental={2}" -f $rtime, $rsize, $oneDrp.Isincremental) 
		$line >> $logfile
		if ($oneDrp.representedpointintime -ge $enddate)
		{
			#stick to latest full ($oneDrp = dependents, $onerp = full)
			$adjustflag = $true
			$reselect = $onerp.representedpointintime
			"<< Dependents newer than BEFORE date >>>" >> $logfile
			Write-Host -nonewline "`t <<< later than BEFORE date >>>" -foregroundcolor white -backgroundcolor red
			write-host "$line" -foregroundcolor yellow
		}
		else
		{
			#Ok, include current latest incremental
			$reselect = $oneDrp.representedpointintime
        	write-host "$line" -foregroundcolor yellow
		}
	}
}
if ($reselect -lt $oneDrp.representedpointintime) 
{
	#we adjusted further backward than latest incremental within selection
	$line =  "Adjusted BEFORE date backward to $reselect to avoid deleting dependents newer than $enddate"
	$line >> $logfile
	Write-Host $line -foregroundcolor white -backgroundcolor blue
}
$line="`n<<< LAST CHANCE TO ABORT >>>"
write-host $line  -foregroundcolor white -backgroundcolor blue
$line >> $logfile
$line="Above recovery points within adjusted range will be permanently deleted !!!"
write-host $line -foregroundcolor red
$line >> $logfile
$line="These RP's include dependent recovery points"
write-host $line -foregroundcolor red 
$line >> $logfile
$line="Data source activity = " + $DSselected.Activity
$line >> $logfile
write-host $line -foregroundcolor white
$DoDelete=""
while (($DoDelete -ne "N" ) -and ($DoDelete -ne "Y"))
{
	$line="Continue with deletion (must answer) Y/N? "
	write-host $line -foregroundcolor white
	$DoDelete=read-host
	$line = $line + $DoDelete
	$line >> $logfile
}

if (!$DSselected.Activity -eq "Idle") 
{
	$line="Data source not idle, do you want to wait Y/N ? "
	write-host $line -foregroundcolor yellow
	$Y=read-host
	$line = $line + $Y
	$line >> $logfile
	if ($Y -ieq "Y") 
	{
		Write-Host "Waiting for data source to become idle..."  -foregroundcolor green
		while ($DSselected.Activity -ne "Idle")
		{
			("Waiting {0} seconds" -f $wait) >>$logfile
			Write-Host -NoNewline "..." -ForegroundColor blue
			start-sleep -s $wait
		}
	}
}

if ($DoDelete -eq "Y")
{
   foreach ($onerp in $RPselected)
	{
		#reselect is adjusted to safe range relative to what was requested
		#--- if adjustflag not set then all up to including else only older because we must keep the full
		if ((($onerp.representedpointintime -le $reselect) -and ($adjustflag -eq $false)) -or ($onerp.representedpointintime -lt $reselect))
		{
			$rtime=[string]$onerp.representedpointintime
			$line =("---`nDeleting recoverypoint -> " + $rtime)
			write-host `n$line -foregroundcolor red
			$line >>$logfile
			if (($onerp ) -and ($onerp.IsIncremental -eq $FALSE)) { remove-recoverypoint -RecoveryPoint $onerp -confirm:$FALSE >> $logfile}
		}
	}
	
	#re-get objects and re-check no more rp's
	"Re-checking recovery points..." >> $logfile
	write-host "`nRe-checking recovery points..." -foregroundcolor white
	$pglist = Get-ProtectionGroup $DPMservername
	$ds =@(Get-Datasource $DPMservername -inactive)
	
	foreach ($onepg in $pglist) {$ds=$ds+ (get-datasource $onepg)}
	$DSselected=$ds[$DSname]
	$rp=get-recoverypoint $DSselected
	if ($DoTape -ne "y" )
	{
		$RPselected=$rp | where {($_.representedpointintime -gt $afterdate)-and ($_.representedpointintime -lt $reselect) -and ($_.Isincremental -eq $FALSE)-and ($_.DataLocation -eq "Disk")}
	}
	else
	{
		$RPselected=$rp | where {($_.representedpointintime -gt $afterdate)-and ($_.representedpointintime -lt $reselect) -and ($_.Isincremental -eq $FALSE)}
	}
	if (!$RPselected)
	{
	 	write-host "PASS: no more recovery points found to remove" -foregroundcolor green
		"PASS: no more recovery points found to remove" >> $logfile	
	}
	else
	{		
		#Hey... we should not have got anything
		$line = ("ERROR: expected nothing but still found {0} recovery points to remove" -f $RPselected.count)
		write-host $line -foregroundcolor yellow
		$line >> $logfile
	}
}
 else
{
"Nothing left to do!" >> $logfile
write-host "`nNothing left to do!`n`n" -foregroundcolor white
 exit 0
}
$newShadowUsage=[math]::round($DSselected.ShadowCopyUsedspace/$MB,1)
$reclaimedShadowUsage=[math]::round($oldShadowUsage-$newShadowUsage,1)
write-host "`nTotal reclaimed $reclaimedShadowUsage MB on disk" -foregroundcolor green
 "Total reclaimed $reclaimedShadowUsage MB"  >>$logfile

$DoExpress=read-host "Would you like to create a new recovery point now Y/n ? "
"Would you like to create a new express full recovery point now  = $DoExpress" >> $logfile

$DoPrune=read-host "Would you like to run pruning now y/N ? "
"Would you like to run pruning now  = $DoPrune" >> $logfile

if ($DoExpress -ne "n")
{
	$DoRPtape="N"
	if ($PGselected.PGProtectionType -imatch "tape") {
		$DoRPtape=read-host "Would you like to create a new recovery point on Tape  y/N ? "
		"Would you like to create a new recovery point on Tape  y/N ? $DoRPtape " >> $logfile
	}
	write-host "Creating new express full recovery point ..." -foregroundcolor green
	if ($DoRPtape -ne "y") {
			$j= New-RecoveryPoint -Datasource $DSselected -Disk  -BackupType expressfull
	}
	else {
		#if doing a new recovery point after removing then short term wil be the goal if possible
		#if removing all need to do a short term first anyway
		if (ShortToTape $PGselected) {
			$j= New-RecoveryPoint -Datasource $DSselected -Tape -ProtectionType "ShortTerm"
		}
		else  {$j= New-RecoveryPoint -Datasource $DSselected -Tape -ProtectionType "LongTerm"}
	}
	("Started new recovery point at {0}" -f $j.starttime) >>$logfile
	$j >> $logfile
	write-host ("Jobtype: {0} `nStatus: {1} `nHasCompleted: {2}" -f $j.jobtype, $j.status, $j.hascompleted) -foregroundcolor cyan
	write-host "`n`nWaiting for job to complete checking each $wait seconds... " -foregroundcolor green
	while ($j.hascompleted -eq $FALSE)
	{
		write-host -nonewline "..."  -foregroundcolor blue
		start-sleep -s $wait
	}
	$j >> $logfile
	write-host ("`nJobtype: {0} `nStatus: {1} `nHasCompleted: {2}" -f $j.jobtype, $j.status, $j.hascompleted) -foregroundcolor cyan
	"Finished expres full" >> $logfile
	write-host "`nFinished express full!`n" -foregroundcolor yellow
}
if ($doprune -eq "Y")
{

	$myprune=Get-Item ".\RBpruneshadowcopies.ps1" -ErrorAction "SilentlyContinue"
	if (!$myprune)
	{
		write-host "`nPruning shadow copies using standard prune..." -foregroundcolor white
		"Pruning shadow copies using standard prune" >> $logfile
		.\pruneshadowcopies.ps1
	}
	else
	{
		write-host "`nPruning shadow copies using logging prune..." -foregroundcolor white
		"Pruning shadow copies using logging prune" >> $logfile
		$curverbose=$VerbosePreference
		$VerbosePreference="Continue"
		#This prune version is 1:1 btu uses 'write-error' which can be diverted into file
		&$myprune 2>> $logfile
		$VerbosePreference=$curverbose
	}
	write-host "`nPruning finished!" -foregroundcolor white
	"Pruning shadow copies finished" >> $logfile
}
"All Done!" >> $logfile
write-host "`nAll Done!`n`n" -foregroundcolor white
