#Author: Ruud Baars
#Date 01/31/2010
# Synopsis:
# Reads and saves protection group & data source configuration as XML with the intention to be recreated

param ( 
[string[]]$dpmserverlist = @(),
$configfile = ""
) 

#region traps 
trap [Exception] { 
	writelog $("TRAP: DPMsaveConfig: $Error")
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "DPMsaveConfig"
	$log.WriteEntry("TRAP: DPMsafeConfig: $error", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	write-host $Error -f "magenta"
	write-host $Error[0].InvocationInfo.PositionMessage -ForegroundColor "Magenta"
	$Error.Clear()
	exit 1
}
#endregion
#region functions
function writelog {
	param([string]$msg, $color="Green")
	$msg =  "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	Write-Host $msg -ForegroundColor $color
}
function Showhelp {
	#just help page
	Write-Host -f cyan @("
============================ 
DPMsaveConfig $version usage
============================
[-dpmserverlist dpm1,dpm2]  optional list of DPM servers to save {defaults to localhost only}
	") 
}
function LoadDPMsnapin {
	#load PS snap-in if not already
	param ()
	if (Get-PSSnapin | ?{$_.name -like "Microsoft.DataProtectionManager.PowerShell"}) {
	}
	else {
		Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
	}
} 
function DaysAndTimes {
	param ($xml, $s, $item )
	$t = "";$s.WeekDays | foreach {$t = "$t$_,"}; $t = $t.TrimEnd(",")
	[void]$item.SetAttribute("WeekDays", $t)
	$t = ""; $s.TimesOfDay | foreach {$t = "{0},$t" -f , $_.tostring("HH:mm")}; $t = $t.TrimEnd(",")
	[void]$item.SetAttribute("TimesOfDay", $t)
}
function DoPolicy {
	param($xml, $pol, $POLitem )
	[void]$POLitem.SetAttribute("AllowIncrementals", $pol.AllowIncrementals.ToString())
	[void]$POLitem.SetAttribute("IncrementalSet", $pol.IncrementalSet.ToString())
	[void]$POLitem.SetAttribute("Frequency", $pol.Frequency.ToString())
	[void]$POLitem.SetAttribute("Interval", $pol.Interval.ToString())
	[void]$POLitem.SetAttribute("Mode", $pol.Mode.ToString())
	$RRitem = $xml.CreateElement("RECOVERYRANGE")
	[void]$POLitem.AppendChild($RRitem)
	[void]$RRitem.SetAttribute("Range", $pol.RecoveryRange.Range.ToString()) 
	[void]$RRitem.SetAttribute("Unit", $pol.RecoveryRange.Unit.ToString()) 
	$SCHitem = $xml.CreateElement("SCHEDULES")
	[void]$POLitem.AppendChild($SCHitem)
	foreach ($s in $pol.schedules) {
		$item = $xml.CreateElement($s.JobType)
		[void]$SCHitem.AppendChild($item)
		[void]$item.SetAttribute("JobType", $s.JobType)
		[void]$item.SetAttribute("JobTypeString", $s.JobTypeString)
		switch ($s.JobTypeString.ToString().Trim()){
			"Express full" {DaysAndTimes $xml $s $item}
			"Synchronization" {$item.SetAttribute("Frequency", $s.Frequency)} # = replication
			"Shadow copy" {DaysAndTimes $xml $s $item}
			"Tape backup" { 
				[void]$item.SetAttribute("Frequency", $s.Frequency)
				[void]$item.SetAttribute("Generation", $s.Generation)
				[void]$item.SetAttribute("Interval", $s.Interval)
				[void]$item.SetAttribute("RelativeInterval", $s.RelativeInterval)
				[void]$item.SetAttribute("RelativeWeekday", $s.RelativeWeekDay)
				[void]$item.SetAttribute("ScheduleTime", $s.ScheduleTime.ToString("MM/dd/yyyy hh:mm tt", $cult))
				[void]$item.SetAttribute("Vault", $s.Vault)
				[void]$item.SetAttribute("Weekday", $s.WeekDay) 
			}
			"Consistency check" {
				[void]$item.SetAttribute("StartTime", $s.StartTime.ToString("hh:mm tt"))
				[void]$item.SetAttribute("MaxDuration", $s.MaxDuration)
			}
			default {writelog ("Unexpected job schedule type ->" + $s.JobTypeString) }
		} 
	}
}
function DoDPM {
	param ($xml, $dpmsrv )
	writelog "Using DPMserver $dpmsrv ...`n`n"
	disconnect-dpmserver $dpmsrv
	$srv = Connect-dpmserver $dpmsrv

	$dpmnode = $xml.createelement($dpmsrv)
	[void]$xml.DPMconfig.Appendchild($dpmnode)
	$dpmnode.SetAttribute("Domain", $srv.Domain)
	$dpmnode.SetAttribute("Dpmservername", $dpmsrv)
	$global:dpmversion = $srv.GetProductInformation().Version.Major
	$dpmnode.SetAttribute("DpmMajorVersion", $srv.GetProductInformation().Version.Major) 
	$dpmnode.SetAttribute("DpmMinorVersion", $srv.GetProductInformation().Version.Minor) 
	$dpmnode.SetAttribute("DpmBuild", $srv.GetProductInformation().Version.Build) 

	# save global settings
	writelog "Processing Global properties..."
	$item = $xml.createelement("GLOBALS")
	[void]$dpmnode.appendchild($item)
	$v = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName OptimizeTapeUsage
	[void]$item.SetAttribute("OptimizeTapeUsage", $v)
	$TapeWritePeriodRatio = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName TapeWritePeriodRatio
	[void]$item.SetAttribute("TapeWritePeriodRatio", $TapeWritePeriodRatio.Tostring())
	$v = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName IsNetworkChecksumRequired
	[void]$item.SetAttribute("IsNetworkChecksumRequired", $v) 
	$v = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName TruncateSharePointDbLogs
	[void]$item.SetAttribute("TruncateSharePointDbLogs", $v) 
	$v = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName LibraryRefreshInterval
	[void]$item.SetAttribute("LibraryRefreshInterval", $v) 
	$v = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName ExchangeSCRProtection
	if (!$v) {$v = $false}
	[void]$item.SetAttribute("ExchangeSCRProtection", $v) 
	$v = Get-DPMGlobalProperty -DPMServerName $dpmsrv -PropertyName AllowLocalDataProtection
	[void]$item.SetAttribute("AllowLocalDataProtection", $v) 

	#save specific registry settings
	writelog "Processing Registry entries..."
	$reg = $xml.createelement("REGISTRY")
	[void]$dpmnode.appendchild($reg)
	$keys = $null
	if (test-path 'HKLM:\Software\Microsoft\Microsoft Data Protection Manager\1.0\Colocation') {
		$keys = Get-Item 'HKLM:\Software\Microsoft\Microsoft Data Protection Manager\1.0\Colocation'
		[single]$TapeExpiryTolerance = $keys.GetValue("TapeExpiryTolerance")
	}
	else {
		$TapeExpiryTolerance = 17
	}
	[void]$item.SetAttribute("TapeExpiryTolerance", $TapeExpiryTolerance.Tostring())
	$item = $xml.createelement("TapeSize")
	[void]$reg.appendchild($item)
	[void]$item.SetAttribute("Path", "HKLM:\Software\Microsoft\Microsoft Data Protection Manager\Agent\")
	$keys = $null
	$keys = Get-Item 'HKLM:\Software\Microsoft\Microsoft Data Protection Manager\Agent\'
	$TapeSize = $keys.GetValue("TapeSize")
	if (!$TapeSize) {$TapeSize = 0}
	[void]$item.SetAttribute("Value", $TapeSize.ToString())

	#associated replica list
	$replicalist = $xml.createelement("REPLICALIST")
	[void]$dpmnode.appendchild($replicalist)
	$arl = @()
	$srv.GetDatasourceCollection() | sort type | foreach {$arl += $_}
	writelog ("Processing {0} associated replicas DPM once knew about..." -f $arl.count)
	for ($i = 0; $i -lt $arl.count; $i++) {
		$ar = $xml.CreateElement("AR$i")
		[void]$replicalist.AppendChild($ar)
		[void]$ar.SetAttribute("PhysicalReplicaId", $arl[$i].AssociatedReplica.PhysicalReplicaId)
		[void]$ar.SetAttribute("ReplicaId", $arl[$i].AssociatedReplica.ReplicaId)
		[void]$ar.SetAttribute("DataSourceId", $arl[$i].AssociatedReplica.DatasourceId)
	}
	#tape libs & drives
	$libs = @(Get-DPMLibrary $dpmsrv)
	writelog ("Processing {0} libraries..." -f $libs.count)
	$liblist = $xml.createelement("LIBRARYLIST")
	[void]$dpmnode.appendchild($liblist)
	for ($i = 0; $i -lt $libs.count; $i++) { 
		$lib = $xml.createelement("LIB$i")
		[void]$liblist.AppendChild($lib)
		[void]$lib.SetAttribute("UserFriendlyName", $libs[$i].UserFriendlyName)
		[void]$lib.SetAttribute("VendorId", $libs[$i].VendorId)
		[void]$lib.SetAttribute("ProductId", $libs[$i].ProductId)
		[void]$lib.SetAttribute("NumberOfChangers", $libs[$i].NumberOfChangers.ToString())
		[void]$lib.SetAttribute("Drives", $libs[$i].GetDriveCollection().count.tostring())
		[void]$lib.SetAttribute("Slots", $libs[$i].GetSlotCollection().count.tostring())
		[void]$lib.SetAttribute("ProtectionGroups", $libs[$i].ProtectionGroups.Replace(";",","))
	}

	$groups = $xml.createelement("Groups")
	[void]$dpmnode.appendchild($groups)
	$pgs = @($srv.GetProtectionGroups() | sort friendlyname)
	[void]$groups.SetAttribute("Count", $pgs.count)
	writelog ("`Processing {0} groups..." -f , $pgs.Count)
	for ($i = 0; $i -lt $pgs.count; $i++) {
		DoPG $groups $pgs[$i] "PG$i" $xml
	}

}
function DoPG {
	param ($groups, $pg, $elname, $xml)
	writelog ("GROUP: " + $pg.Friendlyname) "white"
	$PGel = $xml.CreateElement($elname)
	[void]$groups.AppendChild($PGel)
	[void]$PGel.SetAttribute("GroupName", $pg.friendlyname)
	[void]$PGel.SetAttribute("ScheduleOffset", $pg.ScheduleOffset.ToString())
	[void]$PGel.SetAttribute("PGPRotectionType", $pg.PGProtectionType.tostring())
	[void]$PGel.SetAttribute("OnsiteFrequency", $pg.OnsiteFrequency.tostring())
	[void]$PGel.SetAttribute("OffsiteFrequency", $pg.OffsiteFrequency.tostring())
	[void]$PGel.SetAttribute("Performance", $pg.Performance.tostring())
	[void]$PGel.SetAttribute("ReplicateBeforeShadowCopy", $pg.ReplicateBeforeShadowCopy.tostring())

	#V3
	if ($pg.DpmServer.GetProductInformation().version.major -gt 2) {
		[void]$PGel.SetAttribute("IsTapeShortTerm", $pg.IsTapeShortTerm.tostring())
		[void]$PGel.SetAttribute("IsTapeLongTerm", $pg.IsTapeLongTerm.tostring())
		[void]$PGel.SetAttribute("IsDiskShortTerm", $pg.IsDiskShortTerm.tostring())
		[void]$PGel.SetAttribute("IsTapeEnabled", $pg.IsTapeEnabled.tostring())
		[void]$PGel.SetAttribute("AutoHealProperty", $pg.AutoHealProperty.ToString())
		[void]$PGel.SetAttribute("IsAutoCCenabled", $pg.IsAutoCCEnabled.tostring())
		[void]$PGel.SetAttribute("IsAutoGrowenabled", $pg.IsAutoGrowEnabled.tostring())
		[void]$PGel.SetAttribute("IsClientDatasourcePresent", $pg.IsClientDatasourcePresent.tostring())
		[void]$PGel.SetAttribute("IsCloudLongterm", $pg.IsCloudLongterm.tostring())
		[void]$PGel.SetAttribute("IsCloudProtectable", $pg.IsCloudProtectable.tostring())
		[void]$PGel.SetAttribute("IsCollocated", $pg.IsCollocated.tostring())
		[void]$PGel.SetAttribute("IsPGCollocateable", $pg.IsPGCollocateable().tostring())
		[void]$PGel.SetAttribute("RerunCancelledJobs", $pg.RerunCancelledJobs.tostring())
		[void]$PGel.SetAttribute("TotalDPMOnlineReplicaSize", $pg.TotalDPMOnlineReplicaSize.tostring())
		[void]$PGel.SetAttribute("TotalDiskReplicaSize", $pg.TotalDiskReplicaSize.tostring())
	} 
	$item = $xml.CreateElement("DISKINTENT")
	[void]$PGel.AppendChild($item)
	if ($pg.DiskIntent) {
		[void]$item.SetAttribute("Compression", $pg.DiskIntent.Compression.ToString())
		[void]$item.SetAttribute("Encryption", $pg.DiskIntent.Encryption.ToString())
	} 
	$item = $xml.CreateElement("ARCHIVEINTENT")
	[void]$PGel.AppendChild($item)
	if ($pg.ArchiveIntent) {
		[void]$item.SetAttribute("Compression", $pg.ArchiveIntent.Compression.ToString()) #on-the-wire compression
		[void]$item.SetAttribute("IsCustomScheme", $pg.ArchiveIntent.IsCustomScheme.ToString())
		[void]$item.SetAttribute("NumberOfDrives", $pg.ArchiveIntent.NumberOfDrives.Tostring())
		[void]$item.SetAttribute("OnsiteCompression", $pg.ArchiveIntent.OnsiteCompression.ToString())
		[void]$item.SetAttribute("OnsiteEncryption", $pg.ArchiveIntent.OnsiteEncryption.ToString())
		[void]$item.SetAttribute("OffsiteCompression", $pg.ArchiveIntent.OffsiteCompression.ToString())
		[void]$item.SetAttribute("OffsiteEncryption", $pg.ArchiveIntent.OffsiteEncryption.ToString())
		[void]$item.SetAttribute("BackupLibraryName", $pg.ArchiveIntent.BackupLibraryName)
		[void]$item.SetAttribute("TapeCopyLibraryName", $pg.ArchiveIntent.TapeCopyLibraryName)
		[void]$item.SetAttribute("ArchivemodeForSon", $pg.ArchiveIntent.ArchiveModeForSon)
		[void]$item.SetAttribute("CancelOverlappingJobs", $pg.ArchiveIntent.CancelOverlappingJobs.ToString())
		[void]$item.SetAttribute("DatasetVerificationIntent", $pg.ArchiveIntent.DataSetVerificationIntent.ToString())
		[void]$item.SetAttribute("MediaEraseIntent", $pg.ArchiveIntent.MediaEraseIntent.ToString())
		[void]$item.SetAttribute("OptimizeForMedia", $pg.ArchiveIntent.OptimizeForMedia.ToString())

		$li = $pg.ArchiveIntent.LabelInfo
		$s = ""; foreach ($l in $li.Label) {$s = "$s$l,"}
		[void]$item.SetAttribute("LabelInfoLabels", $s.TrimEnd(","))
		$s = ""; foreach ($l in $li.Vault) {$s = "$s$l,"}
		[void]$item.SetAttribute("LabelInfoVaults", $s.TrimEnd(","))
		$s = ""; foreach ($l in $li.Generation) {$s = "$s$l,"}
		[void]$item.SetAttribute("LabelInfoGeneration", $s.TrimEnd(","))
	}
	#RETENTIONS	
	$Rpol = $xml.CreateElement("RETENTIONPOLICY")
	[void]$PGel.AppendChild($Rpol)
	$retpols = $pg.ArchiveIntent.RetentionPolicy
	if ($retpols) {
		[void]$Rpol.SetAttribute("OnsiteEnabled", $retpols.OnsiteEnabled.Tostring())
		[void]$Rpol.SetAttribute("OffsiteEnabled", $retpols.OffsiteEnabled.Tostring())

		$item = $xml.CreateElement("OnsiteGreatGrandFather")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OnsiteGreatGrandFather.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OnsiteGreatGrandFather.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OnsiteGreatGrandFather.IntervalPair.Value) 

		$item = $xml.CreateElement("OnsiteGrandFather")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OnsiteGrandFather.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OnsiteGrandFather.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OnsiteGrandFather.IntervalPair.Value)

		$item = $xml.CreateElement("OnsiteFather")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OnsiteFather.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OnsiteFather.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OnsiteFather.IntervalPair.Value)
		
		$item = $xml.CreateElement("OnsiteSon")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OnsiteSon.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OnsiteSon.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OnsiteSon.IntervalPair.Value)

		$item = $xml.CreateElement("OffsiteGreatGrandFather")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OffsiteGreatGrandFather.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OffsiteGreatGrandFather.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OffsiteGreatGrandFather.IntervalPair.Value) 

		$item = $xml.CreateElement("OffsiteGrandFather")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OffsiteGrandFather.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OffsiteGrandFather.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OffsiteGrandFather.IntervalPair.Value)

		$item = $xml.CreateElement("OffsiteFather")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OffsiteFather.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OffsiteFather.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OffsiteFather.IntervalPair.Value)
		
		$item = $xml.CreateElement("OffsiteSon")
		[void]$Rpol.AppendChild($item)
		[void]$item.SetAttribute("Enabled", $retpols.OffsiteSon.Enabled) 
		[void]$item.SetAttribute("Range", $retpols.OffsiteSon.IntervalPair.Key)
		[void]$item.SetAttribute("Unit", $retpols.OffsiteSon.IntervalPair.Value)
	}

	#SHORTTERM
	$POLitem = $xml.CreateElement("SHORTTERMPOLICY")
	[void]$PGel.AppendChild($POLitem)
	$pol = Get-PolicyObjective $pg -shortterm
	if ($pol) {DoPolicy $xml $pol $POLitem}
	$pol = $null; $POLitem = $null; $RRitem = $null; $SCHitem = $null; $item = $null

	#LONGTERM
	$POLitem = $xml.CreateElement("LONGTERMPOLICY")
	[void]$PGel.AppendChild($POLitem) 
	if ($dpmversion -gt 2) { $pol = Get-PolicyObjective $pg -longterm "Tape" } else { $pol = Get-PolicyObjective $pg -longterm}
	if ($pol) {DoPolicy $xml $pol $POLitem}
	$pol = $null; $POLitem = $null; $RRitem = $null; $SCHitem = $null; $item = $null

	#ONLINE / CLOUD
# 	if ($dpmversion -gt 2) {
# 		$POLitem = $xml.CreateElement("ONLINEPOLICY")
# 		[void]$PGel.AppendChild($POLitem) 
# 		$pol = Get-PolicyObjective $pg -longterm "Online" 
# 		if ($pol) {DoPolicy $xml $pol $POLitem}
# 		$pol = $null; $POLitem = $null; $RRitem = $null; $SCHitem = $null; $item = $null
# 
# 		$item = $xml.CreateElement("CLOUDGENERATOR")
# 		[void]$PGel.AppendChild($item)
# 		if ($pg.CloudGenerator) {
# 			[void]$item.SetAttribute("Range", $pg.CloudGenerator.RecoveryRange.Range.ToString())
# 			[void]$item.SetAttribute("Unit", $pg.CloudGenerator.RecoveryRange.Unit)
# 		}
# 
# 		$item = $xml.CreateElement("CLOUDRECOVERYRANGE")
# 		[void]$PGel.AppendChild($item)
# 		if ($pg.CloudRecoveryRange) {
# 			[void]$item.SetAttribute("Key", $pg.CloudRecoveryRange.key)
# 			[void]$item.SetAttribute("Value", $pg.CloudRecoveryRange.value)
# 		}
# 	}

	$item = $xml.CreateElement("ONSITEGENERATOR")
	[void]$PGel.AppendChild($item)
	if ($pg.OnsiteGenerator) {
		[void]$item.SetAttribute("Range", $pg.OnsiteGenerator.RecoveryRange.Range.ToString())
		[void]$item.SetAttribute("Unit", $pg.OnsiteGenerator.RecoveryRange.Unit)
	}
	$item = $xml.CreateElement("OFFSITEGENERATOR")
	[void]$PGel.AppendChild($item)
	if ($pg.OffsiteGenerator) {
		[void]$item.SetAttribute("Range", $pg.OffsiteGenerator.RecoveryRange.Range.ToString())
		[void]$item.SetAttribute("Unit", $pg.OffsiteGenerator.RecoveryRange.Unit)
	}
	$item = $xml.CreateElement("ONSITERECOVERYRANGE")
	[void]$PGel.AppendChild($item)
	if ($pg.OnsiteRecoveryRange) {
		[void]$item.SetAttribute("Key", $pg.OnsiteRecoveryRange.key)
		[void]$item.SetAttribute("Value", $pg.OnsiteRecoveryRange.value)
	} 
	$item = $xml.CreateElement("OFFSITERECOVERYRANGE")
	[void]$PGel.AppendChild($item)
	if ($pg.OnsiteRecoveryRange) {
		[void]$item.SetAttribute("Key", $pg.OffsiteRecoveryRange.key)
		[void]$item.SetAttribute("Value", $pg.OffsiteRecoveryRange.value)
	}

	$Popt = $xml.CreateElement("PROTECTIONTOPTIONS")
	[void]$PGel.AppendChild($Popt)
	#File -FileSystem  just returns excludes types (did that above)
	$tmp = ""; foreach ($type in $pg.ExcludeFileType) {$tmp = $tmp + "$type," }
	[void]$Popt.SetAttribute("ExcludeFileType", $tmp.TrimEnd(","))

	#Exchange 
	$po = Get-DatasourceProtectionOption $pg -ExchangeOptions
	[void]$Popt.SetAttribute("RunEseUtilCC", $po.RunEseUtilCC)
	[void]$Popt.SetAttribute("ProtectionTopology", $po.ProtectionTopology)
	$t = ""; $po.PreferredServers| foreach {$t = "{0},$t" -f , $_}; $t = $t.TrimEnd(",")
	[void]$Popt.SetAttribute("PreferredServers", $t)
	if ($dpmversion -gt 2) {
		$po = Get-DatasourceProtectionOption $pg -E14Options
		[void]$Popt.SetAttribute("EseUtiltype", $po.EseUtilCCtype)
	}

	$DSnode = $xml.CreateElement("DATASOURCES")
	[void]$PGel.AppendChild($DSnode)
	DoDatasources $xml $pg $DSnode
}
function DoDatasources {
	param ($xml, $pg, $DSnode)
	$dss = @(Get-Datasource -ProtectionGroup $pg)
	[void]$DSnode.SetAttribute("Count", $dss.count)
	writelog ("Processing {0} datasources, this may take a few minutes..." -f , $dss.Count)
	for ($i = 0; $i -lt $dss.count; $i++) {
		writelog ( "`tProcessing '{0}' on {1}" -f $dss[$i].name.tostring(), $dss[$i].PSInfo.NetBiosName )
		$DSel = $xml.CreateElement("DS$i")
		[void]$DSnode.AppendChild($DSel)
		[void]$DSel.SetAttribute("Name", $dss[$i].name)
		[void]$DSel.SetAttribute("Logicalpath", $dss[$i].Logicalpath)
		[void]$DSel.SetAttribute("ProtectionGroupName", $dss[$i].ProtectionGroupName) 
		[void]$DSel.SetAttribute("ProductionServerName", $dss[$i].ProductionServerName)
		[void]$DSel.SetAttribute("ClusterName", $dss[$i].PSinfo.ClusterName) 
		[void]$DSel.SetAttribute("Type", $dss[$i].Type.Name) 
		[void]$DSel.SetAttribute("SupportsIncremental", $dss[$i].SupportsIncremental)
		[void]$DSel.SetAttribute("NumberOfExcludedObjects", $dss[$i].NumberOfExcludedObjects)

		if ($pg.PGProtectionType -match "DiskToDisk") {
			$da = Get-DatasourceDiskAllocation $dss[$i]
			[void]$DSel.SetAttribute("PhysicalReplicaId", $dss[$i].AssociatedReplica.PhysicalReplicaId )
			if ($dpmversion -gt 2) {
				[void]$DSel.SetAttribute("ReplicaSize", $da[0].ReplicaSize)
				[void]$DSel.SetAttribute("RequiredReplicaSize", $da[0].RequiredReplicaSize)
				[void]$DSel.SetAttribute("ReplicaUsedSpace", $da[0].ReplicaUsedSpace)
				[void]$DSel.SetAttribute("ShadowCopyAreaSize", $da[0].ShadowCopyAreaSize)
				[void]$DSel.SetAttribute("RequiredShadowCopyAreaSize", $da[0].RequiredShadowCopySize)
				[void]$DSel.SetAttribute("ShadowCopyUsedSpace", $da[0].ShadowCopyUsedSpace)
				[void]$DSel.SetAttribute("IsCollocated", $da[0].IsCollocated)
			}
			else {
				[void]$DSel.SetAttribute("ReplicaSize", $da.ReplicaSize)
				[void]$DSel.SetAttribute("RequiredReplicaSize", $da.RequiredReplicaSize)
				[void]$DSel.SetAttribute("ReplicaUsedSpace", $da.ReplicaUsedSpace)
				[void]$DSel.SetAttribute("ShadowCopyAreaSize", $da.ShadowCopyAreaSize)
				[void]$DSel.SetAttribute("RequiredShadowCopyAreaSize", $da.RequiredShadowCopySize)
				[void]$DSel.SetAttribute("ShadowCopyUsedSpace", $da.ShadowCopyUsedSpace)
			} 
		}
		
		if ($dss[$i].Type.Name -eq "Volume") {	
			#Childs
			$DSchilds = $xml.CreateElement("Childs")
			[void]$DSel.AppendChild($DSchilds)
			$childs = @($dss[$i].GetProtectedObjects() | ? {$_.CurrentProtectionState -eq "Protected"}  )  
			[void]$DSchilds.SetAttribute("Count", $childs.count)
			writelog ( "`tProcessing {0} child members of '{1}' " -f $childs.count, $dss[$i].name.tostring() )
			$c = 0; $s=0
			foreach ($child in $childs ) {
				writelog ("`t[{0}] " -f $child.logicalpath) "cyan"
				$ChSel = $xml.CreateElement("Child$c")
				[void]$DSChilds.AppendChild($ChSel)
				[void]$ChSel.SetAttribute("LogicalPath", $child.logicalpath)
				[void]$ChSel.SetAttribute("Type", $child.Type.Name)
				$c++
			}
			#excluded folders
			$DSexclobj = $xml.CreateElement("ExcludedObjects")
			[void]$DSel.AppendChild($DSexclobj)
			$exclobj = @($dss[$i].GetProtectedObjects() | ? {$_.CurrentProtectionState -eq "Excluded"})
			[void]$DSexclobj.SetAttribute("Count", $exclobj.count)
			$c = 0
			foreach ($child in $exclobj ) {
				writelog ("`tExcluding [{0}] " -f $child.logicalpath) "yellow"
				$ChSel = $xml.CreateElement("ExclObj$c")
				[void]$DSexclobj.AppendChild($ChSel)
				[void]$ChSel.SetAttribute("LogicalPath", $child.logicalpath)
				[void]$ChSel.SetAttribute("Type", $child.Type.Name)
				$c++
			}
		}
	}
}
#endregion 

#START
$Error.clear()
$version = "v0.94"
[datetime]$now = Get-Date
$global:format = "HH:mm:ss"
$global:cult  = New-Object System.Globalization.CultureInfo("en-US")

$oldpref = $ConfirmPreference
$ConfirmPreference = "None"
LoadDPMsnapin
if ($configfile -eq "" ) {$configfile = "{0}\DPMsaveConfig.XML" -f , (get-location)}
$logfile = "{0}\DPMsaveConfig.LOG" -f , (get-location)
"DPMsaveConfig version $version" >> $logfile
if (Test-Path $configfile -ErrorAction silentlycontinue) {
	[xml]$xml = Get-Content $configfile
}
else {
	#Create decent XML structure
	$hdr = '<?xml version="1.0" encoding="utf-8"?>
 <DPMConfig xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	scriptversion="V0.0">
	</DPMConfig>'
 $xml = [xml]$hdr
}
$xml.DPMConfig.scriptversion=$version

if ($dpmserverlist.count -eq 0) {
	$dpmserverlist += (&hostname)
	Showhelp
}

foreach ($dpmsrv in $dpmserverlist) {
	$node = $xml.DPMConfig.SelectSingleNode("./$dpmsrv")
	if ($node) {
		$result = Read-Host "Configuration for $dpmsrv already present, overwrite it Y/N [N]"
		if ($result -eq "Y") {
			[void]$xml.DPMConfig.RemoveChild($node)
			DoDPM $xml $dpmsrv 
		}
		else { 
			writelog ( "Skipping DPM server [{0}] "-f $node.dpmservername)
		}
	} else {DoDPM $xml $dpmsrv } 
}
$xml.Save($configfile)
writelog "`nFinished, saved configuration in $configfile"
$ConfirmPreference = $oldpref
