#Author: Ruud Baars
#Date 1/31/2010
# Synopsis:
# Reads and creates protection group & data source configuration in XML created using DPMsaveConfig.Ps1

param ( 
	[string[]]$dpmserverlist = @(),
	[string]$configfile = "",
	[string]$AllocationIntent="Auto"
) 

#region traps 
trap [Exception] { 
	writelog $("TRAP: DPMcreateConfig")
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "DPMcreateConfig"
	$log.WriteEntry("TRAP: DPMcreateConfig: $error", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	write-host $Error -f "magenta"
	write-host $Error[0].InvocationInfo.PositionMessage -ForegroundColor "Magenta"
	$Error.Clear()
	exit 1
}
#endregion

#region functions

function writelog {
	param([string]$msg, $color="Green")
	$msg =  "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	Write-Host $msg -ForegroundColor $color
}
function Showhelp {
	#just help page
	Write-Host -f cyan @("
========================================== 
DPMcreateConfig $version usage
==========================================
[-configfile <filespec>] specifies input file, defaults to .\DPMsaveConfig.XML

[-AllocationIntent `"Auto`" | `"Required`" | `"Used`"], defaults to `"Auto`"

`tRequired = Allocate  minimum required size
`tUsed`t = Allocate according used size
`tAuto`t = Allocate according DPM calculations
	") 
}
function LoadDPMsnapin {
	#load PS snap-in if not already
	param ()
	if (Get-PSSnapin | ?{$_.name -like "Microsoft.DataProtectionManager.PowerShell"}) {
	}
	else {
		Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
	}
} 
function DoDPM {
	param ($dpmsrv )
	$currentDPM = &hostname
	writelog ("Processing saved information from DPMserver {0}..." -f $dpmsrv.Dpmservername)
	disconnect-dpmserver $currentDPM
	$srv = Connect-dpmserver $currentDPM
	$DPMmajor = $srv.GetProductInformation().Version.Major

	$PSs = @($srv.GetProductionServers())
	writelog "Inquiring data sources, this may take a while..."
	$xps = @()
	$dpmsrv.Groups.SelectNodes("//DATASOURCES/*") | foreach {$xps += $_.ProductionServername}
	$xps = $xps | sort -Unique

	$DSs = @()
	foreach ($ps in $PSs) {
		if ($xps -match $ps.name) {
			writelog ("`tQuerying server {0}" -f $ps.name)
			$DSs += Get-Datasource -ProductionServer $ps -Inquire
		}
		else {writelog ("`tNo protection definitions for {0}" -f $ps.name)}
	}
	Writelog "Datasource queries done!" 

	$inactiveGrps = @()
	foreach ($xgrp in $dpmsrv.groups.SelectNodes("*")) {
		if ($xgrp.DATASOURCES.Count -gt 0 ) {DoPG $xgrp $DSs $srv }
		else {
			$inactiveGrps += $xgrp
			writelog ("Skipping group [{0}] because no datasources were saved!" -f $xgrp.GroupName ) "Cyan"
		}
	}
	writelog ("Processing DPMserver {0} finished`n`n" -f $dpmsrv.Name)
}
function RecurseForChild {
	param($parent, $recursepath)
	Write-host ("[{0}]`tRecursing: [" -f (Get-Date).tostring($format))  -ForegroundColor cyan -NoNewline
	$pathsteps = $recursepath.split("\")[1..256] #split but omit first element
	$level = $parent
	Write-Host ("{0}" -f $parent.LogicalPath) -ForegroundColor cyan -NoNewline
	foreach ($step in $pathsteps) {
		$kidlevel = Get-ChildDatasource -ChildDatasource $level -Inquire | ? {$_.Name -eq $step}
		Write-Host ("{0}\" -f $kidlevel.name) -ForegroundColor cyan -NoNewline
		$level = $kidlevel
	}
	Write-Host "]" -ForegroundColor cyan
	return $kidlevel
}
function DoChilds {
	param ($DStodo, $protectedDS, $xds, $mpg, $DSs)
	$parent=$DStodo.ds
	$protectedChilds = @()
	if ($protectedDS) {
		$protectedChilds += Get-ChildDatasource -ChildDatasource $protectedDS -Inquire | ? {$_.CurrentProtectionState -eq "Protected" } 
	}
	writelog ("`tProcessing childs of [{0}] ..." -f $xds.logicalpath)
	foreach ($xchild in $xds.Childs.SelectNodes("*")) { 
		if ( $protectedChilds | ? {$_.logicalpath -eq $xchild.logicalpath}) { 
			writelog ("`tChild [{0}] is already member" -f $xchild.logicalpath)
		} 
		else {
			if ($xchild.Type -eq "Share" ) {
				#cannot recurse share, add directly (servername is included in logicalpath)
				$childtodo = $DSs | ? {$_.logicalpath -eq $xchild.logicalpath}
				writelog ("`t++ Adding share [{0}]  ..." -f $childtodo.LogicalPath) "cyan"
				Add-ChildDatasource -ProtectionGroup $mpg -ChildDatasource $childtodo -ErrorAction SilentlyContinue
				$DStodo.count +=1
				continue;
			}
			$childtodo = RecurseForChild $parent $xchild.LogicalPath
			writelog ("`t++ Adding child [{0}] on server {1}  ..." -f $childtodo.LogicalPath, $xds.ProductionServerName) "cyan"
			Add-ChildDatasource -ProtectionGroup $mpg -ChildDatasource $childtodo -ErrorAction SilentlyContinue
			$DStodo.count +=1
		}
	} 
}
function DoExcludes{
	param ($parent, $xds, $mpg) 
	foreach ($xexcl in $xds.ExcludedObjects.SelectNodes("*")) {
		$exclobj = RecurseForChild $parent $xexcl.LogicalPath
		if ($exclobj) {
			writelog ("`t-- Excluding {0}" -f $exclobj.LogicalPath) "yellow"
			Remove-ChildDatasource $mpg -ChildDatasource $exclobj
		}
	} 
}
 function DoPG {
	param ($xgrp, $DSs, $srv)
	#check for existing group
	$pg = $srv.GetProtectionGroups() | ?{$_.FriendlyName -eq $xgrp.GroupName}
	if (!$pg) { 
		writelog ("Creating group [{0}] ..." -f $xgrp.GroupName) "Yellow"
		$pg = New-ProtectionGroup -DPMServerName $srv.name -name $xgrp.GroupName
	}
	writelog ("Modifying group [{0}] ..." -f $xgrp.GroupName) "white"
	$mpg = Get-ModifiableProtectionGroup $pg

	#excluded file types
	if ($xgrp.PROTECTIONTOPTIONS.ExcludeFileType.Length -gt 0) {
		writelog ("`tExcluding file types {0}" -f $xgrp.PROTECTIONTOPTIONS.ExcludeFileType.ToUpper())
		($xgrp.PROTECTIONTOPTIONS.ExcludeFileType).split(",")| foreach {Set-DatasourceProtectionOption $mpg -FileType $_ -Add}
	}

	# auto consistency check
	if ($DPMmajor -gt 2) { 
		switch ($xgrp.AutohealProperty) { 
			"3" {
				writelog "`tAuto consistency check is now ENABLED!"
				Set-DatasourceProtectionOption $mpg -AutoConsistencyCheck $true
			}
			"1" {
				writelog "`tAuto consistency check is now DISABLED!"
				Set-DatasourceProtectionOption $mpg -AutoConsistencyCheck $false
			}
			default { writelog ("UNKNOWN AutohealProperty value = {0}" -f $xgrp.AutohealProperty ) }
		}
	}

	#collect protected data sources
	$protectedDSlist = @(); $srv.GetProtectionGroups() | foreach {$protectedDSlist += Get-Datasource -ProtectionGroup $_ }
	$protectedDSlist = $protectedDSlist | ? {$_ } #ensure no empty ones
	# $inactiveDSS = @(Get-Datasource -DPMServerName $srv.name -Inactive)

#Add the kids to group
	$DStoAllocate = @()
	foreach ($xds in $xgrp.DATASOURCES.SelectNodes("*")) {
		$DStodo = "" | select ds, calculate, count
		# select data source object we need from inquired list
		$DStodo.ds = $DSs | ? {($_.ProductionServerName -eq $xds.ProductionServerName) -and ($_.logicalpath -eq $xds.logicalpath )}
		if (!($DStodo.ds)) {writelog ("[{0}] no longer exists on protected server " -f $xds.Logicalpath); continue}
		# see if already exists
		if ($protectedDSlist) {$protectedDS = $protectedDSlist | ? {$_.equals($DStodo.ds) }}
		if ($protectedDS) { 
			# when volume type check if childs need to be added else it is just an existing data source. 
			if ($protectedDS.Type.Name -ne "Volume" ) { 
				writelog ("`t[{0}] on server {1}  already exists!" -f $xds.name, $xds.ProductionServerName);
				continue;
			}
			$DStodo.count=0
			if (($xds.Childs.Count + $xds.ExcludedObjects) -gt 0) {
				if ($xds.Childs.Count -gt 0 ) {DoChilds $DStodo $protectedDS $xds $mpg $DSs }
				if ($xds.ExcludedObjects.Count -gt 0 ) {DoExcludes $DStodo.ds $xds $mpg }
				if ($DStodo.count -gt 0) {
					$DStodo.calculate =$true
					$DStoAllocate += $DStodo
				}
				continue;
			}
			else {
				# we are here if  volume type but not a child
				writelog ("`t++Adding [{0}] on server {1} to group [{2}] for [{3}] protection..." -f $xds.name, $xds.ProductionServerName, $xgrp.GroupName, $xgrp.PGprotectionType)
				Add-ChildDatasource -ProtectionGroup $mpg -ChildDatasource $DStodo.ds
				if ($xds.ExcludedOjects.count -gt 0 )  {DoExcludes $DStodo.ds $xds $mpg }
				if ($DStodo.count -gt 0) {
					$DStodo.calculate =$true
					$DStoAllocate += $DStodo
				}
				continue;
			}
		}
		else {
			# we are here if  new data source, if volume type check if childs need be added 
			if (($DStodo.ds.Type.Name -eq "Volume" ) -and ($xds.Childs.Count -gt 0)) {
				DoChilds $DStodo $protectedDS $xds $mpg $DSs
				if ($xds.ExcludedOjects.count -gt 0 )  {DoExcludes $DStodo.ds $xds $mpg }
				if ($DStodo.count -gt 0) {
					$DStodo.calculate =$true
					$DStoAllocate += $DStodo
				}
				continue;
			}
			# we are here if new app or entire volume data source 
			writelog ("`t++Adding [{0}] on server {1} to group [{2}] for [{3}] protection..." -f $xds.name, $xds.ProductionServerName, $xgrp.GroupName, $xgrp.PGprotectionType)
			Add-ChildDatasource -ProtectionGroup $mpg -ChildDatasource $DStodo.ds
			if ($xds.ExcludedObjects.count -gt 0 )  {
				DoExcludes $DStodo.ds $xds $mpg 
				}
			$DStodo.calculate = $false
			$DStoAllocate += $DStodo
		}
	} #end foreach

	# NOTE: must maintain this order of steps
	#	1- Set-Type
	# 	2- Set-PolicyObjective
	# 	3- Set-PolicySchedule  	
	# 	4 -disk allocation and other options	
	# 	5- Set-Protectiongroup

	switch ($xgrp.PGprotectiontype) {
		"DiskToDisk" { 
			Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Disk
			SetShortDiskObjectives $xgrp $mpg 
			SetShortSchedule $xgrp $mpg
			DoDiskAllocation $mpg $DStoAllocate $xgrp $AllocationIntent
		}
		"DiskToTape" { 
			#we also get here when both (D2T2T) are tape, bail-out and debug ?
			#if ($xgrp.IsTapeLongTerm) {Throw "STRANGE => debug/verify ::  IsTapeLongTerm=True on DiskToTape case!?"}
			
			# Objectives & schedules
			if (($xgrp.IsTapeShortTerm -eq "True") -and  ($xgrp.IsTapeLongTerm -eq "False") ){	
				Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Media 
				SetShortTapeObjectives $xgrp $mpg 
				SetShortSchedule $xgrp $mpg	
			}

			if  (($xgrp.IsTapeShortTerm -eq "False") -and  ($xgrp.IsTapeLongTerm -eq "True") ){	
					if ($DPMmajor -gt 2 ) {Set-ProtectionType -ProtectionGroup $mpg  -LongTerm Tape}
					else {Set-ProtectionType -ProtectionGroup $mpg -LongTerm}
					SetLongTapeObjectives $xgrp $mpg 	
					SetLongTapeSchedule $xgrp $mpg 
			}
			
			if  (($xgrp.IsTapeShortTerm -eq "True") -and  ($xgrp.IsTapeLongTerm -eq "True") ){	
					if ($DPMmajor -gt 2 ) {Set-ProtectionType -ProtectionGroup $mpg  -ShortTerm Media -LongTerm Tape}
					else {Set-ProtectionType -ProtectionGroup $mpg -ShortTermMedia -LongTerm}
					SetShortTapeObjectives $xgrp $mpg 
					SetShortSchedule $xgrp $mpg	
					SetLongTapeObjectives $xgrp $mpg 	
					SetLongTapeSchedule $xgrp $mpg 
			}	
			SetTapeOptions $xgrp $mpg $srv 
		}
		"DiskToDiskToTape" { 
			if ($DPMmajor -gt 2) {Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Disk -LongTerm Tape }
			else {Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Disk -LongTerm} 
			
			#Objectives & Schedules
			SetShortDiskObjectives $xgrp $mpg 
			SetLongTapeObjectives $xgrp $mpg
			SetShortSchedule $xgrp $mpg
			SetLongTapeSchedule $xgrp $mpg
			
			SetTapeOptions $xgrp $mpg $srv 
			DoDiskAllocation $mpg $DStoAllocate $xgrp 
		} 
		"DiskToTapeToTape" { 
			#not sure when this is used ?
			if ($srv.GetProductInformation().Version.Major -gt 2) {Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Tape -LongTerm Tape }
			else {Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Media -LongTerm}
			#Objectives
			if ($xgrp.IsDiskShortTerm -eq "True") { 
				SetShortDiskObjectives $xgrp $mpg 
				SetShortSchedule $xgrp $mpg 
			}
			if ($xgrp.IsTapeShortTerm -eq "True") {	
				SetShortTapeObjectives $xgrp $mpg 
				SetShortSchedule $xgrp $mpg 
			}
			if ($xgrp.IsTapeLongTerm -eq "True") {
				SetLongTapeObjectives $xgrp $mpg 
				SetLongTapeSchedule $xgrp $mpg 
			}
			SetTapeOptions $xgrp $mpg $srv
		}
		"DiskToDiskToCloud" { 
			Throw "DiskToDiskToCloud not yet tested!"
			#Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Disk -LongTerm Online  #build 7336
			Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Disk -LongTerm Tape #RC build
			# Objectives  & schedules
			if ($xgrp.IsDiskShortTerm -eq "True") { 
				SetShortDiskObjectives $xgrp $mpg 
				SetShortSchedule $xgrp $mpg 
			}
			if ($xgrp.IsTapeLongTerm -eq "True") {	
				SetLongTapeObjectives $xgrp $mpg 
				SetLongTapeSchedule $xgrp $mpg 
			}
			if ($xgrp.IsCloudLongTerm -eq "True")  {
				SetOnlineObjectives $xgrp $mpg 
				SetOnlineSchedule $xgrp $mpg
			}
			DoDiskAllocation $mpg $DStoAllocate $xgrp 
		}
		"DiskToDiskToCloudAndTape" { 
			Throw "DiskToDiskToCloudAndTapenot yet tested!"
			Set-ProtectionType -ProtectionGroup $mpg -ShortTerm Disk -LongTerm OnlineAndTape
			
			# Objectives  & schedules
			if ($xgrp.IsDiskShortTerm -eq "True") { 
				SetShortDiskObjectives $xgrp $mpg 
				SetShortSchedule $xgrp $mpg 
			}
			if ($xgrp.IsTapeLongTerm -eq "True") {	
				SetLongTapeObjectives $xgrp $mpg 
				SetLongTapeSchedule $xgrp $mpg 
			}
			if ($xgrp.IsCloudLongTerm -eq "True")  {
				SetOnlineObjectives $xgrp $mpg 
				SetOnlineSchedule $xgrp $mpg
			}
			SetTapeOptions $xgrp $mpg $srv
			DoDiskAllocation $mpg $DStoAllocate $xgrp 
		}
		default {writelog ("Unknown protection type [{0}]" -f $xgrp.PGprotectiontype)}
	} #end switch
	
	writelog ("Committing protectiongroup [{0}]" -f $xgrp.Groupname)
	$2ndmpg = Get-ModifiableProtectionGroup $mpg #need to redo this for some reason ?
	Set-protectiongroup $2ndmpg
	writelog ("Processing group [{0}] finished" -f $xgrp.GroupName)
	#END
}
function DoDiskAllocation {
	param ($mpg, $DStoAllocate, $xgrp  )

	foreach ($DSrecord in $DStoAllocate) {
		$DSal = $DSrecord.ds
		$xpathstring = "*[attribute::Logicalpath='{0}']" -f $DSal.logicalpath	
		switch ($AllocationIntent) {
			"Required" {
				writelog ("`tAllocating according REQUIRED space for [{0}]..." -f $DSal.Name) "white"
				[void](Get-DatasourceDiskAllocation -Datasource $DSal)
				[int64]$Ralloc= ($xgrp.DATASOURCES.SelectNodes("$xpathstring")).item(0).RequiredReplicaSize
				[int64]$Salloc = ($xgrp.DATASOURCES.SelectNodes("$xpathstring")).item(0).RequiredShadowCopyAreaSize
				if (($Ralloc / $GB) -lt 1.01) {$Ralloc = 1.01*$GB} ; if (($Salloc/$GB) -lt 1.57) { $Salloc = 1.57 * $GB}
				writelog ("`tAllocating {0}GB for Replica volume and {1}GB for Recoverypoint volume" -f ($Ralloc/$GB).Tostring("N2"), ($Salloc/$GB).Tostring("N2") ) "Cyan"
				Set-DatasourceDiskAllocation -Datasource $DSal -ProtectionGroup $mpg -Manual -ReplicaArea $Ralloc -ShadowCopyArea $Salloc
			}
			"Used" {
				writelog ("`tAllocating according USED space for [{0}]..." -f $DSal.Name)  "white"
				[void](Get-DatasourceDiskAllocation -Datasource $DSal)
				[int64]$Ralloc = ($xgrp.DATASOURCES.SelectNodes("$xpathstring")).item(0).ReplicaUsedSpace
				[int64]$Salloc = ($xgrp.DATASOURCES.SelectNodes("$xpathstring")).item(0).ShadowCopyUsedSpace
				if (($Ralloc / $GB) -lt 1.01) {$Ralloc = 1.01*$GB} ; if (($Salloc/$GB) -lt 1.57) { $Salloc = 1.57 * $GB}
				writelog ("`tAllocating {0}GB for Replica volume and {1}GB for Recoverypoint volume" -f ($Ralloc/$GB).Tostring("N2"), ($Salloc/$GB).Tostring("N2") ) "Cyan"
				Set-DatasourceDiskAllocation -Datasource $DSal -ProtectionGroup $mpg -Manual -ReplicaArea $Ralloc -ShadowCopyArea $Salloc
			}
			default {
				writelog ("`tAllocating  DPM -Calculate = {0} for [{1}]..." -f $DSrecord.calculate, $DSal.Name)  "white"
				switch ($DSal.Type.Name ) {
					"Volume" {
						if ($DSrecord.calculate) {[void](Get-DatasourceDiskAllocation -Datasource $DSal -CalculateSize) }
						else { [void](Get-DatasourceDiskAllocation -Datasource $DSal)  }
					}
					"Share" {
						if ($DSrecord.calculate) {[void] (Get-DatasourceDiskAllocation -Datasource $DSal -CalculateSize) }
						else { [void](Get-DatasourceDiskAllocation -Datasource $DSal )}					
					}	
					default {
						 [void](Get-DatasourceDiskAllocation -Datasource $DSal )
					}
				}
				Set-DatasourceDiskAllocation  -Datasource $DSal  -ProtectionGroup $mpg
				if (($DPMmajor -gt 2) -and ($xgrp.IsAutoGrowenabled -eq "True")) { 
					writelog "`tAUTOGROW enabled!" "white"
					Set-DatasourceDiskAllocation -ProtectionGroup $mpg -AutoGrow $true
				}
			}	
		}	
		Set-ReplicaCreationMethod -ProtectionGroup $mpg -Manual
	}
}
function SetShortSchedule {
	param ( $xgrp, $mpg)
	$xschedules = @($xgrp.SHORTTERMPOLICY.SCHEDULES.SelectNodes("*")) 
	if ($xschedules.Count -lt 1) {writelog "No SHORT term schedules saved!"; return}
	foreach ($xsch in $xschedules) {
		writelog ("`tSetting short term schedule [{0}]" -f $xsch.Jobtype)
		switch ($xsch.Jobtype) {
			#Note: this switches on "JobType" and NOT "JobTypeString"  which is slightly different and may be confusing
			#Note: there are 'timeSofday' / 'daysSofweek' (multiple) but also 'timeofday' / 'dayof week' (single)
			#Note:  'Son' = daily / 'Father' = daily or  weekly / 'GrandFather' = monthly / 'GreatGrandFather' = monthly or yearly
			#Note: 'Onsite*' = short term / 'Offsite*' = long term 

			"ShadowCopy" {
				# multiple days and times, can be just 1
				$sched = Get-PolicySchedule -ProtectionGroup $mpg -ShortTerm | ? { $_.JobType -eq $xsch.Jobtype } 
				$dow = $xsch.WeekDays.Split(","); $tod = $xsch.TimesOfDay.Split(",")
				Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -daysofweek $dow -timesofday $tod -ErrorAction SilentlyContinue
				Set-PolicySchedule -ProtectionGroup $mpg -OffsetInMinutes $xgrp.ScheduleOffset -ErrorAction SilentlyContinue 
			} 
			"OnsiteSonArchive" {
				# daily incremental
				$sched = Get-PolicySchedule -ProtectionGroup $mpg -ShortTerm | ? { $_.JobType -eq $xsch.Jobtype } 
				Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -timeofday $xsch.ScheduleTime -ErrorAction SilentlyContinue
			}
			"OnsiteFatherArchive" {
				# single day and time
				$sched = Get-PolicySchedule -ProtectionGroup $mpg -ShortTerm | ? { $_.JobType -eq $xsch.Jobtype } 
				Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -dayofweek $xsch.weekday -timeofday $xsch.ScheduleTime -ErrorAction SilentlyContinue
			}
			"Replication" {
				# $sched = Get-PolicySchedule -ProtectionGroup $mpg -ShortTerm  |  ? { $_.JobType -eq  $xsch.Jobtype }	
				# SynchronizationFrequency is set as part of policy objective
				Set-PolicySchedule -ProtectionGroup $mpg -OffsetInMinutes $xgrp.ScheduleOffset -ErrorAction SilentlyContinue 
			}
			"FullReplicationForApplication" {
				# multiple days and times, can be just 1
				$sched = Get-PolicySchedule -ProtectionGroup $mpg -ShortTerm | ? { $_.JobType -eq $xsch.Jobtype }
				$dow = $xsch.WeekDays.Split(","); $tod = $xsch.TimesOfDay.Split(",")
				Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -DaysOfWeek $dow -TimesOfDay $tod -ErrorAction SilentlyContinue
				Set-PolicySchedule -ProtectionGroup $mpg -OffsetInMinutes $xgrp.ScheduleOffset -ErrorAction SilentlyContinue
			}
			"DiskAutoValidation" { 
				# time and max. duration
				$sched = Get-PolicySchedule -ProtectionGroup $mpg -ShortTerm | ? { $_.JobType -eq $xsch.Jobtype }
				Set-ProtectionJobStartTime $mpg -JobType ConsistencyCheck -TimeOfDay $xsch.StartTime -MaximumDurationInHours $xsch.MaxDuration -ErrorAction SilentlyContinue
			}
			default { writelog ("SHORT TERM schedule type [{0}] not yet implemented" -f $xsch.Jobtype) "Magenta"}
		}
	} 
}
function SetLongTapeSchedule {
	param ($xgrp, $mpg)
	$xschedules = @($xgrp.LONGTERMPOLICY.SCHEDULES.SelectNodes("*")) 
	if ($xschedules.Count -lt 1) {writelog "No LONG term schedules saved!"; return}
	foreach ($xsch in $xschedules) {
		writelog ("`tSetting long term schedule [{0}]" -f $xsch.Jobtype) 
		#Must set 'IsCustomScheme' to properly initialize $sched.Interval (read only and must be 1,3,6 or 12)
		#Otherwise aborts Set-PolicySchedule on invalid value exception
		if ($xgrp.ARCHIVEINTENT.IsCustomScheme -eq "True") {
			$mpg.ArchiveIntent.IsCustomScheme=$true
		} 
		else {
			$mpg.ArchiveIntent.IsCustomScheme=$false
		} 
		switch ($xsch.Jobtype) {
			"OffsiteFatherArchive" {
				if ($DPMmajor -gt 2 ) {$sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm "Tape" | ? { $_.JobType -eq $xsch.Jobtype }}
				else { $sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm | ? { $_.JobType -eq $xsch.Jobtype }}
				if (!($sched)) {writelog ("`tSkipping [{0}] because no schedule was returned" -f $xsch.Jobtype) "Cyan"; return}
				if ($xsch.RelativeInterval -eq "None") {
					if ($xsch.Weekday -eq "None") { Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -ErrorAction silentlycontinue}
					else {Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -DayOfWeek $xsch.Weekday -ErrorAction silentlycontinue }	
				}
				else { Set-PolicySchedule $mpg $sched -StartTime $xsch.ScheduleTime -RelativeInterval $xsch.RelativeInterval -DayOfWeek $xsch.RelativeWeekday -ErrorAction SilentlyContinue}
			}
			"Offsite1FatherArchive" {
				if ($DPMmajor -gt 2 ) {$sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm "Tape" | ? { $_.JobType -eq $xsch.Jobtype }}
				else { $sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm | ? { $_.JobType -eq $xsch.Jobtype }}
				if (!($sched)) {writelog ("`tSkipping [{0}] because no schedule was returned" -f $xsch.Jobtype) "Cyan"; return}
				if ($xsch.RelativeInterval -eq "None") {
					if ($xsch.Weekday -eq "None") { Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -ErrorAction silentlycontinue}
					else {Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -DayOfWeek $xsch.Weekday -ErrorAction silentlycontinue }	
				}
				else { Set-PolicySchedule $mpg $sched -StartTime $xsch.ScheduleTime -RelativeInterval $xsch.RelativeInterval -DayOfWeek $xsch.RelativeWeekday -ErrorAction SilentlyContinue}
			}
			"OffsiteGrandFatherArchive" {
				if ($DPMmajor -gt 2 ) {$sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm "Tape" | ? { $_.JobType -eq $xsch.Jobtype }}
				else { $sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm | ? { $_.JobType -eq $xsch.Jobtype }}
				if (!($sched)) {writelog ("`tSkipping [{0}] because no schedule was returned" -f $xsch.Jobtype) "Cyan"; return}
				if ($xsch.RelativeInterval -eq "None") {
					if ($xsch.Weekday -eq "None") { Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -ErrorAction silentlycontinue}
					else {Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -DayOfWeek $xsch.Weekday -ErrorAction silentlycontinue }	
				} 
				else {Set-PolicySchedule $mpg $sched -StartTime $xsch.ScheduleTime -RelativeInterval $xsch.RelativeInterval -DayOfWeek $xsch.RelativeWeekday -ErrorAction SilentlyContinue}
			}
			"OffsiteGreatGrandFatherArchive" { 
				if ($DPMmajor -gt 2 ) {$sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm "Tape" | ? { $_.JobType -eq $xsch.Jobtype }}
				else { $sched = Get-PolicySchedule -ProtectionGroup $mpg -LongTerm | ? { $_.JobType -eq $xsch.Jobtype }}
				if (!($sched)) {writelog ("`tSkipping [{0}] because no schedule was returned" -f $xsch.Jobtype) "Cyan"; return}
				if ($xsch.RelativeInterval -eq "None") {
					if ($xsch.Weekday -eq "None") { Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -ErrorAction silentlycontinue}
					else {Set-PolicySchedule -ProtectionGroup $mpg -Schedule $sched -TimeOfDay $xsch.ScheduleTime -DayOfWeek $xsch.Weekday -ErrorAction silentlycontinue }	
				} 
				else {Set-PolicySchedule $mpg $sched -StartTime $xsch.ScheduleTime -RelativeInterval $xsch.RelativeInterval -DayOfWeek $xsch.RelativeWeekday -ErrorAction SilentlyContinue}
			}
			default { writelog ("LONG TERM schedule type not yet [{0}] implemented" -f $xsch.Jobtype) "Magenta"}
		} #end switch
	} #end foreach	
}
function SetOnlineSchedule {
	param ($xgrp, $mpg)
	WRITELOG "CLOUD/ONLINE SCHEDULE ARE NOT YET IMPLEMENTED" ; return
}
function SetShortDiskObjectives {
	param ($xgrp, $mpg)
	writelog ("`tSetting short term disk objectives for [{0}]" -f $xgrp.PGPRotectionType)
	if ($xgrp.ReplicateBeforeShadowCopy -eq "True") {Set-PolicyObjective $mpg -RetentionRangeInDays $xgrp.SHORTTERMPOLICY.RECOVERYRANGE.Range -BeforeRecoveryPoint}
	else {Set-PolicyObjective $mpg -RetentionRangeInDays $xgrp.SHORTTERMPOLICY.RECOVERYRANGE.Range -SynchronizationFrequency $xgrp.SHORTTERMPOLICY.SCHEDULES.Replication.Frequency}
	if (($xgrp.DATASOURCES.SelectNodes("*[attribute::IsCollocated='True']")).count -gt 0 ) { Set-PolicyObjective -ProtectionGroup $mpg -CollocateDatasources $true}
}
function SetShortTapeObjectives {
	param($xgrp, $mpg)
	writelog ("`tSetting short term tape objectives for [{0}]" -f $xgrp.PGPRotectionType)
	if ($xgrp.SHORTTERMPOLICY.AllowIncrementals -eq "True") {
		Set-PolicyObjective $mpg -RetentionRangeInWeeks $xgrp.SHORTTERMPOLICY.RECOVERYRANGE.Range -ShortTermBackupFrequency $xgrp.SHORTTERMPOLICY.SCHEDULES.OnsiteSonArchive.Frequency -CreateIncrementals
	}
	else {
		Set-PolicyObjective $mpg -RetentionRangeInWeeks $xgrp.SHORTTERMPOLICY.RECOVERYRANGE.Range -ShortTermBackupFrequency $xgrp.SHORTTERMPOLICY.SCHEDULES.OnsiteSonArchive.Frequency 
	}
}
function SetLongTapeObjectives {
	param($xgrp, $mpg)
	writelog ("`tSetting long term tape objectives for [{0}]" -f $xgrp.PGPRotectionType)

	if ($xgrp.ARCHIVEINTENT.IsCustomScheme -eq "True") { 
		# Must initialize label information  else the CLI will terminate
		$linfo = New-Object -TypeName Microsoft.Internal.EnterpriseStorage.Dls.XsdClasses.MM.Interface.labelinfo
		$vaults = @( $xgrp.ARCHIVEINTENT.LabelInfoVaults.split(","))
		$labels = @( $xgrp.ARCHIVEINTENT.LabelInfoLabels.split(","))
		$gens = @( $xgrp.ARCHIVEINTENT.LabelInfoGeneration.split(","))
		$linfo.Vault = $vaults
		$linfo.label=$labels
		$linfo.Generation=$gens
		$mpg.ArchiveIntent.LabelInfo=$linfo
		$RRlist = @(); $FRQlist = @();$GENlist = @();
		#select offsite policies only
		foreach ($el in $xgrp.RETENTIONPOLICY.SelectNodes("*") | ? { ($_.enabled -eq $true) -and ($_.name -match "offsite")} ) {
			$RRList += (new-object -TypeName Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.OMCommon.RetentionRange -ArgumentList $el.range, $el.unit)
		}
		foreach ($el in $xgrp.LONGTERMPOLICY.SCHEDULES.SelectNodes("*") ) {
			$GENlist += $el.Generation
			$FRQlist += GetBckFreqEnum $el.Frequency
		}
		Set-PolicyObjective $mpg -RetentionRangeList $RRlist -FrequencyList $FRQlist -GenerationList $GENlist
	}
	else {
		$range = $xgrp.LONGTERMPOLICY.RECOVERYRANGE.Range
		$unit = $xgrp.LONGTERMPOLICY.RECOVERYRANGE.Unit
		$RR = new-object -TypeName Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.OMCommon.RetentionRange -ArgumentList $range, $unit
		Set-PolicyObjective $mpg -RetentionRange $RR -LongTermBackupFrequency $xgrp.LONGTERMPOLICY.Frequency
	}
}
function SetOnlineObjectives {
	param($xgrp, $mpg)
	WRITELOG "CLOUD/ONLINE OBJECTIVES ARE NOT YET IMPLEMENTED" ; return
	# 	$RRlist=@(); $FRQlist=@();$GENlist=@(); 
# 	foreach ($el in $xgrp.ONLINEPOLICY.SCHEDULES.SelectNodes("*") ) {
# 			$FRQlist += GetBckFreqEnum $el.Frequency
# 			$GENlist += $el.Generation
# 			$range = $el.interval ;	$unit = GetUnitString $el.Frequency
# 			$RR = new-object -TypeName Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.OMCommon.RetentionRange -ArgumentList $range, $unit
# 			$RRlist += $RR
# 	}
# 	Set-PolicyObjective $mpg -RetentionRangeList $RRlist -FrequencyList $FRQlist -GenerationList $GENlist
}
function SetTapeOptions {
	param($xgrp, $mpg, $srv)
	writelog ("`tSetting tape options for [{0}]" -f $xgrp.PGPRotectionType)
	#select lib with highest  number drives
	$curLibs = @(Get-DPMLibrary -DPMServerName $srv.Name | ? {(($_.IsOffline -eq $false) -and ($_.IsEnabled -eq $true))})
	$selectlib = $curlibs[0]
	$curlibs | foreach {
		if ($_.GetDriveCollection().Count -ge $selectlib.GetDriveCollection().Count) {
			$selectlib = $_
			writelog ("`tSelecting {0}-drive library [{1}] " -f $_.GetdriveCollection().Count, $_.userfriendlyname)
		}
	}
	if (!($selectlib)) {writelog "WARNING: Skipping library assignment due to no enabled online libraries found" "Cyan"; return;}

	if ($xgrp.PGPRotectionType -eq "DiskToTape") {
		# This is the only tape-shortterm situation
		if ($xgrp.ARCHIVEINTENT.OnsiteCompression -eq "True") {Set-TapeBackupOption $mpg -Shortterm -CompressData}
		if ($xgrp.ARCHIVEINTENT.OnsiteEncryption -eq "True") {
			writelog ("Enabling encryption for group {0} which will disable compression" -f $xgrp.GroupName)
			Set-TapeBackupOption $mpg -Shortterm -EncryptData 
		}
	}
	else {
		#All longterm tape situations
		if ($xgrp.ARCHIVEINTENT.OffsiteCompression -eq "True") {Set-TapeBackupOption $mpg -Longterm -CompressData}
		if ($xgrp.ARCHIVEINTENT.OffsiteEncryption -eq "True") {
			writelog ("Enabling encryption for group {0} which will disable compression" -f $xgrp.GroupName)
			Set-TapeBackupOption $mpg -Longterm -EncryptData 
		}
	}
	#assign libs
	if ($selectlib.GetDriveCollection().count -gt 1) {Set-TapeBackupOption $mpg -BackupLibrary $selectlib -TapeCopyLibrary $selectlib -DrivesAllocated $xgrp.ARCHIVEINTENT.NumberOfDrives}
	else {Set-TapeBackupOption $mpg -BackupLibrary $selectlib -DrivesAllocated $xgrp.ARCHIVEINTENT.NumberOfDrives}

	if ($xgrp.ARCHIVEINTENT.CancelOverlappingJobs -eq "True") {$mpg.ArchiveIntent.CancelOverlappingJobs = $true}
	else {$mpg.ArchiveIntent.CancelOverlappingJobs = $false}
	if ($xgrp.ARCHIVEINTENT.DatasetVerificationIntent-eq "True") { $mpg.ArchiveIntent.DataSetVerificationIntent=$true}
	else {$mpg.ArchiveIntent.DataSetVerificationIntent = $false}
	if ($xgrp.ARCHIVEINTENT.MediaEraseIntent -eq "True") { $mpg.ArchiveIntent.MediaEraseIntent = $true }
	else { $mpg.ArchiveIntent.MediaEraseIntent = $false}
	if ($xgrp.ARCHIVEINTENT.Compression -eq "True") { $mpg.ArchiveIntent.Compression = $true }
	else { $mpg.ArchiveIntent.Compression = $false}
}
function GetBckFreqEnum {
	param ($k)
	# BackupFrequency strings need be passed as representing Int32 of backupfrequency enum list that we mimic here
	switch ($k) {
		"Yearly" {return 6}
		"Halfyearly" {return 5}
		"Quarterly" {return 4}
		"Monthly" {return 3}
		"Biweekly" {return 2}
		"Weekly" { return 1}
		"Daily" { return 0} 
		default {writelog "Unknown BackupFrequency [$k], defaulting to Weekly" "Magenta" ;return 1;}
	}
}
#endregion 

#START
$Error.clear()
$version = "v0.94"
$global:DPMmajor = 0
[datetime]$now = Get-Date
$format = "HH:mm:ss"
$global:MB = 1024 * 1024
$global:GB = 1024 * $MB
$oldpref = $ConfirmPreference
$ConfirmPreference = "None"
$WarningPreference = "SilentlyContinue"
showhelp
#LoadDPMsnapin
if ($configfile -eq "" ) {$configfile = "{0}\DPMsaveConfig.XML" -f , (get-location)}
$logfile = "{0}\DPMcreateConfig.LOG" -f , (get-location)
if (Test-Path $configfile -ErrorAction silentlycontinue) {[xml]$xml = Get-Content $configfile}
else {Throw "Config file not found: $configfile"}

writelog ("Configuration was saved by script version {0} and being parsed by $version" -f $xml.DPMConfig.scriptversion)
foreach ($node in $xml.DPMConfig.SelectNodes("*")) {
	if ($dpmserverlist.count -gt 0) { 
		if ($dpmserverlist -match $node.Dpmservername) {DoDPM $node}
	}
	else {DoDpm $node}

}
writelog "Finished, output saved to $logfile"
$ConfirmPreference = $oldpref
