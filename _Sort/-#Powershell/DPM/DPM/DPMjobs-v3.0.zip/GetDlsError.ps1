# GetDlsError
# Retrieves description to DlsError code from XML ( used to populate P2W)

param ([int[]]$err)
function Translate {
	param ($e, $dls)
	$current = @($dls.ExpectedErrors.SelectNodes("Error[Code='$e']"))
	return  $current[0].message
}
#START
$version = "V1.0"
Write-Host "`nGetDlsError $version" -ForegroundColor white
if ($err.count -lt 1 ) {Write-Host "Usage: GetDlsError <error code>" -ForegroundColor yellow ;exit}
Write-Host "Loading list..." -ForegroundColor green
[xml]$dls = Get-Content .\DlsError.XML

foreach ($e in $err) {
	Write-Host ("`nDlsError [{0}] = {1}" -f $e.tostring("00000000"), (Translate $e $dls )) -ForegroundColor cyan
}
