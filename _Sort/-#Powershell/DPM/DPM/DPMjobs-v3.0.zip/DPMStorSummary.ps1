
#Author	: Ruud Baars
#Date	: 9/30/2009
#v2.0
# v2.1 - worked around regional settings and factor formatting in DPM 'diskallocation string'
# 		    using this string to stick to what DPM 'sees' and reports in UI data source detail pane
# v2.2 - made W2008 compatible, fixed some errors, added QFE check
# v2.3 - fixed  regional settings issues, no longer parsing diskallocation string but get values directly
# v2.4 - changed KB check to june rollup (which is all cumulative to that point)
# v2.5 - Added CSV output 
# v2.6 - Added multiple qfe search and DPMv3 check
# v2.8 - Saving in bytes and using culture info (point/comma seperator differences)
# v2.9 - Changes to better deal with inactive disk data sources 
# 		   Save protected server, not the DPM server.

param ([string]$dpmserver, $checkqfe = @("KB970867","KB970868") )
trap [Exception] { 
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "DPMstorSummary"
	$log.WriteEntry("TRAPPED: $error", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	Write-Host $_.Exception.Message
	$Error.Clear()

}
function CheckForQFE {
	param ($qfestring)
	[boolean]$qt = $false
	$hotfix = (Get-WmiObject -computername $dpmserver Win32_OperatingSystemQFE -property dependent)
	foreach ($l in $hotfix) {
		foreach ($qfe in $qfestring) {
			if ( $l.dependent -imatch $qfe) {
				Write-Host "`t<<< Found QFE $qfe installed >>>" -f green
				$qt = $true
			}
		}
	}
	if (!$gt) {Write-Host "`t<<< None of the specified QFE's  found >>>" -f yellow}
	return $qt
}
$ErrorActionPreference="STOP"

$KB = 1024
$MB = $KB * 1024
$GB = 1024 * $MB
$TB = 1024 * $GB
$version = "v2.9"
$global:cult = New-Object System.Globalization.CultureInfo("en-US")
$outfile = ".\DPMstorSummary.CSV"
write-host "`nDPMstorSummary  $version" -foregroundcolor green
Write-Host "Usage: DPMstorSummary [-dpmserver <name>] [-checkqfe <0 | search string>]`n"
[string[]]$qfestring=@()
$checkqfe | foreach {$qfestring += $_}
if ($qfestring.count -eq 0 ) {$qfestring += "KB970868"}
if (!$dpmserver) {$dpmserver = @(hostname)}

write-host "Collecting information from server $dpmserver...`n" -foregroundcolor white
#get system information

[string]$versionstring = (Get-WmiObject -computername $dpmserver Win32_OperatingSystem -property Version).Version
write-host "Windows version $versionstring" -foregroundcolor green
[int]$osversion = $versionstring.Substring(0,1)

$srv = Connect-DPMServer "$dpmserver"
$dpminfo = $srv.GetProductInformation()

#don't bother when DPM v3
[boolean]$qfecheck = $true
if ($dpminfo.Version.Major -lt 3) {
	$qfecheck = $false
	if ($osversion -lt 6) {
		if ($qfestring.count -gt 0) {[boolean]$qfecheck = CheckForQFE $qfestring}
	}
	else {$qfecheck = $true} #W2008 or later
}

#only if elevant (no QFE)
if (!$qfecheck) {
	[double]$PFsize = (Get-WmiObject -computername $dpmserver Win32_PagefileUsage -property allocatedbasesize).allocatedbasesize #in MB
	Write-Host "Total page file size  		= " ( [math]::Round($PFsize,0)) "MB" -foregroundcolor white
	[double]$PFpeak = (Get-WmiObject -computername $dpmserver Win32_PagefileUsage -property peakusage).peakusage # in MB (=committed on W2k3)
	Write-Host "Peak page file usage 		= " ([math]::Round($PFpeak,0)) "MB" -foregroundcolor white
	[double]$PFcurrent = (Get-WmiObject -computername $dpmserver Win32_PagefileUsage -property currentusage).currentusage # in MB (=comitted on W2k3)
	Write-Host "Current page file usage 	= " ([math]::Round($PFcurrent,0) ) "MB`n" -foregroundcolor white
}

[double]$maxneed = 0
[double]$maxrecom = 0
$pgs = $srv.GetProtectionGroups()
"ProtectedServer`tDSname`tReplUsed`tReplAlloc`tRecoUsed`tRecoAlloc`tPGname" > $outfile
$dss=@(); $pgs | foreach {$dss += Get-DataSource $_}
$dss += Get-Datasource  "$dpmserver" -Inactive

	foreach ($oneds in $dss)
	{

		# get sizes in bytes 
		[double]$used = $oneds.ShadowCopyUsedSpace 
		[double]$alloc = $oneds.ShadowCopyAreaSize
		[double]$replused = $oneds.ReplicaUsedSpace 
		[double]$replalloc = $oneds.ReplicaSize 
				
		("{0}`t{1}`t{2}`t{3}`t{4}`t{5}`t{6}" -f $oneds.PSInfo.NetBiosName, $oneds.name, $replused, $replalloc, $used, $alloc, $oneds.ProtectionGroupName) >> $outfile
		
		#Do not warn if qfecheck not applicable or installed
		if (($used -ge ($PFsize - $PFpeak)) -and (!$qfecheck)) {
				if ($used -ge ($PFsize - $PFcurrent)) {Write-Host "`n*CURRENT* committed +  recovery point usage too high for;" -f red }
				else {Write-Host "`nPEAK committed +  recovery point usage too high for;" -f yellow }
		}
		if ($oneds.isdiskinactive) { 
			write-host ("{0} | {1} | {2}" -f "*INACTIVE*", $oneds.name, $oneds.inactivediskallocation) -foregroundcolor green
		}
		else { write-host ("{0} | {1} | {2}" -f $oneds.protectiongroup.friendlyname, $oneds.name, $oneds.diskallocation) -foregroundcolor green}
		if (($used + $PFcurrent) -gt $maxneed) {$maxneed = ([math]::ceiling($used + $PFcurrent)/$MB).tostring("N0",$cult)}
		if (($alloc + $PFpeak) -gt $maxrecom) {$maxrecom = ([math]::ceiling($alloc + $PFpeak)/$MB).tostring("N0",$cult)}
		write-host "Requires total pagefile space to be: " ([math]::ceiling((($used + $PFcurrent))/$MB).tostring("N0",$cult) ) "MB" -f cyan 	 
	}
 
Write-Host "`n`nRequired total pagefile size	: $maxneed MB (based on current comitted memory and used recoverypoint space)" -foregroundcolor white
Write-Host "Recommended total pagefile size	: $maxrecom MB (based on peak committed memory and allocated recoverypoint space)" -foregroundcolor white


