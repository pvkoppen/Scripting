#Author: Ruud Baars -  4/7/2010
# Synopsis
# Reports failed jobs based on DPMjobsQ -batch mode
#
# v1.0 first draft
# v2.0 added DlsError lookup from fixed XML as $DlsSupplument (if DlsError.XMLfound)
#		job errorinfo does not always have relevant fields filled
#		supplement gives at least general translation of the DlsError -> recommended action
# V2.1 not using shortmessage because not always present
# v2.9 Align with DPMJobsQ.Ps1 now using switches instead of booleans 
# 		remove unconditional disconnect (served IDE debug only)


param([string]$filtername = "", [boolean]$rerun=$false,  [string]$dpmserver = "")
function writelog 
{
	param([string]$msg)
	$msg >> $logfile
	if($debug) {Write-Host $msg}
}

trap [Exception] { 
	writelog "<<< ERROR >>>"
	writelog $("TRAPPED: " + $_.Exception.GetType().FullName); 
	#writelog $("TRAPPED: " + $_.Exception.Message); 
	$Error
	writelog "<<< end >>>"
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "DPMcolocate"
	$log.WriteEntry("TRAPPED: $error", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	$Error.Clear()
	continue; 
}

#START

if ($dpmserver -eq "") {$dpmserver = hostname}
$logfile = "DPMjobsFailed.LOG"
$CSVfile = "DPMjobsFailed.CSV"
$maxlog = 5 * 1024 * 1024 	#5Mb
$format = "MM/dd/yyy hh:mm" #date/time format
$version = "V2.9"
$c = "`," ;$q = "`'" ;$t = "`t"; $qq = "`""; $qcq = "`"`,`""
[xml]$dls = Get-Content .\DlsError.XML -ea silentlycontinue
#set to false for no console output
$Debug = $true
if ($Args.Count -lt 2) {
	$msg = "`nUsage: DPMjobsFailed.ps1 -filtername <string> [-rerun 0/1] [-dpmserver <name>] `n"
	writelog $msg
}
writelog "DPMjobsFailed $version using server $dpmserver"
#ensure logfile does not keep growing endlessly
if ((Get-Item $logfile).length -gt $maxlog) {Remove-Item -path $logfile - confirm:$false}
if ($filtername.Length -eq 0) {
	writelog "Missing required filtername!`n"
	writelog ( .\DPMjobsQ.ps1 -reportfilters  $true)
	writelog "`nRerun specifying -filtername <name> using one of the filters above...`n"
	exit 1
}

$jq=@()
$command = '.\DPMjobsQ.ps1 -filtername $filtername -batch'
writelog "Executing jobs query...`n"
$jq=(Invoke-Expression -command $command)
# DO  NOT REMOVE NEXT LINE, the jobs query runs asynchronous
while (!$jq.IsQueryComplete) {Start-Sleep 1; writelog "Waiting for query to complete"}
if ($jq.jobs.count -eq 0) {writelog "No jobs returned!`n"; exit 1}

#Just create new file with headerline, appending makes no sense for this information
$line = "`"Server`"`,`"Datasource`"`,`"Endtime`"`,`"Tasktype`"`,`"Backuptype`"`,`"DlsError`"`,`"ShortProblem`",`"Action`",`"DetailedError`", `"DlsSupplement`""
$line > $CSVfile

$rerunners=@()
foreach ($job in $jq.jobs) 
{
	foreach ($task in $job.Tasks) 
	{
		if ($task.CanRerun) {$rerunners+=$task}
		$line = $qq + $task.taskinfo.datasource.psinfo.machinename + $qcq + $task.taskinfo.datasource.name 
		$line = $line + $qcq + ($task.endtime) + $qcq + $task.Type + $qcq +  $task.TaskInfo.BackupType 
		if ($dls) {
			$xpathstr = "Error[Code='{0}']" -f  $task.ErrorInfo.DlsErrorCode
			$current = @($dls.ExpectedErrors.SelectNodes("$xpathstr"))
			[string]$msg = $current[0].shortmessage
			if ($msg.trim().length -lt 5 ) {$msg=$current[0].message}
			$DlsSupplement = $msg + " -> " + $current[0].RecommendedAction
		}
		else {$DlsSupplement = "No DlsError XML  file"}
		$line = $line + $qcq + $task.ErrorInfo.DlsErrorCode + $qcq + $task.ErrorInfo.ShortProblem 
		$line = $line + $qcq + $task.ErrorInfo.RecommendedAction + $qcq + $task.ErrorInfo.DetailedErrorCode + $qcq + $DlsSupplement +  $qq
		$line >> $CSVfile
		Write-Host $line
	}
}
if ($rerun) {
	$msg= "`nThere are " + $rerunners.count + " jobs that can rerun!"
	writelog $msg
	if ((Read-Host "Do you want to rerun these jobs [y/N]") -imatch "y") {
		writelog "Triggering jobs rerun, please wait..."
		foreach ($t in $rerunners) {$t.rerun; Write-Host "..." -nonewLine -foregroundcolor cyan }
		writelog "Rerun triggers done!"
	}
}
Write-host "`nOutput to CSV file in following format" -foregroundcolor white
Write-host "Server, Datasource, Endtime, Tasktype, Backuptype, DlsError, ShortProblem, Action, DetailedError" -foregroundcolor cyan
Write-Host "Done!" -foregroundcolor white

