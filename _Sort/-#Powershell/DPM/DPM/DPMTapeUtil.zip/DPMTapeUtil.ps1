# Author	  : Ruud Baars
# Created	 : 5/25/2010 	(#happy birthday)
# Modified	: 9/10/2010
#
# Synopsis: 
# Implement variaty of functions, see parameters below and Showhelp function
# V3.0 
# 	- rewrite/merge of DPMReportAllTapes and DPMForceTapeFree and others
# 	- coded various as separate but combinable functions (mark free/erase/eject/etc..)
# V3.1
# 	- Added one off backup feature
# 	- Changed restoring original preference after last writelog call 
# V3.2
# 	- Added 'Search by group' function, select all tapes for 1 or more groups
# 	- Have CopyPIT output to a path rather than another tape 
#   	using -TargetServer and -TargetPath parameters and CopyOnExist flag
# V3.3 - corrected attaching zip to mail msg
# 		 - implemented overruling switch to do latest RP only 
# 		   This is latest RP for each unique data source across all selected media
# 		- Added $rp.DestinationForRestore to -TargetPath exactly as UI does
# V3.4 - changed scheduling to adjust to tomorrow when time < 'now'
# 		 - to avoid 'schedule in the past error'
# V3.5 - fixed library select by slot= when only 1 library
# V3.6 - fixed: insert space between params when scheduling
# 	     - fixed: do not prompt to erase in batch mode (scheduled)

param (
[string[]]$dpmserverlist = (&hostname), 
[string]$Search,
[string]$Schedule,
[string]$Mailto,
[string]$OneOff,
[string]$TargetPath,
[string]$TargetServer = (&hostname),
[switch]$Export, 
[switch]$Shared, 
[switch]$Scanlib,
[switch]$CopyPIT,
[switch]$TapeErase,
[switch]$Latest,
[switch]$Override,
[switch]$Forcefree,
[switch]$Inventory,
[switch]$Eject,
[switch]$Recatalog,
[switch]$Wait, 
[switch]$Runas,
[switch]$Batch,
[switch]$Cleanup,
[switch]$DeleteAllTasks,
[switch]$Help
)

#region FUNCTIONS

trap [Exception] { 
	writelog $("TRAP: $TN: $Error") red
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "$TN"
	$msg = "$error`n $($Error[0].InvocationInfo.PositionMessage)"
	$log.WriteEntry("TRAP: $TN: $msg", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	Write-Host $Error[0].InvocationInfo.PositionMessage -f red
	$Error.Clear()
	NormalExit $false $retobj
}
function CheckTaskResult {
	param ($msg)
	writelog $msg
	if ($msg -ne $null) {$msg = -join ($msg)}
	if (($msg -inotmatch "SUCCESS") -or (-not $msg)) {Throw "Scheduler reported a failure!"}
}
function MakeZip
{
	param($filecollection)
	writelog "Packing [$($filecollection.count)] files..." 
	if ($filecollection.count -lt 1) {
		writelog "Nothing to zip!" white red
		return $null
	}
	Remove-Item ((Get-Location).Path + "\DPMTapeUtil*.ZIP") -confirm:$false 
	$tmp = (Get-Date).ToString($cult).replace("/","-")
	$tmp = $tmp.replace(" ","_")
	$tmp = $tmp.replace(":","-")
	$newzip = (Get-Location).Path + "\DPMTapeUtil_$($tmp).ZIP" 
	set-content $newzip ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
	$zip = (new-object -com shell.application).NameSpace($newzip) 

	foreach($file in $filecollection) 
	{
		if (-not (Test-Path $file)) {writelog "Could not find [$($file.fullname)]";continue; }
		writelog "Adding: $($file.Fullname)"
		$zip.CopyHere($file.FullName)
		Start-sleep -milliseconds 500
	}
	writelog "Created ZIP: $($zip.self.path)" white
	return $zip
}
function GetCredentials{
	#just a cumbersome but very familiar looking way to prompt forcredentials
#however this returns a secure string and we need clear passw for schtasks 
	param ([string]$user = "")

	if ($user -eq "" ) {$user = (@(whoami))}
	$things = "" | select "User" , "ClearPW" , "Cred"
	if ($batch) {
		$things.User = "SYSTEM"
		$things.ClearPW = ""
		$things.Cred = $null
		return $things
	}
	$cred = $null
	$cred = Get-Credential $user
	$things.Cred=$cred
	$things.user = $cred.UserName
	#retrieve clear password
	$things.clearpw = $cred.GetNetworkCredential().Password
	return $things
}
function RefreshDS {
	param()
	$ps = @(Get-ProductionServer $dpmserver | ? {$_.name -match $TargetServer})
	if ($ps.count -eq 0) {Throw "Server $TargetServer not found!"}
	writelog "Querying data sources on $TargetServer..."
	#dummy inquiry just to make sure DPM knows about all volumes (tbl_IM_Volume)
	$dss = Get-Datasource -ProductionServer $ps[0] -Inquire
	return $ps
}
function CopyPIT {
	param ()
	if ($TargetPath.Length -gt 3) {$ps = @(RefreshDS)}

	foreach ($sourcetape in $retobj.Tapes) {
		$sourcelib = $retobj.Libraries | ? { $_.Id -eq $sourcetape.LibraryId}
		if ($TargetPath.length -lt 3) {
			if ($retobj.Libraries.Count -lt 2) {
				#single library
				if ($sourcelib.GetDriveCollection().Count -lt 2) {
					Throw "Not enough libraries and drives to copy!"
				}
				else {$targetlib = $sourcelib}
			}
			else {
				#multiple libraries
				if ($sourcelib.GetDriveCollection().Count -gt 1) {
					#always use same library if possible (UI does not even give a choice)
					$targetlib = $sourcelib
				}
				else {
					#find another library with compatible drive
					$targetlib = FindCompatibleDriveLib $sourcelib $retobj.Libraries
					if (-not $targetlib) {Throw "No compatible drives found!"}
				}
			}
		}
		# sort default (ascending) because sorting that -unique keeps the last one
		$rps = @(Get-RecoveryPoint -Tape $sourcetape | sort -Property RepresentedPointInTime )
		$rps = $rps | sort -Property DatasourceId -Unique
		#we now have newest recovery point of each unique data source on tape
		if ($rps) {$retobj.PIT += $rps} 

		foreach ($rp in $rps) {
			#we might have an issue here with multiple resource locations return (cannot test currently)
			$rsl = ($rp.RecoverySourceLocations | ? {$_.Validity -eq "Valid"} | sort -Property expirydate -Descending)
			writelog "Copying data source: $($rp.datasource.logicalpath)"
			if ($TargetPath.Length -lt 3) {
				writelog "Copy PIT [$($rp.representedpointintime)] from [$($sourcelib.userfriendlyname)] to [$($targetlib.userfriendlyname)]"
				$j = Copy-DPMTapeData -RecoveryPointLocation $rsl -RecoveryPoint $rp -SourceLibrary $sourcelib -TargetLibrary $targetlib -TapeLabel $sourcetape.label -TapeOption 0
			}
			else {
				$EndTargetPath = "$Targetpath\$($rp.DestinationForRestore)"
				writelog "Copy PIT [$($rp.representedpointintime)] from [$($sourcelib.userfriendlyname)] to [$EndTargetPath] on $TargetServer"
				$j = Copy-DPMTapeData -RecoveryPoint $rp -Tape $sourcetape -TargetServer $ps[0].name -TargetPath $EndTargetPath -OverwriteType OverWrite
			}
			if ($j) {$retobj.Jobs += $j}
			AddLine $dpmserver $now $tape $copyfile $rp
		}
	} 
	return 
}
function CopyLatestPIT {
	param ()
	writelog "Copying latest PIT to disk..."
	$ps = @(RefreshDS)
	foreach ($item in $retobj.Latest) {
		$sourcelib = $retobj.Libraries | ? { $_.Id -eq $item.tape.LibraryId}
		#we might have an issue here with multiple resource locations return (cannot test currently)
		$rsl = ($item.PIT.RecoverySourceLocations | ? {$_.Validity -eq "Valid"} | sort -Property expirydate -Descending)
		$EndTargetPath = "$Targetpath\$($item.PIT.DestinationForRestore)"
		writelog "Copy PIT [$($item.PIT.representedpointintime)] from [$($sourcelib.userfriendlyname)] to [$EndTargetPath] on $TargetServer"
		$j = Copy-DPMTapeData -RecoveryPoint $item.PIT -Tape $item.Tape -TargetServer $ps[0].name -TargetPath $EndTargetPath -OverwriteType OverWrite
		if ($j) {$retobj.Jobs += $j}
		AddLine $dpmserver $item.PIT.RepresentedPointInTime $item.tape $copyfile $item.PIT
	}
}
function FindCompatibleDriveLib {
	param ($libtomatch, $libcollection)
	#We are here to find another, take out source ref
	$searchcol = @($libcollection | ? { $_.Id -ne $sourcelib.Id})
	#Take supported media from first (assume drive tpes within library are same)
	$mediatomatch = (@($sourcelib.getdrivecollection())[0]).mediatypessupported
	$mediatomatch = "fuckit"
	writelog "Searching libraries for [$mediatomatch] compatable drive..."
	foreach ($L in $searchcol) {
		foreach ($D in $L.Getdrivecollection()) {
			if ($D.MediaTypesSupported -eq $mediatomatch){
				writelog "Selected compatible library [$($L.userfriendlyname)]"
				return $L
			}
		}
	}
	return $null
}

function NormalExit {
	param ($state, $retobj)
	#Restore preference not before last writelog
	$retobj.Files = @()
	$retobj.Files += Get-Item "$homepath\$TN*.log"
	$retobj.Files += Get-Item "$homepath\$TN*.csv" 

	$retobj.Libraries = @($retobj.Libraries | ? {$_})
	$retobj.Tapes= @($retobj.Tapes| ? {$_})
	$retobj.Jobs = @($retobj.Jobs| ? {$_})
	$retobj.Files= @($retobj.Files| ? {$_})

	if ($state) {
		writelog ("All done, returning structure with;" -f $retobj.Jobs.count) white 
		writelog "`t_.Libraries = $($retobj.Libraries.count) library objects" 
		writelog "`t_.Tapes     = $($retobj.Tapes.count) tape objects" 
		writelog "`t_.Jobs      = $($retobj.Jobs.count) job objects" 
		writelog "`t_.PIT       = $($retobj.PIT.count) recovery point objects" 
		writelog "`t_.Files	    = $($retobj.Files.count) file objects" 
		writelog "Normal exit!" white blue
		$ConfirmPreference = $OrgConfirmPreference
		return
	} 
	else {writelog "Exit on failure or aborted!" white red} 
	$ConfirmPreference = $OrgConfirmPreference
	writelog "Exit!" white blue
	exit $retobj
}

function writelog {
	param([string]$msg, $color = "Green", $bcolor = "Black")
	$msg = "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	# catch all if batch mode
	if (-not $batch) {Write-Host $msg -ForegroundColor $color -BackgroundColor $bcolor}
}

function SpecialOut {
	param ($title, $dolist) 
	#for some reason we get array with 1 null but count =1
	if (-not $dolist) {return}
	# Cumbersome way to console output but avoids this becoming part of return job object list!
# see "http://keithhill.spaces.live.com/Blog/cns!5A8D2641E0963A97!811.entry" for detailed explanation
	writelog "$title..." white
	writelog ("{0}{1}{2}{3} " -f "Location".PadRight(10), "State".Padright(10), "Library".Padright(20), "Label") white
	$dolist | foreach {writelog ("{0}{1}{2}{3}" -f ($_.location.tostring()).Padright(10), ($_.datasetstate.tostring()).Padright(10), ($_.libraryname.tostring()).padright(20),$_.Displaystring) }
}
function PrepSrv {
	param ($srv, $taskscript) 
	writelog "Checking out remote server..."
	$remotedir = "\\$srv\$($taskscript.directoryname)"
	$remotedir = $remotedir.replace(":", "$")
	if (-not (Test-Path $remotedir)) {
		$newdir = New-Item $remotedir -ItemType directory -confirm:$false
		if (-not $newdir) {Throw "Could not create: $remotedir"}
		writelog "Created [$remotedir]"
		$remotedir = $newdir
	}
	$remotescript = "\\$srv\$($taskscript.directoryname)"
	$remotescript = $remotescript.replace(":","$") 
	if (-not (Test-Path $remotescript)) { 
		writelog "Copying script to target ..."
		Copy-Item $taskscript $remotedir -confirm:$false
	}
}

function ScheduleTask {
	param ($dpmserver, $scriptfile, $pcol )
	$sch = @($pcol.Item("Schedule").split("|"))
	$dpmserver = $dpmserver.ToUpper()

	# prepare remote server to run scheduled task
	if ($dpmserver -notmatch (&hostname)) {
		PrepSrv $dpmserver (Get-Item (Resolve-Path $scriptfile))
	}

	if ($sch.count -lt 4) {Throw "Missing schedule element: $sch" }
	# ref list
	$monthdays = @(); for ($i = 1;$i -le 31; $i++) {$monthdays += $i}
	$weekdays = @("MON","TUE","WED","THU","FRI","SAT","SUN","*")

	if ("ENABLED" -match $sch[0]) {$sch[0]="ENABLE"}
	if ("DISABLED" -match $sch[0]) {$sch[0]="DISABLE"}
	switch ($sch[0].ToUpper()) {
		"ENABLE" {[boolean]$taskstate = $true}
		"DISABLE" {[boolean]$taskstate = $false}
		default {Throw "Invalid taskstate field: $schedule"}
	}

	$time = (Get-Date($sch[3])).tostring("HH:mm")
	$day = $sch[2] #same for all except when $mo is used
	$period = $sch[1].ToUpper()
	switch ($period) {
		"MONTHLY" {
			if (!($monthdays -contains $day)) {Throw "Invalid $period day number  [1-31]: $schedule" }
		}
		"WEEKLY" {
			if (!($weekdays -contains $day)) {Throw "Invalid $period 3-char day name: $schedule" }
		}
		"DAILY" {
			$mo = $sch[2];$day = ""
			if (($mo -lt 1) -or ($mo -gt 365)) {Throw "Invalid $period modifier: [$mo]" }
		} 
		"HOURLY" {
			$mo = $sch[2]; $day = ""
			if (($mo -lt 1) -or ($mo -gt 23)) {Throw "Invalid $period modifier: [$mo]" }
		}
		"MINUTE" {
			$mo = $sch[2]; $day = ""
			if (($mo -lt 1) -or ($mo -gt 1439)) {Throw "Invalid $period modifier: [$mo]" }
		}
		"ONCE" {
			$day = "";$sd = ($sch[2]).padleft(10,"0")
		}
		default {Throw "Invalid schedule period: $schedule"}
	}

	#build taskname
	$taskname = $null
	$nr = 0
	$msg = schtasks /QUERY /S $dpmserver
	do {
		$taskname = -join ($TN.ToUpper(),"-",$nr) 
		$nr++
	}
	while ($msg -match $taskname)
	writelog "Scheduling this script as $taskname"

	#must use triple literals to avoid interpretation of wildcard spec before actual runtime
	if ($pcol.keys -contains "oneoff") {$pcol.item("oneoff") = "'''{0}'''" -f $pcol.item("oneoff")}
	foreach ($key in $pcol.keys) {
		if ($key -match "dpmserverlist") {continue;} #skip, defaults to local as intended
		if ($key -match "schedule") {continue;} # skip, we don't schedule to schedule
		if ($key -match "runas") {continue;} # skip, this is to schedule, not a task run param
		if ($pcol.item($key).Ispresent) {$params = -join ($params," -",$key)}
		else { $params = -join ($params," -",$key," ", "`"", $pcol.item($key),"`"")}
	}
	$params = -join ($params, " -Batch")
	writelog "Using parameters: $params"

	#build command and schedule
# must use "/RL HIGHEST" because task needs registry access
	$thisscript = "`"`"`"`"powershell`"`"`" -noninteractive -nologo -command `"`"`"&{$scriptfile $params}`"`"`""
	$cleanscript = "`"`"`"`"powershell`"`"`" -noninteractive -nologo -command `"`"`"&{$scriptfile -cleanup}`"`"`""

	$msg = $null
	#create task
	if ($RU -eq "") {$RU = "SYSTEM"; $RP = ""}
	#set recurring for tomorrow if before 'now' to avoid schedule in the past error
	if ((get-date($time)).subtract((Get-Date)) -lt 0) {
		$date = (Get-Date).AddDays(1)
	}
	else {$date = Get-Date}
	$sd = $date.ToString("MM/dd/yyyy",$cult)

	switch ($period) {
		"MONTHLY" { 
			$msg = @(schtasks /CREATE /F /RL "HIGHEST" /S $dpmserver /TN $taskname /SD $sd /SC $period /D $day /ST $time /RU "$RU" /RP "$RP" /TR $thisscript ) 
		}
		"WEEKLY" {
			$msg = @(schtasks /CREATE /F /RL "HIGHEST" /S $dpmserver /TN $taskname /SD $sd /SC $period /D $day /ST $time /RU "$RU" /RP "$RP" /TR $thisscript )
		}
		"ONCE" {
			$msg = @(schtasks /CREATE /F /RL "HIGHEST" /S $dpmserver /TN $TN - CLEANUP /SD $sd /SC "DAILY" /ST "12:00" /RU "$RU" /RP "$RP" /TR $cleanscript )
			CheckTaskResult $msg
			$taskname = "$taskname-ONCE"
			$msg = @(schtasks /CREATE /F /RL "HIGHEST" /S $dpmserver /TN $taskname /SC $period /SD $sd /ST $time /RU "$RU" /RP "$RP" /TR $thisscript )
		}
		default {
			$msg = @(schtasks /CREATE /F /RL "HIGHEST" /S $dpmserver /TN $taskname /SC $period /MO $mo /ST $time /RU "$RU" /RP "$RP" /TR $thisscript )
		}
	}
	CheckTaskResult $msg

	if (!$taskstate) {
		# disable task
		$msg = $null
		$msg = @(schtasks /CHANGE /S $dpmserver /TN $taskname /DISABLE)
		writelog $msg
		if ($msg -ne $null) {$msg = -join ($msg)}
		if (($msg -inotmatch "SUCCESS") -or (-not $msg)) {Throw "Scheduler reported a failure on /CHANGE"}
		writelog ("Task $taskname is DISABLED, use the following command to enable;") 
		writelog ("SCHTASKS /CHANGE /S $dpmserver /TN $taskname /ENABLE") magenta
	}
	else {writelog "Task $taskname is ENABLED"}
	writelog "Scheduling done on $dpmserver " white
	return $taskname
}

function Showhelp {
	#just help page
#catch all if batch mode 
	if ($batch) {return}
	write-host "`nUSAGE" -ForegroundColor green
	Write-Host -f white @("
 `$obj = .\DPMTapeUtil.Ps1 [-dpmserverlist []] one or more parameters as per below
	Returns `$obj.Libraries[], `$obj.Tapes[], `$obj.Jobs[], `$obj.PIT[], `$obj.Files[]
	and `$obj.Dates{} key/value pairs, the keys are; 'begin' , 'end' , 'expire' 
	")
 write-host "DESCRIPTION" -ForegroundColor green
	Write-Host -f cyan @("
 Processes selected tapes, see PARAMETERS below for selection abilities
	As indication of progres display various messages and;
	'T_' for each tape processed 
	'P_' for each PIT copy 
	'F_' for each tape forced marked free (removes recovery points)
	'r_' for each recovery point processed
	")
write-host "PARAMETERS" -ForegroundColor green
	Write-Host -f cyan @("
 -Dpmserverlist
	<> [path\file] file with 1 servername per line
	<> [string] `"dpm1,dpm2`", comma separated list, defaults to localhost only
 
	-Export [switch], to export tape recovery point details to CSV file (time consuming)
	-Shared [switch], to process tapes belonging to another DPM server within shared library
	-Forcefree [switch], forceably mark tape, removes all recovery points on tape 
	-TapeErase [switch], to erase tape if datasetstate = 'Recyclable'
	-DeleteTasks [switch], to delete all DPMTapeUtil tasks regardless of status
	-Override [switch], overrides 'datasetstate' to free/erase and 'unknown' to inventory
	-Eject [switch], to eject selected tapes out of library using I/E port 
	-Inventory [switch], run detailed inventory on selected tapes
	-Recatalog [switch], recatalog tapes (not recovery point details)
	-CopyPIT [switch], copy newest recovery point to another tape
	-Scanlib [switch], to trigger a library scan (and resolve library alerts)
	-Mailto [string], valid smtp mail address like: user@domain
	-OneOff [server|datasource|type], to schedule 1 time backup 
	-Wait [switch], to wait for all jobs to complete before exiting")
Write-Host -f red @("
 [primarily Internal Use or calling from another script]
	-Batch [switch], silent mode without any confirmations (potentially dangerous!)
	-Cleanup [switch], used to run the cleanup task with schedule 'ONCE'
	-DeleteAllTasks [switch], used with -Cleanup to delete all tasks
	")
 
	Write-Host -f yellow @("
 -Search [string] match slot specification as per below;
	<> [sub]string to match with label-string or barcode [-or-]

	<> `"state=...`" Valid/Recyclable/None/Unknown/Imported/Freedate/Offsite/Expired
 <> `"slot=1-10|LIB2`" means slot-1 through slot-10 selecting 10 slots from *LIB2*
 <> `"slot=1,10|LIB1`" means slot-1 and slot-10 selecting 2 slots from *LIB1*
 <> `"written= <100.05|MB`", written less than 100.50 MB 
 <> `"written= >500.50|GB`", written 500.50 GB or more 
 <> `"ExpiresBy = dd/mm/yyyy hh:mm`", tapes that will be expired by this date
 <> `"span = dd/mm/yyyy hh:mm > dd/mm/yyyy hh:mm`", start > end (start is optional)")

	Write-Host -f white @("
 -Schedule [string] as below on listed server(s)
	<> `"ENABLE|MONTHLY|14|20:00`", every 14th of the month at 8:00 PM, task enabled 
 <> `"ENABLE|WEEKLY|SAT|05:00`", every Saturday at 5:00 AM, task enabled
 <> `"DISABLE|DAILY|1|13:00`", every 1 day at 1:00 PM, task disabled
 <> `"DISABLE|HOURLY|4|13:00`", starting 13:00 repeat every 4 hours
 <> `"DISABLE|MINUTE|30|14:00`", starting 14:00 repeat every 30 minutes
 <> `"ENABLE|ONCE|05/25/2010|23:00`", run once May 25th, 2010 at 23:00")
	Write-Host -f green @("
 if following registry entry exists and drive supports it DPM will use quick erase
	HKLM\SOFTWARE\Microsoft\Microsoft Data Protection Manager\Agent\UseShortErase=0
	") 
 exit $null
}

function MakeHeader {
	param ($outputfile )
	[string]$t = "`t"
	$line = "DPMSERVER".PadRight(15) + $t + "LABEL".padright(9) + $t + "DATE".PadRight(20) + $t + "DATASET STATE".padright(20) + $t 
	$line += "BARCODE".padright(14) + $t + "OFFSITE" + $t + "STATE".padright(10) + $t + "OMIDSTATE".padright(10) + $t 
	$line += "LOCATION".PadRight(24) + $t + "LIBRARY".padright(26) + $t + "GROUP" + $t + "DATASOURCE" 
	$line > $outputfile
}

function AddLine {
	param ($srv, $PIT, $tape, $outputfile , $rp = $null)
	#for some reason we get array with 1 null but count =1
	if (-not $tape) {return} 
	if (-not (Test-Path $outputfile)) {MakeHeader $outputfile}
	[string]$t = "`t"
	$freelabel = "Free" #substitute same as UI
	$freedate = "01/01/1980 00:00 AM" #ensure some valid date but clearly fake
# dpmserver, label, backup, datasetstate, library, barcode, offsite, group, DatasetState, Omid, Suspect, Group, Datasource 
	$line = ""
	$line += $srv + $t
	$now = (Get-Date).ToString($format)
	if ($tape.label.length -gt 0 ) { 
		if ($export) {$line += $tape.DisplayString + $t + $PIT + $t }
		else {$line += $tape.DisplayString + $t + $now.padright(20) + $t }
	} 
	else {
		if ($export) {$line += $freelabel.padright(9) + $t + $freedate.padright(20) + $t }
		else {$line += $freelabel.padright(9) + $t + $now.padright(20) + $t }
	}
	if ($rp) {
		$dsname = $rp.DataSource.Name; $grpname = $rp.DataSource.ProtectionGroupName
	} 
	else {$dsname = "not applicable"; $grpname = "not applicable"}
	$line += $tape.Datasetstate.tostring().PadRight(10) + $t + $tape.Barcode.ToString().padright(14) + $t + $tape.IsOffsiteReady.tostring() + $t
	$line += $tape.DatasetState.ToString().PadRight(10) + $t + $tape.OmidState.ToString().padright(10) + $t 
	$line += $tape.Location.ToString().Padright(24) + $t + $tape.LibraryName.padright(26) + $t + $grpname + $t + $dsname
	$line >> $outputfile
}

function ForceTapeFree {
	param ($freetapes, $forcefreefile, $dpmserver)
	foreach ($tape in ($freetapes | sort-object -property label -descending )) {
		if ($tape -is [Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.LibraryManagement.ArchiveMedia]) {
			foreach ($rp in @(Get-RecoveryPoint -Tape $tape))
			{
				[void] (Get-RecoveryPoint -Datasource $rp.Datasource)
				write-host "r_" -foregroundcolor white -BackgroundColor red -noNewLine 
				[void](Remove-RecoveryPoint -RecoveryPoint $rp -ForceDeletion -confirm:$false)
				AddLine $dpmserver $now $tape $forcefreefile $rp
			}
			Set-Tape -Tape $tape -Free
		}
		else {Writelog "The tape in $($tape.Location) is a cleaner tape";continue; }
		write-host "F_" -foregroundcolor white -BackgroundColor darkred -noNewLine 
	} 
	Write-Host ""
}

function TriggerEraseTapes {
	param ($dpmserver, $erasetapes, $erasefile )
	#for some reason we get array with 1 null but count =1
	if (-not $erasetapes) {return}
	foreach ($tape in $erasetapes) {
		$j = (Start-TapeErase -Tape $tape)
		if ($j) {
			$retobj.Jobs += $j
			$now = (get-date).tostring($format)
			AddLine $dpmserver $now $tape $erasefile
		}
	}
}

function BuildSlotCollection {
	param ($search, $lib)
	$search = $search.Replace(" ","")
	$search = $search.Tolower()
	$search = $search.trimstart("slot=") 
	if ($search -match ",") {
		#Split fill the indexes
		[int[]]$indexes = @($search.split(","))
	}
	else {
		#Fill indexes from lowest through highest
		$indexes = @()
		[int[]]$lohi = $search.split("-")
		if ($lohi.count -eq 1) {$indexes += $lohi[0]}
		else {
			if ($lohi[0] -gt $lohi[1]) {
				#swap lo/hi values
				$tmp = $lohi[0]
				$lohi[0]=$lohi[1]
				$lohi[1]=$tmp
				writelog "Swapped low/high slot values!" yellow
			}
			if ($lohi[0] -lt 1) {$lohi[0]=1}
			$i = $lohi[0]
			for ($i -eq $lohi[0]; $i -le $lohi[1];$i++) {
				$indexes += $i
			}
		}
	}
	$indexes = @($indexes | sort)
	writelog "Highest slot number for [$($lib.userfriendlyname)] = $($lib.GetSlotCollection().count)" 
	if ($lib.GetSlotCollection().count -lt $indexes[$indexes.GetUpperBound(0)]) {
		Throw "Too high slotnumber used [$search]"
	}
	return $indexes
}

function ScanLib {
	param ($dpmserver)
	writelog "Library rescan: resolving library alerts on  $dpmserver..."
	$srv = Connect-DPMServer -DPMServerName $dpmserver
	$srv.AlertController.RefreshAlerts()
	$alerts = @()
	$alerts += @($srv.AlertController.ActiveAlerts.Values | where {$_.Type.ToString() -eq " LibraryNotAvailableAlert "} )
	$alerts += @($srv.AlertController.ActiveAlerts.Values | where {$_.Type.ToString() -eq " LibraryDriveAlert "} )
	writelog "Resolving [$($alerts.count)] alerts..."
	foreach ($a in $alerts) {
		$a.TakeRecommendedAction()
		$a.ResolveAlert() 
	}
	return (Start-DPMLibraryRescan $dpmserver -Full)
}
function GetSizeInBytes{
	param ([string]$expr)
	#ensure we get numbers in EN-US (decimal/thousand seperator stuff)
	if (($expr.Split(" ")).count -lt 2) {Throw "Missing number or unit in: $expr"}
	[double]$written = ([double]$expr.Split(" ")[0]).tostring("N2",$cult)
	$factor = $expr.split(" ")[1]
	$factor = $factor.trim().toupper()
	switch ($factor) {
		"KB" {$written = $written * $KB}
		"MB" {$written = $written * $MB}
		"GB" {$written = $written * $GB}
		"TB" {$written = $written * $TB}
		default {Throw "Could not interpret size expression: $expr"}
	}
	return $written
}

function TapeLoop {
	# we only get tapes here selected by -search (if used)
	param ($retobj)
	$tmp = @()
	$PairsOfLatest = @{} #DatasourceId as key and $item values

	foreach ($tape in $retobj.Tapes) {
		write-host "T_" -foregroundcolor white -BackgroundColor blue -noNewLine 
		if ($override) {
			if ($tapeerase) {$tmp += $tape}
		}
		else {if (($tapeerase) -and ($tape.Datasetstate -eq "Recyclable" )) {$tmp += $tape}}

		$rps = $null
		$rps = @(Get-RecoveryPoint -Tape $tape | Sort-Object -Property RepresentedPointInTime )
		if ($rps.count -lt 1) {continue;}

		if ($latest) {
			# previous ascending sort + unique on id below gives latest for each DS
			$UniqueDsLatest = $rps | sort -Property DatasourceId -Unique
			foreach ($rp in $UniqueDsLatest) {
				$item = "" | select PIT, Tape
				$item.PIT = $rp
				$item.Tape = $tape
				if ($PairsOfLatest.keys -contains $rp.DatasourceId) {
					if (($PairsOfLatest[$rp.DatasourceId]).PIT.representedpointintime -lt $rp.representedpointintime ) {
						$PairsOfLatest[$rp.DatasourceId] = $item
					}
				}
				else {$PairsOfLatest.Add($rp.datasourceid,$item)}
			}
		}
		else {
			if ($retobj.dates.keys.count -gt 0) {
				if ($retobj.Dates.Keys -match "expire") {
					if (($rps | foreach {$_.RecoverySourceLocations | ? {$_.expirydate -gt $retobj.Dates.Item("end")} }) -eq $null) { 
						$tmp += $tape
						$retobj.PIT += $rps
						AddLine $dpmserver $now $tape $expiredfile $rps[$rps.count-1]
					}
				}
				else{
					if (($rps[0].RepresentedPointInTime -ge $retobj.Dates.Item("start")) -and ( $rps[0].RepresentedPointInTime -le $retobj.Dates.Item("end"))) { 
						$tmp += $tape
						$retobj.PIT += $rps
						AddLine $dpmserver $now $tape $spanfile $rps[$rps.count-1]
					}
				}
			}
			else {$retobj.PIT += $rps}
		} #end if latest

		if ($export) {
			foreach ($rp in $retobj.PIT) {
				Write-Host "r_" -foregroundcolor white -BackgroundColor red -noNewLine
				AddLine $dpmserver $rp.RepresentedPointInTime $tape $exportfile $rp
			} 
		} 
	} #END TAPE LOOP

# adjust to latest when asked
	if ($latest) { 
		$tmp = $null
		$retobj.Tapes=@()
		$retobj.PIT=@()
		$retobj.Latest = $pairsoflatest.Values
		foreach ($val in $PairsOfLatest.Values) {
			$retobj.Tapes += $val.tape
			$retobj.PIT += $val.PIT
			AddLine $dpmserver $val.PIT.RepresentedPointInTime $val.tape $latestfile $val.PIT
		}
	}

	# if we selected something take it or if erasing take even nothing
	if (($tmp) -or ($tapeerase)) {
		$retobj.Tapes = @($tmp) 
		#adjus PIT to current tape set
		$retobj.PIT=@()
		$retobj.Tapes | foreach {$retobj.PIT += (Get-RecoveryPoint -Tape $_) }
	}
	Write-Host ""
	return $retobj
}
function Search {
	param($searchtapes, $retobj)
	writelog "Processing search string..." white blue
	$span = $null
	$slots = $null
	switch (($search.split("=")[0]).ToUpper() ) {
		"GROUP" {
			writelog "Selecting by group..."
			$tmplist = @()
			$grplist = @(($search.trimstart("groups=")).Trim().split(","))
			foreach ($grp in $grplist) {$tmplist += $searchtapes | ? {$_.ProtectionGroupName -match $grp}}
			$searchtapes = $tmplist
			foreach ($tape in $searchtapes) {
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $groupfile
			}
		}
		"WRITTEN" {
			writelog "Selecting by written.."
			$refsize = $null
			$search = $search.Replace("|", " ")
			if ($search -match "<") {
				[double]$refsize = GetSizeInBytes ($search.Split("<")[1])
				$searchtapes = @($searchtapes | ? {$_.HasValidDatasets()})
				$searchtapes = @($searchtapes | ? {(GetSizeInBytes $_.DataWrittenDisplaystring) -lt $refsize})
			}
			else {
				[double]$refsize = GetSizeInBytes ($search.Split(">")[1])
				$searchtapes = @($searchtapes | ? {$_.HasValidDatasets()})
				$searchtapes = @($searchtapes | ? {(GetSizeInBytes $_.DataWrittenDisplaystring) -ge $refsize})
			}
			foreach ($tape in $searchtapes) {
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $writtenfile
			}
		}
		"STATE" { 
			$state = $search.split("=")[1]
			$tmp = @()
			switch ($state.toupper()) {
				"VALID" {$searchtapes = @($searchtapes | ? {$_.DatasetState.Tostring().ToUpper() -eq "VALID"})}
				"UNKNOWN" {$searchtapes = @( $searchtapes | ? {$_.DatasetState.Tostring().ToUpper() -eq "UNKOWN"})}
				"NONE" {$searchtapes = @( $searchtapes | ? {$_.DatasetState.Tostring().ToUpper() -eq "NONE"})}
				"RECYCLABLE" {$searchtapes = @( $searchtapes | ? {$_.DatasetState.ToString().ToUpper() -eq "RECYCLABLE"})}
				"OFFSITEREADY" {$searchtapes = @( $searchtapes | ? {$_.IsOffsiteReady -eq $true})}
				"IMPORTED" {$searchtapes = @( $searchtapes | ? {$_.Displaystring -match "imported"})}
				"FREEDATA" {$searchtapes = @( $searchtapes | ? {$_.Displaystring -match "contains data"})}
				"CLEANING" {$searchtapes = @( $searchtapes | ? {$_ -isnot [Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.LibraryManagement.ArchiveMedia]})}
				default {Throw "Unknown state selection: $search"}
			}
			writelog "Reduced tape collection to state: $state" yellow
			foreach ($tape in $searchtapes) {
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $statefile
			}
		}
		"SLOT" { 
			writelog "Selecting by slot and library..."
			if ($retobj.Libraries.count -gt 1) {
				$libsearch = $search.split("|")[1]
				$lib = @($retobj.Libraries | ? {$_.userfriendlyname -match $libsearch})
				if ($lib.Count -gt 1) {Throw "Too many matching online libraries: $search"}
				if ($lib.Count -lt 1) {Throw "No matching online library found: $search"}
				$retobj.Libraries = @($lib)
			}
			writelog "Reduced libraries searched to [$($retobj.Libraries[0].userfriendlyname)]" yellow
			$slots = BuildSlotcollection $search.split("|")[0] $retobj.Libraries[0]
			#Now add tapes by slots
			$tmp = @()
			foreach ($i in $slots) {
				$tmp += @($searchtapes | ? {(($_.location.id -eq $i) -and ($_.libraryname -match $libsearch))})
			}
			$searchtapes = @($tmp)
			foreach ($tape in $searchtapes) {
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $slotsfile
			}
		}
		"SPAN" { 
			writelog "Selecting by time span..."
			$search = $search.Tolower()
			$search = $search.trimstart("span=") 
			#ensure ">" we swap high low anyway if needed
			if ($search -match "<" ) {$search.Replace("<",">")}
			if ($search -match ">") { 
				[datetime[]]$span = @($search.split(">"))
				if ($span[0] -eq $span[1]) {Throw "No timespan because Start/End are same $search"}
				#ensure oldest first else swap
				if ($span[0] -gt $span[1]) {$tmp = $span[0];$span[0]=$span[1];$span[1]=$tmp}
				$span[0]=([datetime]$span[0]).tostring($format)
				$span[1]=([datetime]$span[1]).tostring($format)
			}
			else {
				$span = @("1/1/1980 00:00", $search) 
			}
			$retobj.Dates.Add("begin",[datetime]$span[0])
			$retobj.Dates.Add("end",[datetime]$span[1])
			#we actually select when building EraseSpan list later
#avoiding processing tape & recovery points more than once
		}
		"EXPIRESBY" {
			$search = $search.Tolower()
			$search = ($search.trimstart("expiresby=")).Trim()
			if ($search -eq "") {$search = (get-date).tostring($format)}
			#simple fill the span[1], we'll process during span processing later
#again avoid processing all recovery points more than once
			$span = @("1/1/1980 00:00", $search) 
			$retobj.Dates.Add("begin",[datetime]$span[0])
			$retobj.Dates.Add("end",[datetime]$span[1])
			$retobj.Dates.Add("expire",[datetime]$span[1])
			writelog "Selecting tapes that have expired by [$($span[1])]..."
		}
		default { 
			# select tapes on string match
			writelog "Selecting by string match..."
			$searchtapes = @($searchtapes | ? {($_.DisplayString -match $search) -or ($_.barcode -match $($search)) })
			foreach ($tape in $searchtapes) {
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $matchfile
			}
		}
	}
	$retobj.tapes = @($searchtapes)
	return $retobj
} 
function SendMail {
	param($mailto, $mailfile)
	#if something missing set $mailto $null so we don't get here again
	if (!$mailto) {(writelog "No mail recipient specified" white red); $mailto = $null; return }
	if (!$mailfile) {(writelog "No attachment specified" white red); $mailto = $null; return } 
	writelog "Gathering mail information..." 

	# need DPM serverobject to get smtp properties
# Get-DPMGlobalPropertyValue cmdlet does not do these
	Disconnect-DPMServer (&hostname)
	$dpmobj = Connect-DPMServer (&hostname)
	$smtprelay = $dpmobj.GetGlobalPropertyValue("Smtpservername")
	if (!$smtprelay) {(writelog "SMTP relay not configured" white red); $mailto = $null; return } 
	$mailfrom = $dpmobj.GetGlobalPropertyValue("Smtpserversenderaddress")
	if (!$mailfrom) {(writelog "FROM address not configured" white red); $mailto = $null; return } 

	$Error.Clear()
	[void][system.reflection.assembly]::loadwithpartialname("system.web") 
	if ($Error.Count -gt 0) {Throw "$error"}
	$msg = New-Object System.Web.Mail.MailMessage
	$msg.From = $mailfrom
	$msg.to = $mailto
	$msg.Subject = "DPMTapeUtil output from server $(&hostname)"
	$msg.Body = "DPMTapeUtil output files zipped and attached"
	writelog "SMTP relay : [$smtprelay]"
	writelog "From address : [$mailfrom]"
	writelog "Subject : $($msg.Subject)"
	$att = new-object System.web.mail.MailAttachment ((resolve-path $mailfile),"UUENCODE")
	$msg.Attachments.Add($att)
	[System.Web.Mail.SmtpMail]::SmtpServer=$smtprelay 
	writelog "Attempting to send now..."
	[System.Web.Mail.SmtpMail]::Send($msg)
	writelog "Mailing $($mailfile.basename) done" white blue
	Remove-Item (Resolve-Path $mailfile) -ea SilentlyContinue -confirm:$false
}

function CleanupTasks {
	param ($srv)
	writelog "Searching tasks to cleanup..."
	$tasklist = @(schtasks /QUERY /S $srv )
	$tasklist = @($tasklist -match $TN)
	if ($DeleteAllTasks) {
		writelog "Deleting all $TN tasks!" white red
		foreach ($task in $tasklist) {
			$taskname = $task.split()[0]
			DeleteTask $taskname $srv
		}
		return;
	}
	$tasklist = @($tasklist -match "ONCE")
	if ($tasklist.count -lt 1) {
		writelog "No *$tasksearch* tasks found to cleanup!"
		return;
	}
	foreach ($task in $tasklist) {
		#split into items and remove empty ones
		$taskitems = @($task.split() | ? {$_})
		$taskname = $taskitems[0]
		# 'ONCE' tasks that are disabled or scheduled in the past ("n/a") won't run anyway
		if (($taskitems[1] -match "disabled") -or ($taskitems[1] -match "n/a")) {
			DeleteTask $taskname $srv
			return;
		}
		$schdate = $taskitems[1] 
		$schtime = "$($taskitems[2]) $($taskitems[3])"
		if ((Get-Date "$schdate $schtime") -lt (Get-Date)) {
			DeleteTask $taskname $srv
		}
	}
}
function DeleteTask {
	param ($delname, $delsrv)
	writelog "Deleting task: $task" yellow
	$msg = $null
	$msg = @(schtasks /DELETE /S $delsrv /TN $taskname /F)
	if ($msg -ne $null) {$msg = -join ($msg)}
	if (($msg -inotmatch "SUCCESS") -or (-not $msg)) {
		Throw "Scheduler reported a failure on /DELETE"
	}
	else {writelog $msg white}
}
function DoRecoveryPoints {
	param ($dslist)
	$bj = @() ; $tmp = @()
	writelog "Creating ExpressFull for:" 
	foreach ($d in $dslist) {
		writelog "$($d.displaypath) [on] $($d.productionservername)" 
		switch ($ptype) {
			"ShortTerm" {
				if ($d.ProtectionGroup.IsDiskShortTerm) {
					$tmp = ( New-RecoveryPoint -Datasource $d -Disk -BackupType ExpressFull)
					if ($tmp) {$bj += $tmp}
				}
				else {
					if (-not $d.ProtectionGroup.IsTapeShortTerm) {Throw "Protectiongroup [$d.protectiongroupname] is not configured for $ptype to tape!" }
					$tmp = ( New-RecoveryPoint -Datasource $d -Tape -ProtectionType ShortTerm )
					if ($tmp) {$bj += $tmp}
				}
			}
			"LongTerm" {
				if (-not $d.ProtectionGroup.IsTapeLongTerm) {Throw "Protectiongroup [$d.protectiongroupname] is not configured for $ptype to tape!" }
				$tmp += ( New-RecoveryPoint -Datasource $d -Tape -ProtectionType LongTerm)
				if ($tmp) {$bj += $tmp}
			} 
			default {Throw "Unknown protection type $ptype"}
		}
	}
	return $bj 
}

function SingleBackup {
	param ($dpmserver, $psname, $dsname, $type)
	$rpobj = $null
	writelog "Collecting datasource information from $dpmserver"
	$ds = @(Get-ProtectionGroup $dpmserver | foreach {Get-Datasource $_})
	$ds = @($ds | sort ProductionServername)
	$ds = @($ds | ? {$_.ProductionServername -like $psname})
	if ($ds.count -lt 1) {Throw "No matching protectiongroups found!"}
	$tds = @($ds | ? {$_.DisplayPath -like $dsname})
	if ($tds.count -gt 0) {
		$ds += $tds
	}
	else{
		$tds = @()
		writelog "Searching protected objects ..." magenta
		foreach ($d in $ds) {
			$cds = ($d.GetProtectedObjects() -like $dsname)
			if ($cds.count -gt 0) { 
				$cds | foreach {writelog "Found: $_" magenta}
				$tds += $d
			}
		}
		$ds = @($tds)
	}
	if ($ds.Count -lt 1) {Throw "No matching datasources found!"}
	if ("shortterm" -match $type) {$ptype = "ShortTerm"}
	if ("longterm" -match $type) {$ptype = "LongTerm"}

	writelog "DATASOURCE SELECT RESULTS..." white
	$ds | foreach { writelog "$($_.displaypath) [on] $($_.productionservername)" }
	$now = (get-date).tostring($format)

	if ($batch.ispresent) {
		$rpobj = @(DoRecoveryPoints $ds)
	}
	else {
		if ("Y","y" -contains (Read-Host "[$now] Run OneOff backup on the above listed [N/y]")) {
			$rpobj = @(DoRecoveryPoints $ds)
		}
		else {
			$retobj.Jobs += $rpobj
			NormalExit $false $retobj
		}
	}
	writelog "Finished backup" white
	return $rpobj
}

#endregion

#region STARTINIT
$Error.Clear() #get rid of garbidge
$version = "v3.7"
$alltapes = @()
$global:RU = "SYSTEM"
$global:RP = ""
$global:KB = 1024
$global:MB = 1024 * $KB
$global:GB = $MB * 1024
$global:TB = $GB * 1024
$maxlog = 5 * $MB
$global:format = "MM/dd/yyy HH:mm.ss" #date/time format
$global:cult = New-Object System.Globalization.CultureInfo("en-US")
$scriptfile = $myinvocation.MyCommand.Definition
$parcollection = $myinvocation.BoundParameters
$HomePath = Resolve-Path (Get-Item $scriptfile).directoryname
$TN = (Get-Item $scriptfile).basename
$retobj = $null
$retobj = "" | select Groups, Libraries, Tapes, Jobs, PIT, Files, Dates, Latest
$retobj.Groups=@()
$retobj.Libraries=@()
$retobj.Tapes = @()
$retobj.Jobs = @()
$retobj.PIT = @()
$retobj.Dates=@{}
#ensure we don't have unsolicited confirms
$global:OrgConfirmPreference = $ConfirmPreference
$ConfirmPreference = "None"
$defaultpath = "C:\DPMutils"
[boolean]$switchedpath = $false

#we can't have space in path (currently SchTasks won't do it properly for PS>)
if ($homepath -match " ") {
	#if current location suitable then use it else take defaultpath
	if ((Get-Location) -match " ") {
		if (-not (Test-Path $defaultpath)) {New-Item $defaultpath -ItemType "Directory"}
		$homepath = $defaultpath
	}
	else {$homepath = Get-Location}
	Copy-Item $scriptfile $homepath #can't move running script
	$oldhomepath = Resolve-Path (Get-Item $scriptfile).directoryname 
	Move-Item "$oldhomepath\DPMTapeUtil.LOG" $homepath -confirm:$false -ea silentlycontinue
	Move-Item "$oldhomepath\DPMTapeUtil*.CSV" $homepath -confirm:$false -ea silentlycontinue
	$switchedpath = $true
	#set script file to new location so schedule takes it from there
	$scriptfile = "$homepath\$TN.Ps1" 
	Set-Location $homepath
}

$global:logfile = "$HomePath\$TN.LOG" 
$exportfile = "$HomePath\$($TN)_Export.CSV"
$erasefile = "$HomePath\$($TN)_Erased.CSV" 
$forcefreefile = "$HomePath\$($TN)_ForceFreed.CSV"
$ejectfile = "$HomePath\$($TN)_Ejected.CSV"
$statefile = "$HomePath\$($TN)_State.CSV"
$writtenfile = "$HomePath\$($TN)_Written.CSV"
$spanfile = "$HomePath\$($TN)_Span.CSV"
$slotsfile = "$HomePath\$($TN)_Slots.CSV"
$matchfile = "$HomePath\$($TN)_Match.CSV"
$copyfile = "$HomePath\$($TN)_Copy.CSV" 
$catfile = "$HomePath\$($TN)_Catalog.CSV" 
$expiredfile = "$HomePath\$($TN)_Expired.CSV"
$groupfile = "$HomePath\$($TN)_Group.CSV"
$latestfile = "$HomePath\$($TN)_Latest.CSV"

#ensure we DPM cmdlets are loaded
Add-PSSnapin -Name Microsoft.DataProtectionManager.PowerShell -ea silentlycontinue
$Error.Clear()
if (-not (Test-Path $logfile)) {
	"Start new log file`n====================" > $logfile
}
else {
	#cap logfile size
	if ((Get-item $logfile).length -gt $maxlog ) {
		Remove-Item $logfile -confirmforce:$false
		writelog "Deleted oversized logfile`n`n" -f cyan
	}
}
writelog ("="*60) white
writelog "DPMTapeUtil $version" white
writelog "Using parameters:" white

$taperef = "Export","CopyPIT","TapeErase","ForceFree","Inventory","Recatalog","Search"
$DoTapeloop = $false
foreach ($k in $parcollection.Keys) {
	if ($taperef -contains $k) {$DoTapeloop = $true}
	writelog ("`t$k`: {0}" -f $parcollection.item("$k")) 
}
if (($latest) -and ($TargetPath -lt 3)) {Throw "-Latest requires -TargetPath"}

if ($switchedpath) {writelog "Switched path to $homepath" magenta}
writelog ("-"*60) white
if ($help) {showhelp}

if ($cleanup) { 
	CleanupTasks (&hostname)
	NormalExit $true $retobj
	return $retobj
}
# check if looks like valid smtp
if ($mailto) {
	if ($mailto.split("@").count -lt 2) {
		Throw "Must provide valid smtp mail address like user@domain"
	}
}

# get credentials if needed
if ($runas) {
	$userthings = Getcredentials ""
	$RU = $userthings.user
	$RP = $userthings.ClearPW
}

writelog ("Logfile {0}" -f (Get-Item $logfile))
if (Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\Agent") {
	$k = Get-Item -Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\Agent"
	if ($k.GetValue("UseShortErase") -ne $null) {$tmp = ""} else {$tmp = " NOT"}
}
else {$tmp = "NOT"}
writelog "Quickerase IS$($tmp) enabled on local server!" 
if ((Get-DPMGlobalProperty (&hostname) "OptimizeTapeUsage") -eq "True" ) {
	$tmp = "" 
	[boolean]$global:tapecolocation = $false
}
else {
	$tmp = " NOT"
	[boolean]$global:tapecolocation = $true
}
writelog "Tape colocation IS$($tmp) enabled on local server!" 

#endregion

if (($dpmserverlist.count -eq 1) -and (Test-Path $dpmserverlist[0])) {
	writelog "Processing server list file..."
	$dpmserverlist = Get-Content $dpmserverlist[0]
}
writelog "Handling [$($dpmserverlist.count)] servers..."

#SERVERLOOP
# ensure no old values 
[int]$servercount = 0
$alltapes = @()
$tmp = $null

foreach ($dpmserver in $dpmserverlist) {
	Disconnect-DPMServer
	writelog "=== Using server $dpmserver ===" white
	$servercount++
	$retobj.Libraries = @(Get-DPMLibrary $dpmserver | ? {$_.ISoffline -eq $false})
	$retobj.Groups = @(Get-Protectiongroup $dpmserver )
	if ($retobj.Libraries.count -lt 1) {Throw "No libraries found!"}
	foreach ($grp in $retobj.Groups) { $alltapes += (Get-Tape -ProtectionGroup $grp)}
	foreach ($lib in $retobj.Libraries) { $alltapes += (Get-Tape -DPMLibrary $lib) }
	$alltapes = @($alltapes | sort -Unique)
	
	if ($oneoff) {
		writelog "Starting OneOff backup flow..."
		$tmp = @($oneoff.Split("|"))
		if ($tmp.count -ne 3) {Throw "Missing arguments for OneOff backup: $oneoff "}
		$j = SingleBackup $dpmserver $tmp[0] $tmp[1] $tmp[2]
		if ($j) {$retobj.jobs += $j}
	}

	# schedule task & skip the rest
	if ($schedule ) {
		$currenttaskname = (ScheduleTask $dpmserver $scriptfile $parcollection)
		continue;
	}

	# scan libraries
	if ($scanlib) {
		$j = ScanLib $dpmserver
		if ($j) {
			$retobj.Jobs+= $j
			do {
				# if there is reason to scan, better wait for completion before continue
				writelog "Waiting 5 sec for library scan complete on $dpmserver" magenta
				sleep 5
			} while ($j.hascompleted -eq $false)
		}
	}

	# Ignore -Override, not meant to skip -Search
	if ($search) {$retobj = Search $alltapes $retobj} 
	else { $retobj.Tapes = @($alltapes)}

	# Reduce for functions that must have valid data
	if (($Export) -or ($Copypit) -or ($retobj.Dates.Keys.Count -gt 0) -or ($CopyGroup.Count -gt 0)) {
		$retobj.Tapes = @($retobj.Tapes | ? {$_.datasetstate -ne "None" })
		$retobj.Tapes = @($retobj.Tapes | ? {$_.datasetstate -ne "Unknown" }) 
		writelog "Reduced tape list to tapes with data!" yellow
	}

	# Exclude tapes from another DPM server	unless selected		   
	if (-not $shared) {$retobj.Tapes = @($retobj.Tapes | ? { $_.BelongsToAnotherDPM -eq $false})}

	#TAPE LOOP (get tapes to display before action)
	if ($Dotapeloop) {
		writelog "Processing [$($retobj.Tapes.count)] tapes and may take a while..." white blue
		$retobj = TapeLoop $retobj
	}

	#don't display list with -OneOff
	if ($oneoff -eq "") {
		# only display results with last server in list
		if ($servercount -eq $dpmserverlist.GetLength(0)) {
			writelog ("Selected [{0}] tapes" -f $retobj.Tapes.count)
			if ($retobj.Tapes.Count -gt 0) {
				SpecialOut "SEARCH RESULTS" $retobj.Tapes
				$now = (get-date).tostring($format)
				if ((-not $batch) -and ("n","N" -contains (Read-Host "[$now] Good search [Y/n]")[0])) {NormalExit $false $retobj} 
			}
		}
	}
	#Force free selected tapes
#Need this before erase if not free already
	$now = (get-date).tostring($format)
	if ($forcefree) {
		if ($batch) {ForceTapeFree $retobj.Tapes $forcefreefile $dmserver}
		else {
			if ("y","Y" -contains (Read-Host "[$now] Confirm to force tapes free [N/y]")[0]) {
				ForceTapeFree $retobj.Tapes $forcefreefile $dpmserver
			}
		}
	}

	#Erase selected tapes
	if ($tapeerase) {
		if ($retobj.Tapes.count -gt 0) {
			writelog "Processing eraselist with [$($retobj.Tapes.count)] tapes..." 
			$now = (get-date).tostring($format)
			$prompt = "[$now] Go ahead with erasing [{0}] tapes [N/y]" -f $retobj.Tapes.count
			if (!$batch) {$response = (Read-Host $prompt)[0]}
			if (("y","Y" -contains $response) -or ($batch)) {
				ForceTapeFree $retobj.Tapes $forcefreefile $dpmserver
				$j += TriggerEraseTapes $dpmserver $retobj.Tapes $erasefile
				if ($j) {$retobj.Jobs += $j}
			}
			else {writelog "No erase jobs were triggered!" }
		}
		else {
			if ($override) {writelog "Erase list empty!" yellow}
			else {writelog "No recyclable tapes found!" yellow}
		}
	}
	write-host ""
	writelog ("Processing  for $dpmserver done!") white

	#Run detailed inventory on unknown tapes 
	if ($inventory) {
		foreach ($Linv in $retobj.Libraries) {
			if ($override) {
				$unknownTapeList = @($retobj.Tapes | ? {$_ -is [Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.LibraryManagement.ArchiveMedia]})
			}
			else {
				$unknownTapeList = @($retobj.Tapes | ? {$_ -is [Microsoft.Internal.EnterpriseStorage.Dls.UI.ObjectModel.LibraryManagement.ArchiveMedia] -and $_.OmidState -eq "Unknown"}) 
			}
			if ($unknownTapeList.Count -gt 0) {
				foreach ($tape in ($unknowntapelist| sort-object -property label -descending)) {
					Writelog "Starting detailed inventory on $($tape.location) of [$($Linv.Userfriendlyname)]"
					$j = Start-DPMLibraryInventory -DPMLibrary $Linv -DetailedInventory -Tape $tape
					if ($j) {$retobj.Jobs += $j}
				}
			}
			else {writelog "No unknown tapes found in [$($Linv.userfriendlyname)]!" yellow}
		}
	}

	#recatalog imported
	if ($recatalog) {
		foreach ($tape in $retobj.Tapes) {
			#Offsiteready and cleaning tapes are not eligable
			if ($tape.IsOffsiteReady ) {
				writelog "Skipping offsite ready tape [$($tape.location)]" yellow
				continue;
			}
			$Error.Clear()
			# unmark free so we can recatalog
			if (($tape.DatasetState -eq "None") -and ($tape.DisplayString -match "contains data")) {
				writelog "Unmark free $($tape.location) to recatalog!" cyan
				Set-Tape -NotFree $tape
				while ($tape.displaystring -notmatch "imported") {sleep 1}
			}
			#we cannot recatalog unless appears as 'imported'
			if ($tape.Displaystring -notmatch "imported") {continue;}
			writelog "Recataloging $($tape.location)..." 
			$j = Start-TapeRecatalog -Tape $tape
			if ($j) {
				$retobj.Jobs += $j
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $catfile
			}
			else {
				writelog "Skipped $($tape.location), recatalog not needed!" yellow
			}
			#don't throw, others tapes might be applicable
			if ($Error.Count -gt 0) {writelog "$error"}
		}
	}

	#copy recovery point
	if ($copypit) {
		if ($latest ) {CopyLatestPIT}
		else {CopyPIT}
	}

	#Eject selected tapes
#Keep at the end so we can combine other functions (like erase) + eject
	if ($eject) {
		writelog ("Attempting to eject [$($retobj.Tapes.Count)] tapes..." ) white blue
		#force new file
		MakeHeader $ejectfile
		foreach ($tape in $retobj.Tapes) {
			$lib = $retobj.Libraries | ? {$_.Id -eq $tape.LibraryId}
			$Error.Clear()
			$j = Remove-Tape -DPMLibrary $lib -Tape $tape 
			if ($j) {
				$retobj.Jobs += $J
				$now = (get-date).tostring($format)
				AddLine $dpmserver $now $tape $ejectfile
			}
			#throw this one, if 1 fails likely all will fail
			if ($Error.Count -gt 0) {Throw "$error"}
		}
	}

	# wait for completion if requested
	if ($wait) {
		$inprogress = $retobj.Jobs.count 
		do {
			writelog ("Waiting 1 minute for [$inprogress] jobs to complete...")
			sleep 60
			$inprogress = $retobj.Jobs.count - @($retobj.Jobs | ? {$_.HasCompleted}).count
		}
		while ($inprogress -gt 0)
		$failed = @($retobj.Jobs | ? {$_.Status -ne "Succeeded"}).count
		writelog "All jobs completed with [$failed] failures!" white
	} 

	# zip output files and mail, keep this as very last to get all files.
	if ($mailto) {
		$retobj.Files = @()
		$retobj.Files += Get-Item "$homepath\$TN*.log"
		$retobj.Files += Get-Item "$homepath\$TN*.csv" 
		$myzip = MakeZip $retobj.Files
		SendMail $mailto $myzip.Self.Path
	}
} #END SERVERLOOP

NormalExit $true $retobj
return $retobj
