#Author : Ruud Baars
# Date : 12/23/2010


#v0.1 first draft 
# unloads standalone tape drive that has no  library
# unload causes the media to be ejected

param (
[string][Parameter(Mandatory=$true,Position=1)]$tapename,
[switch][Parameter(Mandatory=$false,Position=2)]$mytapedebug
)

#region FUNCTIONS
trap [Exception] { 
	# Generic trap routine to unify logging to file and application eventlog
	writelog $("TRAP: $TN: $Error") red
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "$TN"
	$msg = "$error`n $($Error[0].InvocationInfo.PositionMessage)"
	$log.WriteEntry("TRAP: $TN: $msg", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	Write-Host $Error[0].InvocationInfo.PositionMessage -f red
	$Error.Clear()
	Remove-Event -SourceIdentifier MyTapeExit -ea SilentlyContinue
	Unregister-Event -SourceIdentifier MyTapeExit -ea SilentlyContinue
	Remove-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	Unregister-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	exit
}

function writelog {
	param([string]$msg, $color = "Green", $bcolor = "Black")
	$msg = "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	# catch all if batch mode
	if (-not $batch) {write-host $msg -ForegroundColor $color -BackgroundColor $bcolor}
}

function ProcessOutputEvent {
	param([string]$key)
	[boolean]$flag = $true
	sleep -Milliseconds 100
	foreach ($event in (Get-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue)) {
		# keep false if once false
		$flag = ($flag -and $true )
		if ($event.SourceEventArgs.Data -match "error") {
			$flag = $false
			$taperr = [int]($event.SourceEventArgs.Data.split(":")[1])
			writelog (net helpmsg $taperr) red
		}
		if ($mytapedebug) {writelog ($event.SourceEventArgs.Data) magenta}
		Remove-Event -SourceIdentifier MyTapeEvent -ErrorAction SilentlyContinue
	}
	return $flag
}

function cleanup {

	Get-Process | ? {$_.name -eq "mytape"} | foreach {$_.kill()}
}
#endregion

#region INITIALIZE
$version = "V0.1"
$Error.Clear()
$global:taperr
$global:WhereAreWe = "" | select CurrentSlot, CurrentDrive, Changer, ReturnSlot
$scriptfile = $myinvocation.MyCommand.Definition
$parcollection = $myinvocation.BoundParameters
$HomePath = Resolve-Path (Get-Item $scriptfile).directoryname
$TN = (Get-Item $scriptfile).basename
if (!($myinvocation.BoundParameters.keys -match "tape" )) {Throw "Missing tape drive parameter!"}
$logfile = ".\$TN.log" 
if (Test-Path .\mytape.exe) {$mytapexe = Resolve-Path .\mytape.exe}
	else {Throw "MYTAPE.EXE not found!"}
[boolean]$global:inventoryneeded = $false
#endregion

	writelog "$tn $version"
	writelog "======================"

	# we now have a drive to use
	writelog "Using: $tapename"

	# Tape drive should be ready, setup Mytape.exe 
	$pi = New-Object system.Diagnostics.ProcessStartInfo
	$pi.Arguments = $tapename
	$pi.FileName = $mytapexe
	$pi.WorkingDirectory = (Get-Item $mytapexe).DirectoryName
	$pi.RedirectStandardError=$true
	$pi.RedirectStandardInput=$true
	$pi.RedirectStandardOutput=$true
	$pi.CreateNoWindow=$true
	$pi.ErrorDialog=$false
	$pi.LoadUserProfile=$false
	$pi.UseShellExecute=$false

	#run MYTAPE
	$p = New-Object system.Diagnostics.Process
	$p.StartInfo = $pi
	$p.EnableRaisingEvents=$true

	# start mytape (which connects to tape)
	writelog "Starting MYTAPE..."
	if (!($p.Start())) {writelog "Could not start MyTape"; exit}
	[void](Register-ObjectEvent $p Exited -SourceIdentifier MyTapeExit -Action {Throw "MYTAPE exited unexpectedly" })
	#Register-ObjectEvent $p OutputDataReceived -SourceIdentifier MyTapeEvent -Action {writelog $Args[1].data}
	Register-ObjectEvent $p OutputDataReceived -SourceIdentifier MyTapeEvent 
	$p.BeginOutputReadLine()
	if (!(ProcessOutputEvent "success")) {Throw "Could not access $tapename" ; exit}

	writelog "MYTAPE started, enabling processing events..."
	#one to resolve 1 expected invalid handle 
	$p.StandardInput.WriteLine("isready")
	if (!(ProcessOutputEvent "success")) {
		writelog "Ignoring first invalid handle. this is expected!"
		sleep 1
		#should be ready now
		$p.StandardInput.WriteLine("isready")
		if (!(ProcessOutputEvent "success")) {
			Throw "Drive not ready, skipping unload!" 
		}
		else {
			writelog "Mytape: unload tape"
			$p.StandardInput.WriteLine("unloadtape")
			if (!(ProcessOutputEvent "success")) {Throw "Media unload failed!"}
			else {writelog "Unload completed!" }
		}
	}
	# quit mytape
	writelog "Mytape: exiting..." white
	Unregister-Event -SourceIdentifier MyTapeExit -ea SilentlyContinue
	$p.StandardInput.writeline("q")
	if (!(ProcessOutputEvent "closing")) {Throw "Quit MYTAPE failed!" }
	Remove-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	Unregister-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	$p.Close()
	$p.Dispose()
	writelog "All done!" white
