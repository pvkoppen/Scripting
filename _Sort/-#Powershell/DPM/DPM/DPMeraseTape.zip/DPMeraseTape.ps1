#Author : Ruud Baars
# Date : 12/12/2010

# Note on MCT: MCT add's first slot nr to entered slot parameter
# e.g. when first slot reported = 1, entering slot-0 becomes slot-1, 2 becomes 3, etc..
# examine slot  =  mctexe <changer nr> -e s <slot nr>
# examine drive =  mctexe <changer nr> -e d <drive nr>
# we hardcode transport to 't 0'
# move drive to slot = mctexe <changer nr> -m t 0 d <drive nr> s <slot nr>
# move slot to drive = mctexe <changer nr> -m t 0 s <slot nr> d <drive nr>

#v1.0 first release 
#v1.1 
# - corrected slot MCT number usage, was using 1 too high all the time 
# - retested DPM tape states (imported, Free, normal etc..) all work
#   after erase must select "Identify unknown tape" (possibly needs fast inventory first)
#   tape shows in DPM as:  "[No tape label. Contains no data]"
# v1.2 added check if any drive info events are received.

param (
[int][Parameter(Mandatory=$true,Position=1)]$slot,
[string][Parameter(Mandatory=$true,Position=2)]$libkey,
[int][Parameter(Mandatory=$false,Position=3)]$erasetimeout = 30,
[switch][Parameter(Mandatory=$false,Position=4)]$mytapedebug
)

#region FUNCTIONS
trap [Exception] { 
	# Generic trap routine to unify logging to file and application eventlog
	writelog $("TRAP: $TN: $Error") red
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "$TN"
	$msg = "$error`n $($Error[0].InvocationInfo.PositionMessage)"
	$log.WriteEntry("TRAP: $TN: $msg", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	Write-Host $Error[0].InvocationInfo.PositionMessage -f red
	$Error.Clear()
	Remove-Event -SourceIdentifier MyTapeExit -ea SilentlyContinue
	Unregister-Event -SourceIdentifier MyTapeExit -ea SilentlyContinue
	Remove-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	Unregister-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	exit
}
function writelog {
	param([string]$msg, $color = "Green", $bcolor = "Black")
	$msg = "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	# catch all if batch mode
	if (-not $batch) {write-host $msg -ForegroundColor $color -BackgroundColor $bcolor}
}

function GetDriveNumNameStats {
	param ($libtouse, $libnum)
	$structcol = @()
	$drives = @($libtouse.GetDriveCollection())
	for ($num = 0; $num -lt $drives.count; $num++) {
		$mctdrive = invoke-expression "$mctexe $changer -e d $num"
		$drive = $drives | ? {$mctdrive[7] -match $_.serialnumber}
		if ($drive) {
			$struct = "" | select Number, Name, Status, HasMedia, DriveObject, LibraryObject
			$struct.DriveObject = $drive
			$struct.LibraryObject = $libtouse
			$struct.Status = $drive.status
			[boolean]$struct.Hasmedia = $false
			$labeltag = (CheckMedia $libnum "d" $num) 
			if ($labeltag) {
				writelog "Drive-$num = $($drive.accesspath) contains: $labeltag"
				$struct.Hasmedia = $true
			}
			[string]$struct.name = $drive.accesspath
			[int]$struct.number = $num
			$structcol += $struct
		}
		else {Throw "BUG: could not match drive serial"}
	}
	return $structcol
}

function ProcessOutputEvent {
	param([string]$key)
	[boolean]$flag = $true
	sleep -Milliseconds 100
	foreach ($event in (Get-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue)) {
		# keep false if once false
		$flag = ($flag -and $true )
		if ($event.SourceEventArgs.Data -match "error") {
			$flag = $false
			$taperr = [int]($event.SourceEventArgs.Data.split(":")[1])
			writelog (net helpmsg $taperr) red
		}
		else { if ($mytapedebug) {writelog ($event.SourceEventArgs.Data) magenta}}
		Remove-Event -SourceIdentifier MyTapeEvent -ErrorAction SilentlyContinue
	}
	return $flag
}

function CheckMedia {
	param ($c = 0, $f = "", $n = 0, $firstslot = 0)
	switch ($f) {
		#drive
		"d" { 
			$mctout = invoke-expression "$mctexe $c -e $f $n"
			$mctstat = [int]($mctout[2].Split()[8])
			if (($mctstat -band 1) -eq 1) 
			{
				$tag = $mctout[5].Split(":")[1]
				return $tag
			}
			else { return $null}
		}
		#slot
		"s" {
			$mctout = invoke-expression "$mctexe $c -e $f $($n-$firstslot)"
			$mctstat = [int]($mctout[2].Split()[8])
			$ident = ($mctout[5].Split(":")[1]).trim()
			writelog "Slot-$($n) contains: $ident"
			if (($mctstat -band 1) -eq 1) {
				$tag = $mctout[5].Split(":")[1]
				return $tag
			}
			else {return $null}
		}
		default { Throw "Invalid media check function"}
	}
}
function ParkMedia {
	param ($changer, $parkdrive, $firstslot = 0)
	for ($parkslot = 0; $parkslot -lt $parkdrive.LibraryObject.Getslotcollection().count;$parkslot++) {
		if (!(CheckMedia $changer "s" $s)) {break;}
	}
	writelog "Parking Drive-$($parkdrive.number) into Slot-$parkslot..." 
	if (!(MoveMedia "park" $changer $parkslot $parkdrive.number)) {return $false}
	writelog "Parking done!" white
	return $true
}

function MoveMedia {
	param ($f = "load", $c = 0, $sn = 0, $dn = 0, $firstslot = 0)
	#flag to run inventory if we move stuff around
	$inventoryneeded = $true
	$WhereAreWe.Changer = $c
	$result = $false
	$response = ""
	switch ($f) {
		"park" {
			writelog "\\.\Changer$c moving from Drive-$dn to Slot-$sn..."
			$response = (MCTcmd " $c -m t 0 d $dn s $($sn-$firstslot)") 
			if ($response.length -gt 1) {$result = $true}
		}
		"load" { 
			writelog "\\.\Changer$c moving from Slot-$sn to Drive-$dn..."
			$response = ( MCTcmd " $c -m t 0 s $($sn-$firstslot) d $dn") 
			if ($response.length -gt 1) {
				$result = $true
				$WhereAreWe.ReturnSlot = $sn
				$WhereAreWe.CurrentDrive = $dn
			}

		}
		default {
			writelog "\\.\Changer$c obtaining status from Drive-$dn..."
			$response = ( MCTcmd " $c -e d $dn")
			if ($response.length -gt 1) {$result = $true}
		} 
	}
	writelog "Moving done!" white
	return $result
}
function MCTcmd {
	param ($pars)
	$mctresult = @(Invoke-Expression "$mctexe $pars")
	if ($mytapedebug) { $mctresult | foreach {writelog $_ magenta}}
	$err = ($mctresult -match "error")
	if ($err.length -gt 0) {
		$code = [int]($err[0].Split()[6]).trimend(".")
		writelog "MCT: $(net helpmsg $code)" red 
		$mctresult = ""
	}
	return $mctresult
}
function cleanup {

	Get-Process | ? {$_.name -eq "mytape"} | foreach {$_.kill()}
}
#endregion

#region INITIALIZE
$version = "V1.2"
$Error.Clear()
$global:taperr
$global:WhereAreWe = "" | select CurrentSlot, CurrentDrive, Changer, ReturnSlot
$scriptfile = $myinvocation.MyCommand.Definition
$parcollection = $myinvocation.BoundParameters
$HomePath = Resolve-Path (Get-Item $scriptfile).directoryname
$TN = (Get-Item $scriptfile).basename
if (!($myinvocation.BoundParameters.keys -match "slot" )) {Throw "Missing slot parameter!"}
$logfile = ".\$TN.log" #temporary till merged into DPMTapeUtils
if (Test-Path .\mct-x64.exe) {$mctexe = Resolve-Path .\mct-x64.exe }
else {Throw "MCT-X64.EXE not found!"}
if (Test-Path .\mytape.exe) {$mytapexe = Resolve-Path .\mytape.exe}
	else {Throw "MYTAPE.EXE not found!"}
	[boolean]$global:inventoryneeded = $false
	$WherAreWe = $null
	#endregion

	# get DPM stuff
	writelog "$tn $version"
	writelog "======================"
	$libs = @(Get-DPMLibrary (&hostname) | ? {!$_.IsOffline})
	$libs | ft -AutoSize
	if (((Get-Service dpmla).status) -ne "Stopped") {Throw "DPMLA is running"}

	if ($libs.Count -eq 1) {$wantedlib = @($libs[0])}
	else{if ($libkey -eq "") {Throw "Missing key to pick library!" } }
	$wantedlib = @($libs | ? {$_.UserFriendlyName -match $libkey})
	if ($wantedlib.Count -gt 1) {Throw "Too many libraries match [$libkey]"}

	# find changer number by matching serial
	[int]$changer = 0
	$libtouse = $null
	for ($changer = 0; $changer -lt $libs.Count; $changer++) {
		# match search lib on serial
		$changerinfo = MCTcmd "$changer -p"
		#dump changer info
		if (!$mytapedebug) {$changerinfo >> $logfile}
		$mctserial = (MCTcmd "$changer -d")[6]
		[int]$global:firstslot = ( $changerinfo | ? {$_ -match "First Slot Number"}).split(":")[1] 
		if ($mctserial -match $wantedlib[0].Serialnumber) {$libtouse = $wantedlib[0]
			writelog "MCT on [$($wantedlib[0].Userfriendlyname)] reported first slot = $firstslot"
			if ($slot -lt $firstslot) {Throw "Slot [$slot] is too low"}
			break;
		}
	}
	# we now know which changer to use
	writelog "Using \\.\Changer$changer = $($libtouse.userfriendlyname)"
	if (!(CheckMedia $changer "s" $slot $firstslot)) {Throw "Slot-$slot has no media!"}

	# Get idle empty drive media
	$drivecol = @(GetDriveNumNameStats $libtouse $changer)
	$usabledrives = @($drivecol | ? {((!$_.hasmedia) -and ($_.status -eq "Idle"))})
	if ($usabledrives.Count -lt 1) {
		writelog "No idle empty drives, attempting to park media..." yellow
		$usabledrives = @($drivecol | ? { $_.status -eq "Idle"})
		if ($usabledrives.count -lt 1) {Throw "All drives are busy!" }
		#just pass the first idle drive
		if (ParkMedia $changer $usabledrives[0]) {
			$drivetouse = $usabledrives[0]
		}
		else {Throw "Failed to park media!"}
	}
	else {$drivetouse = $usabledrives[0]}

	# we now have a drive to use
	writelog "Using Drive-$($drivetouse.number) $($drivetouse.name) of \\.\Changer$changer [$($libtouse.userfriendlyname)]"

	#move media from slot into drive 
	if (!(MoveMedia "load" $changer $slot $drivetouse.number)) {
		Throw "Failed to load media from Slot-$slot into $($drivetouse.name)" 
	}

	# Tape drive should be ready, setup Mytape.exe 
	$pi = New-Object system.Diagnostics.ProcessStartInfo
	$pi.Arguments = $drivetouse.name
	$pi.FileName = $mytapexe
	$pi.WorkingDirectory = (Get-Item $mytapexe).DirectoryName
	$pi.RedirectStandardError=$true
	$pi.RedirectStandardInput=$true
	$pi.RedirectStandardOutput=$true
	$pi.CreateNoWindow=$true
	$pi.ErrorDialog=$false
	$pi.LoadUserProfile=$false
	$pi.UseShellExecute=$false

	#run MYTAPE
	$p = New-Object system.Diagnostics.Process
	$p.StartInfo = $pi
	$p.EnableRaisingEvents=$true

	# start mytape (which connects to tape)
	writelog "Starting MYTAPE..."
	if (!($p.Start())) {writelog "Could not start MyTape"; exit}
	[void](Register-ObjectEvent $p Exited -SourceIdentifier MyTapeExit -Action {Throw "MYTAPE exited unexpectedly" })
	#Register-ObjectEvent $p OutputDataReceived -SourceIdentifier MyTapeEvent -Action {writelog $Args[1].data}
	Register-ObjectEvent $p OutputDataReceived -SourceIdentifier MyTapeEvent 
	$p.BeginOutputReadLine()
	if (!(ProcessOutputEvent "success")) {Throw "Could not access $tapename" ; exit}

	writelog "MYTAPE started, enabling processing events..."
	#one to resolve 1 expected invalid handle 
	$p.StandardInput.WriteLine("isready")
	if (!(ProcessOutputEvent "success")) {
		writelog "Ignoring first invalid handle. this is expected!"
		sleep 1
		#should be ready now
		$p.StandardInput.WriteLine("isready")
		if (!(ProcessOutputEvent "success")) {
			Throw "Drive not ready, skipping erase!" 
		}

		else {
			#loadtape logically (mount it)
			writelog "Mytape: load tape"
			$p.StandardInput.WriteLine("loadtape")
			if (!(ProcessOutputEvent "success")) {Throw "Media load failed!"}

			#get drive infos
			$p.StandardInput.WriteLine("getdriveinfo")
			sleep -Milliseconds 100 
			$events = @(Get-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue)
			if ($events.count -lt 1) {Throw "No 'drive info' output events received"}
			$driveinfo = @($events | foreach {$_.SourceEventArgs.data})
			if (!$mytapedebug) {$driveinfo >> $logfile}
			writelog ($driveinfo -match "short erase")
			$shorterase = ($driveinfo -match "short erase")[0].split(":")[1]
			Remove-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue

			# erase tape
			writelog "Mytape: erasing tape..." white blue
			if ($shorterase -match "TRUE") {$p.StandardInput.WriteLine("erasetape s")}
			else {$p.StandardInput.WriteLine("erasetape l")}
			if (!(ProcessOutputEvent "success")) {
				writelog "No response yet, waiting $erasetimeout minutes..." 
				sleep ($erasetimeout * 60)
			}
			if (!(ProcessOutputEvent "success")) {Throw "Erase failed!" }
		}
	}
	# quit mytape
	writelog "Mytape: exiting..." white
	Unregister-Event -SourceIdentifier MyTapeExit -ea SilentlyContinue
	$p.StandardInput.writeline("q")
	if (!(ProcessOutputEvent "closing")) {Throw "Quit MYTAPE failed!" }
	Remove-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	Unregister-Event -SourceIdentifier MyTapeEvent -ea SilentlyContinue
	$p.Close()
	$p.Dispose()

	#move media back to slot
	writelog "Moving back media..."
	if (!(MoveMedia "park" $changer $slot $drivetouse.number)) {
		Throw "Failed to move media back to slot!" 
	}

	writelog "All done!" white
