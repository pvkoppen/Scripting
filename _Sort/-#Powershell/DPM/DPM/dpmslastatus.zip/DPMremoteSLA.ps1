#Author : Ruud Baars
# Date : 9/29/2010
# Runs a script across multiple servers
#
# Version reset v1.0
#
param (
[string[]]$serverlist = (&hostname), 
[string]$remotescript = ".\DPMslastatus.Ps1",
[string]$listfile = ".\machines.txt",
[int]$age = 24, 
[int]$percent = 100,
[string]$mailto = "",
[string]$schedule = "",
[switch]$interactive
)

#region FUNCTIONS
trap [Exception] { 
	writelog $("TRAP: $TN: $Error") red
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	if ($TN.length -lt 3) {$TN = "DPMslaStatus"}
	$log.Source = "$TN"
	$msg = "$error`n $($Error[0].InvocationInfo.PositionMessage)"
	$log.WriteEntry("TRAP: $TN: $msg", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	Write-Host $Error[0].InvocationInfo.PositionMessage -f red
	Disconnect-DPMServer $dpmservername -ErrorAction SilentlyContinue
	Remove-Event * -ea SilentlyContinue
	Unregister-Event * -ea SilentlyContinue
	(Get-Job * | ? {$_.name -match "ParOn"}) | foreach {Remove-Job $_.id -Force}
	exit
}

function writelog {
	param([string]$msg, $color = "Green", $bcolor = "Black")
	$msg = "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	if ($interactive) {Write-Host $msg -ForegroundColor $color -BackgroundColor $bcolor}
}

function Schedule {
	param ($schedulefile, $params, $schedule)
	writelog "Scheduling $TN..."
	#get credentials to create task runtime user
	$cred = Get-Credential  (&whoami)
	#retrieve clear password neede for schtasks RunAs user (/RU / RP)
	$pwd = $cred.GetNetworkCredential().Password
	#build command and schedule
	# must use "/RL HIGHEST" because task needs registry access
	$thisscript = "`"`"`"`"powershell`"`"`" -noninteractive -nologo -command `"`"`"&{$schedulefile $params}`"`"`""
	switch ($schedule.Trim().split(" " )[0]) {
		"DAILY" {$sc = "DAILY"}
		"WEEKLY" {$sc = "WEEKLY"}
		"MONTHLY" {$sc = "MONTHLY"}
		default: {Throw "Invalid schedule parameter: $schedule"}
	}
	$st = $schedule.Split(" ")[1]
	if ((get-date($st)).subtract((Get-Date)) -lt 0) {
		$date = (Get-Date).AddDays(1)
	}
	else {$date = Get-Date}
	$sd = $date.ToString("MM/dd/yyyy",$cult)	
	$msg = @(SCHTASKS /CREATE /F /RU ($cred.username) /RP $pwd /RL "HIGHEST" /S (&hostname) /TN $TN  /SC $sc /ST $st /TR $thisscript )
	if (($msg -inotmatch "SUCCESS") -or (-not $msg)) {Throw "Scheduler reported a failure -> $msg"}
	writelog "Scheduling done!" white
}



function SendMail {
		param($mailto, $mailfile )
		#if something missing set $mailto $null so we don't get here again
		if (!$mailto) {(writelog "No mail recipient specified" white red); $mailto = $null; return }
		if (!$mailfile) {(writelog "No attachment specified" white red); $mailto = $null; return } 
		writelog "Gathering mail information..." 

		# need DPM serverobject to get smtp properties
		# Get-DPMGlobalPropertyValue cmdlet does not do these
		Disconnect-DPMServer (&hostname)
		$dpmobj = Connect-DPMServer (&hostname)
		$smtprelay = $dpmobj.GetGlobalPropertyValue("Smtpservername")
		if (!$smtprelay) {(writelog "SMTP relay not configured" white red); $mailto = $null; return } 
		$mailfrom = $dpmobj.GetGlobalPropertyValue("Smtpserversenderaddress")
		if (!$mailfrom) {(writelog "FROM address not configured" white red); $mailto = $null; return } 

		$Error.Clear()
		[void][system.reflection.assembly]::loadwithpartialname("system.web") 
		if ($Error.Count -gt 0) {Throw "$error"}
		$msg = New-Object System.Web.Mail.MailMessage
		$msg.From = $mailfrom
		$msg.to = $mailto
		$msg.Subject = "DPM RecoveryPoint status report from server $(&hostname)"
		$msg.Body = "DPM RecoveryPoint status report attached"
		writelog "SMTP relay : [$smtprelay]"
		writelog "From address : [$mailfrom]"
		writelog "Subject : $($msg.Subject)"
		$att = new-object System.web.mail.MailAttachment ((resolve-path $mailfile),"UUENCODE")
		[void]$msg.Attachments.Add($att)
		[System.Web.Mail.SmtpMail]::SmtpServer=$smtprelay 
		writelog "Attempting to send now..."
		[System.Web.Mail.SmtpMail]::Send($msg)
		writelog "Send mail to $mailto done" white 
		#Remove-Item (Resolve-Path $mailfile) -ea SilentlyContinue -confirm:$false
}
function MakeZip
{
	param($filecollection)
	writelog "Packing [$($filecollection.count)] files..." 
	if ($filecollection.count -lt 1) {
		writelog "Nothing to zip!" white red
		return $null
	}
	Remove-Item ((Get-Location).Path + "\$($TN)*.ZIP") -confirm:$false 
	$tmp = (Get-Date).ToString($cult).replace("/","-")
	$tmp = $tmp.replace(" ","_")
	$tmp = $tmp.replace(":","-")
	$newzip = (Get-Location).Path + "\$($TN)_$($tmp).ZIP" 
	set-content $newzip ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
	$zip = (new-object -com shell.application).NameSpace($newzip) 

	foreach($file in $filecollection) 
	{
		if (-not (Test-Path $file)) {writelog "Could not find [$($file.fullname)]";continue; }
		$addfile = Get-Item $file
		writelog "Adding: $($addfile.Fullname)"
		$zip.CopyHere($addfile.FullName)
		Start-sleep -milliseconds 500
	}
	writelog "Created ZIP: $($zip.self.path)" white
	return $zip
}

function GetHTML {
	param($table)
	writelog "Generating HTML report..."
	$head = @("<style> 
 	BODY{font-family:Calibri; background-color:lightblue;} 
	TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;} 
	TH{font-size:1.0em; border-width: 1px;padding: 2px;border-style: solid;border-color: black;background-color:#FFCCCC} 
	TD{font-size:0.8em;border-width: 1px;padding: 2px;border-style: solid;border-color: black;background-color:yellow}
	</style>")
 	$header = "<H1>RecoveryPoint Status Report</H1>"
	$title = "SLA Report "
	return ($table | ConvertTo-Html -Property DPM, Latest, Age, Score, PSname, DSpath  -title $title -head $head -body $header)
}
#endregion

#region INIT
#START
$ConfirmPreference = "None"
$version = "V1.0R"
[int]$jobtimeout = 60

if ($schedule.Length -gt 3)  {$interactive=$true}
Set-ExecutionPolicy RemoteSigned -confirm:$false -Force:$true
$global:dpminstallpath = (Get-ItemProperty -Path "HKLM:SOFTWARE\microsoft\microsoft data protection manager\setup").installpath
$dpmdnsdomain = [System.DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain() 
$MB = 1024 * 1024
$maxlog = [int]5 * $MB
$global:format = "MM/dd/yyyy HH:mm:ss" #date/time format
$global:cult = New-Object System.Globalization.CultureInfo("en-US")
$scriptfile = $myinvocation.MyCommand.Definition
$parcollection = $myinvocation.BoundParameters
$TN = (Get-Item ($scriptfile)).basename
$global:logfile = "$((Get-Item $scriptfile).DirectoryName)\$((Get-item $scriptfile).basename).LOG"
$reportfile = "$((Get-Item $scriptfile).DirectoryName)\$((Get-item $scriptfile).basename)_Summary.CSV"
$htmfile = "$((Get-Item $scriptfile).DirectoryName)\$((Get-item $scriptfile).basename)_Summary.HTM"
Set-Location (Get-Item $scriptfile).DirectoryName

#load DPM snap-in regardlessly and clear the error
Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell -erroraction SilentlyContinue
#get ourselves setup, ensure logfile does not keep growing endlessly
if (Test-Path $logfile) {
	if ((Get-Item $logfile).length -gt $maxlog) {Remove-Item -path $logfile - confirm:$false}
}
#execute both formats
$dpmservername = (&hostname)
Disconnect-DPMServer -DPMServerName "$dpmservername" -ea SilentlyContinue
Disconnect-DPMServer -DPMServerName "$dpmservername.$dpmdnsdomain" -ea SilentlyContinue
#clear old errors
$Error.clear()
#endregion

if ( $listfile.length -gt 3 ) { if (Test-Path $listfile) {$serverlist += get-content $listfile} }
$tmplist = $serverlist | ?{$_}
$serverlist = @()
$tmplist | foreach {if ($_.split(".").count -lt 2) {$serverlist += "$_.$dpmdnsdomain" } else {$serverlist += $_ } }
if (!$serverlist) {Throw "No servers found!"}
# we now have a conditioned list
writelog ("=" * 70) 
writelog "$TN-$version on $(&hostname) running [$remotescript] on $($serverlist.count) servers" white
foreach ($k in $parcollection.Keys) {
	writelog ("`t$k`: {0}" -f $parcollection.item("$k")) 
}
writelog ("-" * 70) 

# create the jobs and run side by side AsJob
$invokes = @()
$arglist = @($age, $percent)
foreach ($server in $serverlist) {
	writelog "Starting job on $server ..."
	#Note: if the script uses Get-Item (and likewise) be aware that 'current location' is not a disk\folder\path
	$invoked = Invoke-Command -JobName "SlaOn_$($server.split(".")[0])"  -ComputerName $server -AsJob -FilePath $remotescript -ArgumentList $arglist 
}
#deal with our own jobs only (not using '*')
$jobs = @(Get-Job * | ? {$_.name -match "SlaOn"}) 
writelog "Waiting for $($jobs.count) server search jobs to complete..." white
[int]$slept = 0
while ($jobs | ? {$_.state -eq "Running"}) {
	sleep -seconds 1;$slept++
	if ($slept -gt $jobtimeout) {Throw "Timeout waiting for jobs to complete!"}
}

$objs = Receive-Job  $jobs
Remove-Job * 

# The dpmslatatus script returns objects with properties; DPM,PSname,Latest,Score,DSpath,Displayline 
$output = $objs | foreach {"$($_.DPM)`t$($_.Latest)`t$($_.Age)`t$($_.Score)`t$($_.PSname)`t$($_.DSpath)"} 
"DPMserver`tLatestRecoveryPoint`tAge`tScore`tProductionServer`tDataSourcePath" > $reportfile
$output >> $reportfile
(GetHTML $objs) >$htmfile

#Do mail
if ($mailto -match "@") {
	$schparams = "-mailto $mailto"
	$mailfile = MakeZip @($htmfile,$reportfile)
	if ($mailfile ) {Sendmail $mailto $mailfile.self.path}
}
else {$schparams = ""}
if ($schedule.length -gt 2) {schedule -schedulefile $scriptfile -params $schparams -schedule $schedule}
if ($interactive) {
	writelog "Showing gridview..."
	$objs | select DPM, Latest, Age, Score, PSname, DSpath | Out-GridView -Title "Recovery Point Status Report"
}
writelog "Done!" white

