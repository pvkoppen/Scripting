# Author: Ruud Baars (Microsoft) 
# Date: 9/29/2010
#
# Version reset V1.0R
param (
[Parameter(Position=0)][int]$age = 24, 
[Parameter(Position=1)][int]$percent = 100,
[Parameter(Position=2)][string]$starttime = "23:55",
[Parameter(Position=3)][switch]$interactive,
[Parameter(Position=4)][switch]$schedule,
[Parameter(Position=5)][string]$runlocation = (Get-Location),
[Parameter(Position=6)][string]$dpmservername = (&hostname)
)

#region FUNCTIONS
trap [Exception] { 
	writelog $("TRAP: $TN: $Error") red
	$Error >> $logfile
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	if ($TN.length -lt 3) {$TN = "DPMslaStatus"}
	$log.Source = "$TN"
	$msg = "$error`n $($Error[0].InvocationInfo.PositionMessage)"
	$log.WriteEntry("TRAP: $TN: $msg", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	Write-Host $Error[0].InvocationInfo.PositionMessage -f red
	Disconnect-DPMServer $dpmservername -ErrorAction SilentlyContinue
	Remove-Event * -ea SilentlyContinue
	Unregister-Event * -ea SilentlyContinue
	exit
}

function writelog {
	param([string]$msg, $color = "Green", $bcolor = "Black")
	$msg = "[{0}] {1}" -f ((get-date).tostring($format)), $msg
	$msg >> $logfile
	if ($interactive) {Write-Host $msg -ForegroundColor $color -BackgroundColor $bcolor}
}

function Schedule {
	param ($schedulefile, $params, $schtime)
	$TN = (Get-Item $schedulefile).basename
	writelog "Scheduling $TN..."
	#build command and schedule
# must use "/RL HIGHEST" because task needs registry access
	$targetserver = $dpmservername
	$thisscript = "`"`"`"`"powershell`"`"`" -noninteractive -nologo -command `"`"`"&{$schedulefile $params}`"`"`""
	$msg = @(SCHTASKS /CREATE /F /RU SYSTEM /RL "HIGHEST" /S $targetserver /TN $TN /SC DAILY /ST $schtime /TR $thisscript )
	if (($msg -inotmatch "SUCCESS") -or (-not $msg)) {Throw "Scheduler reported a failure -> $msg"}
	writelog "Scheduling done!" white
}

function GetScore {
	param ($evs )
	$range = $evs.recoveryrangeindays * 1440 #range in minutes
	$scheds = $evs.ProtectionGroup.GetSchedules()
	$Inrange = 0
	switch ($evs.Type.Name.Split()[0]) {
		"Volume" {
			$Inrange = ($scheds.item("shadowcopy").timesofday.count * $scheds.item("shadowcopy").weekdays.count)
		}
		"Client" {
			$Inrange = ($scheds.item("shadowcopy").timesofday.count * $scheds.item("shadowcopy").weekdays.count)
		}
		"System" {
			$Inrange = ($scheds.item("FullReplicationForApplication").timesofday.count * $scheds.item("FullReplicationForApplication").weekdays.count)
		}
		"Hyper-V" {
			$Inrange = ($scheds.item("FullReplicationForApplication").timesofday.count * $scheds.item("FullReplicationForApplication").weekdays.count)
		}
		"SharePoint" {
			$Inrange = ($scheds.item("FullReplicationForApplication").timesofday.count * $scheds.item("FullReplicationForApplication").weekdays.count)
		}
		"SQL" {
			if ($scheds.item("FullReplicationForApplication")) {
				$Inrange = ($scheds.item("FullReplicationForApplication").timesofday.count * $scheds.item("FullReplicationForApplication").weekdays.count)
			}
			if ($scheds.item("replication")){
				$REPLrange = ($range / ($scheds.item("replication").frequency))
			}
			if ($REPLrange -gt $Inrange) {$Inrange = $REPLrange} 
		}
		"Exchange" {
			if ($scheds.item("FullReplicationForApplication")) {
				$Inrange = ($scheds.item("FullReplicationForApplication").timesofday.count * $scheds.item("FullReplicationForApplication").weekdays.count)
			}
			if ($scheds.item("replication")){
				$REPLrange = ($range / ($scheds.item("replication").frequency))
			}
			if ($REPLrange -gt $Inrange) {$Inrange = $REPLrange} 
		}
		"Storage" {
			if ($scheds.item("FullReplicationForApplication")) {
				$Inrange = ($scheds.item("FullReplicationForApplication").timesofday.count * $scheds.item("FullReplicationForApplication").weekdays.count)
			}
			if ($scheds.item("replication")){
				$REPLrange = ($range / ($scheds.item("replication").frequency))
			}
			if ($REPLrange -gt $Inrange) {$Inrange = $REPLrange} 
		}
		Default {
			$Inrange = $evs.TotalRecoverypoints
			writelog "Not yet implemented data type: [$($evs.type.Name)]" magenta
			$evs.ProtectionGroup.GetSchedules() >> $logfile
		}
	}
	return [int]($evs.TotalRecoverypoints / $Inrange * 100)
}
#endregion

#region INIT
#START
$ConfirmPreference = "None"
$version = "V1.0R"
Set-ExecutionPolicy RemoteSigned -confirm:$false -Force:$true
$global:dpminstallpath = (Get-ItemProperty -Path "HKLM:SOFTWARE\microsoft\microsoft data protection manager\setup").installpath
$MB = 1024 * 1024
$maxlog = [int]5 * $MB
$global:format = "MM/dd/yyyy HH:mm:ss" #date/time format
$global:cult = New-Object System.Globalization.CultureInfo("en-US")
$scriptfile = $myinvocation.MyCommand.Definition
$parcollection = $myinvocation.BoundParameters
$TN = "DPMslaStatus"
$global:logfile = ".\$($TN).LOG" 
$reportfile = ".\$($TN)_Lastreport.LOG" 
#load DPM snap-in regardlessly and clear the error
Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell -erroraction SilentlyContinue
$dpmdomain = [System.DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain() 
#get ourselves setup, ensure logfile does not keep growing endlessly	
if (Test-Path $logfile) {
	if ((Get-Item $logfile).length -gt $maxlog) {Remove-Item -path $logfile - confirm:$false}
}
Disconnect-DPMServer -DPMServerName "$dpmservername" -ea SilentlyContinue
Disconnect-DPMServer -DPMServerName "$dpmservername.$dpmdnsdomain" -ea SilentlyContinue
#clear old errors
$Error.Clear() 
#endregion

if ($schedule) {$interactive = $true}

#workaround unpredictable which format will work
try {
	$pg = @(Get-ProtectionGroup $dpmservername -ea silentlycontinue)
}
catch [Exception] {$Error.Clear()}
finally {
	$dpmservername = "$dpmservername.$dpmdomain"
	$pg = @(Get-ProtectionGroup $dpmservername -ea silentlycontinue)
}
if ($pg.count -lt 1) {Throw "No protectiongroups returned!"}
$Error.Clear()

writelog ("=" * 65) 
writelog "Starting $TN $version on $dpmservername using Age $age Percent $percent" white
foreach ($k in $parcollection.Keys) {
	$parcollection.item("$k") | foreach { writelog ("`t$k`: {0}" -f $_) }
}
writelog ("-" * 65)
writelog "Getting data sources..."
$dss = @($pg | foreach {Get-Datasource $_})
$dss = $dss | ?{$_} #remove blanks
if ($dss.Count -lt 1) {Throw "No data sources returned, pls rerun script"}
#create new report file
"The following data sources violate $age hours SLA or $percent% score:" > $reportfile
writelog "The following data sources violate $age hours SLA or $percent% score:" white
$retobj = @()
$global:RXobj = @()
$global:EVdone = @()
for ($i = 0; $i -lt $dss.count;$i++) {
	[void](Register-ObjectEvent $dss[$i] -EventName DataSourceChangedEvent -SourceIdentifier "TEV$i" -Action {
		if (($global:EVdone -contains $Event.SourceIdentifier) -or ($event.sender.latestrecoverypoint.year -lt 2000)) {
			writelog "Multiple events or invalid date from same source: $($Event.SourceIdentifier)" red
			writelog "Please mail this output to ruudb@microsoft.com" yellow
		}
		else {
			#Look at our own sourced events only
			if ($Event.SourceIdentifier -match "TEV") {$global:RXobj += $event.Sender}
		}
		$global:EVdone += $Event.SourceIdentifier
	}
	) 
} 
#touch properties to trigger events and wait for arrival
$dss | select latestrecoverypoint > $null #do not use [void] coz does not trigger
$begin = get-date
while (((Get-Date).subtract($begin).seconds -lt 10) -and ($RXobj.count -lt $dss.count) ) {sleep -Milliseconds 250}
Unregister-Event * 
writelog "Processing $($RXobj.count) out of $($dss.count) received sources"

foreach ($ds in $RXobj) {
	$item = "" | select DPM, PSname, Latest, Age, Score, DSpath, Displayline
	if ($ds.LatestRecoverypoint.year -lt 2000) {Throw "ScriptBug: invalid date encountered"}
	$score = GetScore $ds 
	if (!$score) {continue;}
	if (((get-date).Subtract($ds.LatestRecoverypoint).Hours -ge $age) -or ($score -lt $percent)) {
		$item.DPM = (&hostname)
		$item.PSname=$ds.ProductionServerName
		$item.Latest=$ds.LatestRecoverypoint
		$item.Age = [int](Get-Date).subtract($ds.latestrecoverypoint).hours
		$item.Score = $score
		$item.DSpath = $ds.DisplayPath
		$item.Displayline = "$($ds.LatestRecoverypoint.Tostring($format)) | $($score.tostring("000")) % | $($ds)"
		$retobj += $item
		writelog $item.Displayline yellow
		$item.Displayline >> $reportfile #add data source to file	
	}
}

if ($schedule) { 
	$params = "-age $age -starttime $starttime "
	$scriptfile = ".\$($TN).Ps1"
	Schedule "$((Get-item $scriptfile).fullname)" $params $starttime $age
}
return $retobj