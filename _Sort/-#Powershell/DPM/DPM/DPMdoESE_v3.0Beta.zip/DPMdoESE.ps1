#Author: Ruud Baars
# Date 11/12/2009
#
# v3.0 Beta1 completely reworked for DPM2010 / E2010
#
# Synopsis:
# This script implements ESEUTIL/k checks out of band of DPM to avoid very long DPM backup jobs that
# would prohibit desired scheduling. Configuration sets #checks/day and on how many consecutive days.
# This script schedules itself (as SCHEDULEDRIVER) and tasks (as ESETASK-x) to run ESEUTIL/k against EDB 
# and logfiles for both ExpressFull and Incremental protected data. This scripts ends and recreates tasks as
# a selfhealing approach, schedule should be such that ESETASK-x finish before this script runs again.
# Ineractively running this script with "-setup 1" allows to configure various parameters, "-resetlastrun 1"
# resets last run date to 1/1/1980 to recheck all data. Configuration for this script is DPMdoESEConfig.XML
# and writes ESETASK-x-params.XML that control the scheduled ESTASK-x (avoiding >260 char cmdline).
# New replica shadow copies are created using DPMBACKUP and mounted a short paths (C:\ESE\x\) to 
# overcome the 260 char (MAX_PATH) limitation to EDB and log paths down under DPM path. 
# DPMBACKUP and ESEUTIL output is parsed to validate success and is saved to log files. This script logs 
# to DPMdoESE.LOG and the tasks log to ESETASK-x.LOG (including full ESEUTIL output).
# Unexpected conditions throw exceptions that are trapped and write to log file and Application event log (Event ID 9911).
# Lastly protection group options are changed such that DPM will not run EDB check or none at all.
#
# -cleanup 1 will stop and delete all scheduled tasks, dismount our mount points and delete subdirectories.

param ([boolean]$setup = $false, [boolean]$resetLastRun = $false, [boolean]$cleanup=$false )

#region FUNCTIONS
trap [Exception] 
{
	writelog "<<< ERROR >>>"
	#writelog $("TRAPPED: " + $_.Exception.GetType().FullName); 
	writelog $("TRAPPED: " + $_.Exception.Message); 

	$Error
	writelog "<<< END >>>"
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "DPMdoESE"
	$log.WriteEntry("TRAPPED: $error", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	$Error.Clear()
	exit 
}
function writelog 
{
	#write to console and logfile, pre-able with date time
	param([array]$msg)
	$dt = (Get-Date).ToString("MM/dd/yy HH:ss")
	"$dt :: " >> $logfile
	if ($debug) {Write-Host "$dt:: " -NoNewline}
	for ($i = 0;$i -lt $msg.count;$i++) {
		if ($debug) {Write-Host $msg[$i]} 
		$msg[$i] >> $logfile
	}
} 
function GetDpmMP
{
	# Get DPM mount points by type: Diffarea or Replica or Shadowcopy, defaults to shadowcopy
# Basically to avoid PSCX Get-MounPoint dependency and WMI Win32_MountPoint unreliable (on W2008 Sp2 x64)
# builds array of $dpmmp structures ($PTvols)
# 		<obj>.Target = volume ident in format \\?\Volume{guid} with trailing slash removed
# 		<obj>.Path = mount point path including trailing slash
#  + key-value pairs into $VolObj structure
#		<obj>.Vols  = $PTvols = @(dpmmp)
#		<obj>.KVP = $KPvols = @(Key, Value)

	param([string]$volumetype = "ShadowCopy", [string]$writertype = "Exchange Writer", [string]$esedir )

	$VolObj = "" | Select Vols, KVP
	$PTVols = @()
	$KPvols = @{}
	switch ($volumetype.ToUpper()) {
		ShadowCopy {$paths = @(mountvol | ?{($_ -match "Microsoft DPM") -and ($_ -match "ShadowCopy") -and ($_ -match $writertype)}) }
		Replica {$paths = @(mountvol | ?{($_ -match "Microsoft DPM") -and ($_ -match "Replica") -and ($_ -match $writertype)}) }
		Diffarea {$paths = @(mountvol | ?{($_ -match "Microsoft DPM") -and ($_ -match "Diffarea") -and ($_ -match $writertype)}) }
		Default {$paths = @(mountvol | ?{($_ -match "Microsoft DPM") -and ($_ -match "ShadowCopy") -and ($_ -match $writertype)}) }
	}
	if ($paths.Count -lt 1) {Throw "No mount points found!"}
	#Ensure we have unique paths to quey volumes for
	$paths = $paths | sort -Unique
	foreach ($p in $paths) {
		$dpmmp = "" | Select Target, Path
		#retrieve volume for path
		$dpmmp.Target=(mountvol ("`"{0}`" /L" -f , $p.trimend("\").trim())).trimend("\").trim()
		$dpmmp.Path=$p.trim()
		$PTvols += $dpmmp
		$KPvols.Add($dpmmp.target.trim(), $dpmmp.path.trim())
		$dpmmp = $null
	}
	$VolObj.KVP=$KPvols
	$VolObj.Vols=$PTvols
	return $VolObj
}
function WaitForTask 
{
	### No longer used, but keeping code for now ###

	param($taskname)
	#take 5 sec allowing to get in 'running' state if just scheduled
	Start-Sleep 5
	writelog "Checking for task $taskname not running or wait for it to complete"
	$msg = $null
	$msg = @((schtasks /query) | ? {$_ -match $taskname})
	if ($msg.count -lt 1) {writelog "Task $taskname not found..."; return }
	$running = @($msg | ? {$_ -match "Running"})
	if ($running.count -lt 1) {writelog "No running $taskname found..."; return }

	#now check status, wait & query again
	while ($running.count -gt 0 ) {
		#Take at least 30 sec, dpmbackup waits 30 if datasource busy
		writelog "Waiting 30 seconds for $taskname to complete..."
		Start-Sleep 30
		$running = @((schtasks /query)| ? {($_ -match $taskname) -and ($_ -match "Running")})
	}
	writelog "Wait for task $taskname done!" 
}
function DoDPMbackup 
{
	param ($CfgXML)
	# End all ESETASK*, dpmbackup deletes current shadow, ESETASK* will be rescheduled
	# We do want to run dpmbackup now to ensure fresh shadow copies
	writelog "Stopping ESETASKS before running dpmbackup..."
	$esetasks = @(( schtasks /query) | ? { $_ -match "ESETASK"})
	# Get taskname only, stop and end those (a store may have been removed, task no longer needed) 
	$ToEnd = @($esetasks | foreach{$_.Split(" ")[0] }) 
	$ToEnd | foreach {schtasks /end /TN $_}
	$ToEnd | foreach {schtasks /delete /F /TN $_}
	# return now if we are only cleaning up
	if ($cleanup) {
		schtasks /end /TN $CfgXML.ESEConfig.SchedulerTaskname
		schtasks /delete /F /TN $CfgXML.ESEConfig.SchedulerTaskname
		writelog "Cleanup mode: skipping new shadow copies"
		return;
	}
	
	# Run now and wait to complete to ensure we have fresh shadow copies
	Set-Location $dpminstallpath 
	writelog "Starting DPMBACKUP job..."
	writelog ("-"*40)
	$received = Invoke-Expression "DPMBACKUP -replicas"
	writelog $received
	writelog ("-"*40)
	Set-Location $CfgXML.ESEconfig.eseroot 
	#Parse results
	$ErrMsg = @($received | ? {$_ -match "Error"}) 
	if (($ErrMsg.count -gt 0) -and ( $ErrMsg -match "exchange")) {
		Throw "DPMBACKUP reported Exchange related errors!"
	}
	else {
		writelog "DMBACKUP completed OK!"
	}
}
function SetESEUtilOption
{
	param ($s, [int]$action)
	$pname = $s.protectiongroupname
	writelog "Checking options for group [$pname] datasource [$s.name]"
	$pg = @(Get-ProtectionGroup -DPMServerName $dpmservername | where {$_.friendlyname -match $pname})
	if ($pg.count -lt 1) {Throw "Protection group object for $pname returned nothing!"}

	# DONT ACCESS E12 OPTIONS IF PG DOES NOT HAVE E12 servers, else the cmdlet will crash, see bug 46025
	#E14 there is only $E14option.EseUtilType = "DontRun" or "RunOnLogs" or "RunOnLogsAndDB"
	# if E14 EseUtilType = "DontRun" the E12 RunEseUtil will be false, otherwise true

	$E12runese = $false
	if ($s.version.major -gt 12) {
		#E14
		$E14options = Get-DatasourceProtectionOption $pg[0] -E14Options
		$E14runese = $E14options.EseUtilType
	} 
	else {
		$E12options = Get-DatasourceProtectionOption $pg[0] -ExchangeOptions
		$E12runese = $E12options.RunEseUtilCC
	}

	#Keep what we used for E2007 for now outcommented
#NOTE: on E14; the E12 RunEseUtil option is $true, so make sure not looking at E14
	if (($E12runese) -and ($s.version.major -lt 14)) {
		#E12 :: this used to work for E2007, yet to be validated 
		writelog "Skipping E12 eseutils option changes, not tested with this script yet"
		# 		if ($s.ExchangeCCR){
# 			[string]$list = $E12options.PreferredServers.get(0)
# 			$nodes = $list.split(" ")
# 			$cluster = $nodes[0]
# 			$node = $nodes[1]
# 			writelog "Cluster is set to $cluster"
# 		}
# 		else {
# 			$node = $s.PreferredServer
# 			$cluster = $s.PreferredServer
# 		}
# 		$topology = $E12options.ProtectionTopology
# 		writelog "Node is set to $node"
# 		writelog "Topology for $pname is set to: $topology"
# 		writelog "RunEseUtilCC is set to: $runese"
# 		set-datasourceprotectionoption -protectiongroup $mpg -exchangeoptions -topologytype $topology -preferredphysicalnode ( $cluster, $node ),("","") -RunEseUtilConsistencyCheck:$false
# 		Set-ProtectionGroup $mpg
# 		writelog "DISABLED the E12 run eseutilcc option!"
	}
	else {
		#E14 :: all straight no more SCR/CCR
		if ($action -gt 0 ) {$E14runese = "RunOnLogs"} else {$E14runese = "DontRun"}
		$mpg = Get-ModifiableProtectionGroup -ProtectionGroup $pg[0]
		if (!$mpg) {Throw "No modifiable object returned for protection group $pname!"}
		Set-DatasourceProtectionOption -ProtectionGroup $mpg -ExchangeOptions -EseutilCheckType:$E14runese
		Set-ProtectionGroup $mpg
		writelog "E14 eseutiltype to SET to $E14runese!"
	}
	writelog "Checking options for group [$pname] done!"
}
function DoESEdirsAndMount
{
	param( $shcpy, $CfgXML)
	$structarray = @()
	#subdirectory namer -> keep as short as possible
	[int]$d = 0 
	foreach ($s in $shcpy) {
		#initialize structure to build
		$db = "" | select edb, FullPath, Incrementals, Prefix
		$db.edb="" #hold esb file spec
		$db.FullPath="" #lhold full logfile paths
		$db.Incrementals=@() #hold incremental items (path and creation date)
		$db.Prefix="" #hold log prefix for datasource
		$mpdir = "{0}\{1}" -f $CfgXML.ESEConfig.Eseroot, $d

		#create dir if not exist
		writelog "Ensuring $mpdir exists..."
		if (!(Test-Path $mpdir)) {New-Item -path $eseroot -name $d -itemType Directory -Confirm:$false -ErrorAction "SilentlyContinue"}
		#delete any mountpoints
		writelog "Refreshing mountpoint for $mpdir"
		$msg = @(mountvol "$mpdir" /d)
		if ($msg.count -gt 0) {writelog $msg}
		#continue with next if we are cleaning up
		if ($cleanup) {
			writelog "Cleanup mode: skipping new mount point "
			Remove-Item -Confirm:$false  "$eseroot\$d" -Force
			$d++
			continue;
		}
		
		#create new mountpoint
		$msg = @(mountvol "$mpdir" $shcpy[$d].target)
		if ($msg.count -gt 0) {writelog $msg}

		#search edb and <Filterlog> to get log path
		writelog "Searching Full and Incremental paths..."
		$db.edb=(Get-ChildItem -Recurse -Filter "*.edb" -Path $mpdir).fullname 
		#filter"Full" this return the ExpressFull tree
		$db.FullPath=Get-ChildItem -Recurse -Filter $CfgXML.ESEConfig.LogFilter -Path $mpdir | ?{$_.fullname -match "Full"} | foreach {$_.directory.fullname}
		$db.prefix=(Get-ChildItem -Recurse -Filter $CfgXML.ESEConfig.LogFilter -Path $mpdir | ?{$_.fullname -match "Full"}).Basename.Substring(0,3)
		if ($db.Prefix.Length -lt 3) {Throw "No EDB and prefix found!"}
		#filter on "Incremental" this returns the Incremental trees (multiple)
		$t = @(Get-ChildItem -Recurse -Filter $CfgXML.ESEConfig.LogFilter -Path $mpdir | ?{$_.fullname -match "Incremental"} | foreach {$_.directory.fullname})
		if ($t.count -eq 0) {
			writelog "No incremental paths found for:  $mpdir"
		}
		else {
			$t | foreach { 
				$IncItem = "" | select Path, Date;
				$IncItem.path = $_;
				$IncItem.Date= (Get-Item $_).lastwritetime;
				$db.Incrementals += $IncItem
			}
		} 
		#add data structure to array
		$structarray += $db 
		$d++
		writelog ("Added shadow: {0} = `n{1}" -f $s.target, $s.path)
	}
	writelog "Directories and mountpoints done!"
	#return array of structures
	return $structarray	
}

function DoConfig
 {
	param ($setup, $resetLastRun)
	$format = "HH:mm:00"
	if (Test-Path "DPMdoESEConfig.XML" -ErrorAction silentlycontinue) {
		[xml]$xml = Get-Content "DPMdoESEConfig.XML"
	}
	else {
		#Create decent XML structure
#maxlog defaults to 5MB
		$hdr = '<?xml version="1.0" encoding="utf-8"?>
 <ESEConfig xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
		Scriptversion="V3.0 Beta1"
		Eseroot="C:\ESE"
		EsePerf="C:\ESE\ESEPERF.CSV"
		DpmAction="1"
		LogFilter="E*tmp.log"
		Configfile="DPMdoESEConfig.XML"
		Logfile="DPMdoESE.LOG"
		Maxlog="5" 
		SchedulerTaskname="SCHEDULEDRIVER"
		Stagger="30"
		Startscript="00:45:00"
		StartESE="01:00:00"
		Interval="WEEKLY"
		Daycount="7"
		Checksperday="7">
		</ESEConfig>'
 
		$xml = [xml]$hdr
	}

	if ($setup) 
	{
		$result = read-host ("Enter path to files [{0}]" -f $xml.ESEConfig.Eseroot) 
		if ($result.length -gt 3) {
			$xml.ESEConfig.Eseroot=$result
			$xml.ESEConfig.EsePerf="$result\ESEPERF.CSV"
		}
		$result = read-host ("Should DPM run eseutil on logs 0/1 [{0}]" -f $xml.ESEConfig.DpmAction) 
		if ($result -eq "0") {$xml.ESEConfig.DpmAction="0"} else {$xml.ESEConfig.DpmAction="1" }
		# logfilter search is NOT the base name prefix for ESEUTIL
		$result = read-host ("Enter logfile search pattern [{0}]" -f $xml.ESEConfig.Logfilter) 
		if ($result.length -gt 3) {$xml.ESEConfig.Logfilter=$result}
		$result = read-host ("Maximum log size in MB [{0}]" -f $xml.ESEConfig.Maxlog)
		if ($result.length -gt 0) {$xml.ESEConfig.Maxlog=$result.ToString()}
		$result = read-host ("Script scheduled task name [{0}]" -f $xml.ESEConfig.SchedulerTaskname)
		if ($result.length -gt 0) {$xml.ESEConfig.SchedulerTaskname=$result}
		$result = read-host ("Stagger time in minutes [{0}]" -f $xml.ESEConfig.stagger)
		if ($result.length -gt 0) {$xml.ESEConfig.stagger=$result.ToString()}
		$result = read-host ("Schedule driver start time as HH:mm:ss [{0}]" -f $xml.ESEConfig.startscript)
		if ($result.length -gt 0) {$xml.ESEConfig.startscript=get-date($result).tostring($format)}
		$result = read-host ("ESEUTIL check start time as HH:mm:ss [{0}]" -f $xml.ESEConfig.startese)
		if ($result.length -gt 0) {$xml.ESEConfig.startese=get-date($result).tostring($format)}
		$result = "~" 
		while (!("DAILY,WEEKLY,MONTHLy" -match $result)) {
			$result = read-host ("Interval as DAILY or WEEKLY or MONTHLY [{0}]" -f $xml.ESEConfig.interval)
			if ($result.length -gt 0) {$xml.ESEConfig.interval=$result.tostring()} else {$result = $xml.ESEConfig.interval}
		}
		$result = read-host ("How many days to run ESEUTIL [{0}]" -f $xml.ESEConfig.daycount)
		if ($result.length -gt 0) {$xml.ESEConfig.daycount=$result}
		$result = read-host ("How many ESEUTIL runs per day [{0}]" -f $xml.ESEConfig.checksperday)
		if ($result.length -gt 0) {$xml.ESEConfig.checksperday=$result}
	}

	#save and reload
	$configfile = "{0}\{1}" -f $xml.ESEConfig.eseroot, $xml.ESEConfig.configfile
	$xml.save($configfile)
	[xml]$xml = Get-Content $configfile 
	#overwrite configuration in current location if any
	if (Test-Path "DPMdoESEConfig.XML" -ErrorAction silentlycontinue) {$xml.save("DPMdoEseConfig.XML")}

	if ($resetLastRun) {
		foreach ($f in Get-ChildItem ("{0}\ESETASK-*.XML" -f $xml.ESEconfig.Eseroot)) {
			writelog ("Resetting last run times in: {0}..." -f , $f.fullname)
			[xml]$txml = get-content $f
			$txml.Params.LastEDBrun="1/1/1980"
			$txml.Params.LastFULLrun="1/1/1980"
			$txml.Params.LastINCrun="1/1/1980"
			$txml.save($f)
		}
		writelog "Resetting lastrun times done!"
		exit 0
	}
	if ($setup) {exit 0}
	return $xml
}
function Schedule
 {
	param ($shadowvols, $pstructs, $CfgXML)
	writelog "Scheduling tasks..."
	$eseroot = $cfgXML.ESEConfig.Eseroot

	#query for tasks, 	#don't writelog, on W2008 and later this is a long list
	$q = @(schtasks /query)

	#schedule this script
	if($q -match $schedTN) {writelog "Task $schedTN already scheduled" }
	else {
		writelog "Scheduling this script..."
		$thisscript = "`"`"`"`"powershell`"`"`" -noninteractive -nologo -command `"`"`"&{$eseroot\DPMdoESE.ps1}`"`"`""
		$msg = $null
		$msg = @(schtasks /create /F /TN $schedTN /SC "DAILY" /RU "System" /ST $CfgXML.ESEConfig.Startscript /TR $thisscript)
		writelog $msg
		if ($msg -inotmatch "SUCCESS") {Throw "ERROR: scheduler reported a failure"}
	}

	writelog ("Processing {0} path structures..." -f , $pstructs.count)
	$t = Get-Date $CfgXML.ESEConfig.StartESE
	for ($k = 0; $k -le $pstructs.count; $k += [int]$CfgXML.ESEconfig.daycount) 
	{
		switch ($k) 
		{
			0 {$day = "MON"}
			7 {$day = "TUE"}
			14 {$day = "WED"}
			21 {$day = "THU"}
			28 {$day = "FRI"}
			35 {$day = "SAT"}
			42 {$day = "SUN"}
		}
		for ($j = 0; $j -lt [int]$CfgXML.ESEconfig.checksperday; $j ++)
		{
			$z = $k + $j
			if ($z -ge $pstructs.count) {break}
			$tn = "ESETASK-$z"
			writelog "Scheduling task $tn at $t"
			$EseParamFile = "$eseroot\$tn-params.XML"

			# build param xml 
			$hdr = '<?xml version="1.0" encoding="utf-8"?>
 <Params xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"></Params>'
 			$taskxml = [xml]$hdr
			[void]$taskxml.Params.SetAttribute("LastEDBrun", "1/1/1980")
			[void]$taskxml.Params.SetAttribute("LastFULLrun", "1/1/1980") 
			[void]$taskxml.Params.SetAttribute("LastINCrun", "1/1/1980")
			[void]$taskxml.Params.SetAttribute("Maxlog" ,$cfgXML.ESEconfig.maxlog)
			[void]$taskxml.Params.SetAttribute("Eseperf" ,$cfgXML.ESEconfig.EsePerf)
			[void]$taskxml.Params.SetAttribute("DriverScriptversion" ,$cfgXML.ESEconfig.scriptversion)

			#add FULL edb file and path information
			$EDBitem = $taskxml.CreateElement("EDB")
			[void]$taskxml.Params.AppendChild($EDBitem)
			[void]$EDBitem.SetAttribute("EDBfile", $pstructs[$z].edb)
			writelog ("Added EDB file: {0}" -f , $pstructs[$z].edb)
			[void]$EDBitem.SetAttribute("fullpath", $pstructs[$z].fullpath)
			writelog ("Added Full log path: {0}" -f , $pstructs[$z].fullpath)
			[void]$EDBitem.SetAttribute("Prefix", $pstructs[$z].prefix) 
			writelog ("Added with Prefix [{0}]" -f $pstructs[$z].prefix)

			#add all incrementals paths
			$INCitem = $taskxml.CreateElement("Incrementals")
			[void]$taskxml.Params.AppendChild($INCitem)
			[int]$li = 0
			if ($pstructs[$z].Incrementals.count -gt 0) 
			{
				writelog "Adding incremental log paths for $tn :"
				foreach ($incremental in $pstructs[$z].Incrementals) {
					$item = $taskxml.createelement("P$li")
					[void]$INCitem.AppendChild($item)
					[void]$item.SetAttribute("Path",$incremental.path)
					[void]$item.SetAttribute("Date",$incremental.date)
					writelog ("[{0}] {1} = {2}" -f $li, $incremental.date.tostring("MM/dd/yy HH:mm:ss"), $incremental.path)
					$li++} 
			}
			else {writelog "*NO INCREMENTAL* paths found!"}
			$taskxml.save($EseParamfile) 
			#NOTE: must use 3 escaped quotes to get effectively quoted passed
			$schedcmd = "`"`"`"`"powershell`"`"`" -noninteractive -nologo -command `"`"`"&{$eseroot\DPMdoTask.Ps1 '$EseParamfile' }`"`"`""
			$msg = $null
			$msg = @(schtasks /create /F /D $day /TN $tn /SC $CfgXML.ESEconfig.interval /RU "System" /ST $t.ToString("HH:mm:00") /TR $schedcmd)
			writelog $msg
			if ($msg -inotmatch "SUCCESS") {Throw "ERROR: scheduler reported a failure"}
			$t = $t.AddMinutes([int]$CfgXML.ESEconfig.stagger)
		}
	}
	writelog "Scheduling done!"
}
#endregion

#region INIT
$version = "V3.0 Beta1"
$debug = $true #set to false for no console output
$dpmservername = hostname
$global:dpminstallpath = (Get-ItemProperty -Path "HKLM:SOFTWARE\microsoft\microsoft data protection manager\setup").installpath
$MB = 1024 * 1024
$ReportErrorShowExceptionClass=$true
$ReportErrorShowInnerException=$true
$ReportErrorShowSource=$true
$ReportErrorShowStackTrace=$true 
#------------------ Base config ----------------------------------------
$CfgXML = DoConfig $setup $resetLastRun
$eseroot = $cfgXML.ESEconfig.eseroot
$logfile = $cfgXML.ESEconfig.logfile
$maxlog = [int]$cfgXML.ESEconfig.maxlog * $MB
$schedTN = $cfgXML.ESEconfig.schedulertaskname
#--------------------------------------------------------------------
writelog ("=" * 60) 
writelog "Starting DPMdoESE $version"
writelog ("-" * 30) 

#load DPM snap-in regardlessly and clear the error
Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell -erroraction SilentlyContinue
$Error.Clear()
$DPMversion = (Connect-DPMServer $dpmservername).getproductinformation().version.major
if ($DPMVersion -lt 3) {Throw "This script requires DPM2010 or later"}

#get ourselves setup, ensure logfile does not keep growing endlessly
if ((Get-Item $logfile).length -gt $maxlog) {Remove-Item -path $logfile -Confirm:$false}
#create dir and copy files if missing
if (!(Test-Path $eseroot)) {New-Item -path $eseroot -itemType Directory -Confirm:$false}
if (!(Test-path "$eseroot\DPMdoESE.PS1")) {Copy-Item -path "DPMdoESE.Ps1" -destination $eseroot -Confirm:$false}
if (!(Test-path "$eseroot\DPMdoTask.PS1")) {Copy-Item -path "DPMdoTask.Ps1" -destination $eseroot -Confirm:$false}
if (!(Test-path "$eseroot\eseutil.exe")) {Copy-Item -path "eseutil.exe" -destination $eseroot -Confirm:$false}
if (!(Test-path "$eseroot\ese.dll")) {Copy-Item -path "ese.dll" -destination $eseroot -Confirm:$false}
Set-Location $eseroot
#endregion
# END INIT
# run dpmbackup if not yet to ensure we have the shadowcopy paths
DoDPMbackup $CfgXML

# Get DPMackup shadowcopy mountoints filtered on exchange writer paths
$shadowStruct = GetDpmMP "ShadowCopy" "Exchange" $eseroot
if ($shadowStruct.Vols.count -lt 1) {Throw "No shadowcopy mountpoints found, DPMBACKUP probably failed!"}

# create mountpoint-directories, delete and recreate mountpoints
# this re-instates ESE dirs previously invalidated if we called DoDPMbackup
$pstructs=@()
$pstructs = DoESEdirsAndMount $shadowStruct.Vols $CfgXML



if ($cleanup) {
	writelog "Finished CLEANUP DPMdoESE $version"
	exit $Error.count
}
else {
	# This is a stupid workaround for something that freaks me out
	# For some reason the stucture is fine at function return but back here suddenly shadowStruct.Vols is added first???
	$revisedstructs=@()
	$revisedstructs= $pstructs | ? {$_.GetType().Name -eq "PSCustomObject"} # ensure we only take intended objects
	if ($revisedstructs.count -lt 1) {Throw "No data structures build, likely script logic error -> not supposed to ever be here"}
}
# [re]schedule tasks
Schedule $shadowstruct.Vols $revisedstructs $CfgXML

#get Exchange datasources to modify corresponding ESE util options
$ds = @(Get-Datasource $dpmservername | where {(($_.Type.Name -eq "Storage group" ) -or ($_.Type.Name -eq "Exchange Mailbox Database" )) -and ($_.currentprotectionstate -eq "Protected") -and ($_.version.major -ge 12)})
if ($ds.count -lt 1) {Throw "No protected Exchange datasources!"}
foreach ($s in $ds) {SetESEUtilOption $s $CfgXML.ESEconfig.DpmAction}

writelog "Finished DPMdoESE $version"
exit $Error.count

